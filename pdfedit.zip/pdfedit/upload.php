<?php
header('Content-Type: application/json');
session_start();

// Load environment variables
require_once 'vendor/autoload.php';
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Configuration
$uploadDir = 'uploads/';
$maxFileSize = 50 * 1024 * 1024; // 50MB
$allowedTypes = ['application/pdf'];

// Create upload directory if it doesn't exist
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

try {
    // Check if file was uploaded
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error occurred');
    }

    $file = $_FILES['file'];
    
    // Validate file size
    if ($file['size'] > $maxFileSize) {
        throw new Exception('File size exceeds maximum limit of 50MB');
    }
    
    // Validate file type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        throw new Exception('Invalid file type. Only PDF files are allowed');
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('pdf_') . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        throw new Exception('Failed to move uploaded file');
    }
    
    // Validate PDF file
    if (!validatePDF($filepath)) {
        unlink($filepath); // Delete invalid file
        throw new Exception('Invalid PDF file');
    }
    
    // Store file info in session
    $_SESSION['current_pdf'] = [
        'filename' => $filename,
        'original_name' => $file['name'],
        'filepath' => $filepath,
        'size' => $file['size'],
        'upload_time' => time()
    ];
    
    echo json_encode([
        'success' => true,
        'filePath' => $filepath,
        'filename' => $filename,
        'originalName' => $file['name'],
        'size' => $file['size']
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

/**
 * Validate PDF file
 */
function validatePDF($filepath) {
    // Check if file exists and is readable
    if (!file_exists($filepath) || !is_readable($filepath)) {
        return false;
    }
    
    // Check file header for PDF signature
    $handle = fopen($filepath, 'rb');
    if (!$handle) {
        return false;
    }
    
    $header = fread($handle, 4);
    fclose($handle);
    
    // PDF files start with %PDF
    if (strpos($header, '%PDF') !== 0) {
        return false;
    }
    
    return true;
}
?>
