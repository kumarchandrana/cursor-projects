#!/usr/bin/env python3
"""
Setup script for Indian Language TTS
Installs all required dependencies for offline Indian language text-to-speech
"""

import subprocess
import sys
import os
from pathlib import Path

def run_command(command, description):
    """Run a command and handle errors"""
    print(f"📦 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} failed: {e}")
        print(f"Error output: {e.stderr}")
        return False

def install_python_packages():
    """Install required Python packages"""
    packages = [
        "TTS",  # Coqui TTS for Indic-TTS
        "librosa",  # Audio processing
        "soundfile",  # Audio file handling
        "torch",  # PyTorch for neural networks
        "torchaudio",  # PyTorch audio
        "numpy",  # Numerical computing
        "scipy",  # Scientific computing
        "matplotlib",  # Plotting
        "pydub",  # Audio manipulation
        "gtts",  # Google Text-to-Speech (fallback)
        "moviepy",  # Video processing
    ]
    
    print("🔧 Installing Python packages...")
    for package in packages:
        if not run_command(f"{sys.executable} -m pip install {package}", f"Installing {package}"):
            print(f"⚠️  Warning: Failed to install {package}")
    
    print("✅ Python package installation completed")

def create_directories():
    """Create necessary directories"""
    directories = [
        "models/indian_tts",
        "models/indian_tts/hi",
        "models/indian_tts/bn", 
        "models/indian_tts/ta",
        "models/indian_tts/te",
        "models/indian_tts/mr",
        "models/indian_tts/gu",
        "models/indian_tts/kn",
        "models/indian_tts/ml",
        "models/indian_tts/pa",
        "models/indian_tts/or",
        "models/indian_tts/as",
        "models/indian_tts/ne",
        "models/indian_tts/ur",
        "output",
        "temp"
    ]
    
    print("📁 Creating directories...")
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    print("✅ Directory creation completed")

def download_sample_models():
    """Download sample models for testing"""
    print("📥 Setting up sample models...")
    
    # Create a simple script to download models
    download_script = """
import os
import json
from pathlib import Path

def create_sample_models():
    languages = {
        'hi': 'Hindi',
        'bn': 'Bengali', 
        'ta': 'Tamil',
        'te': 'Telugu',
        'mr': 'Marathi',
        'gu': 'Gujarati',
        'kn': 'Kannada',
        'ml': 'Malayalam',
        'pa': 'Punjabi',
        'or': 'Odia',
        'as': 'Assamese',
        'ne': 'Nepali',
        'ur': 'Urdu'
    }
    
    for lang_code, lang_name in languages.items():
        lang_dir = Path(f"models/indian_tts/{lang_code}")
        lang_dir.mkdir(parents=True, exist_ok=True)
        
        # Create fastpitch directory
        fastpitch_dir = lang_dir / "fastpitch"
        fastpitch_dir.mkdir(parents=True, exist_ok=True)
        
        # Create hifigan directory
        hifigan_dir = lang_dir / "hifigan"
        hifigan_dir.mkdir(parents=True, exist_ok=True)
        
        # Create config files
        config = {
            "model": "fastpitch",
            "language": lang_code,
            "language_name": lang_name,
            "speaker": "default",
            "sample_rate": 22050,
            "offline_tts": True
        }
        
        with open(lang_dir / "config.json", 'w') as f:
            json.dump(config, f, indent=2)
            
        vocoder_config = {
            "model": "hifigan",
            "language": lang_code,
            "language_name": lang_name,
            "sample_rate": 22050
        }
        
        with open(hifigan_dir / "config.json", 'w') as f:
            json.dump(vocoder_config, f, indent=2)
        
        # Create placeholder model files
        (fastpitch_dir / "best_model.pth").touch()
        (hifigan_dir / "best_model.pth").touch()
        
        print(f"✅ Created sample models for {lang_name}")

if __name__ == "__main__":
    create_sample_models()
"""
    
    with open("setup_sample_models.py", "w") as f:
        f.write(download_script)
    
    if run_command(f"{sys.executable} setup_sample_models.py", "Creating sample models"):
        os.remove("setup_sample_models.py")
        print("✅ Sample models created successfully")
    else:
        print("❌ Failed to create sample models")

def test_installation():
    """Test the installation"""
    print("🧪 Testing installation...")
    
    test_script = """
try:
    import TTS
    print("✅ TTS module imported successfully")
except ImportError as e:
    print(f"❌ TTS module import failed: {e}")

try:
    import librosa
    print("✅ librosa module imported successfully")
except ImportError as e:
    print(f"❌ librosa module import failed: {e}")

try:
    import soundfile
    print("✅ soundfile module imported successfully")
except ImportError as e:
    print(f"❌ soundfile module import failed: {e}")

try:
    import torch
    print("✅ torch module imported successfully")
except ImportError as e:
    print(f"❌ torch module import failed: {e}")

try:
    from indian_tts_module import IndianTTS
    print("✅ Indian TTS module imported successfully")
    
    tts = IndianTTS()
    print("✅ Indian TTS initialized successfully")
    
    status = tts.get_status()
    print(f"📊 TTS Status: {status}")
    
except ImportError as e:
    print(f"❌ Indian TTS module import failed: {e}")
except Exception as e:
    print(f"❌ Indian TTS initialization failed: {e}")

print("🎉 Installation test completed!")
"""
    
    with open("test_installation.py", "w") as f:
        f.write(test_script)
    
    run_command(f"{sys.executable} test_installation.py", "Testing installation")
    os.remove("test_installation.py")

def main():
    """Main setup function"""
    print("=" * 60)
    print("🇮🇳 Indian Language TTS Setup")
    print("=" * 60)
    print()
    
    print("This script will install all required dependencies for")
    print("offline Indian language text-to-speech support.")
    print()
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required")
        return False
    
    print(f"✅ Python version: {sys.version}")
    print()
    
    # Install packages
    install_python_packages()
    print()
    
    # Create directories
    create_directories()
    print()
    
    # Download sample models
    download_sample_models()
    print()
    
    # Test installation
    test_installation()
    print()
    
    print("=" * 60)
    print("🎉 Setup completed!")
    print("=" * 60)
    print()
    print("📋 What's been installed:")
    print("• TTS (Coqui TTS) for Indic-TTS support")
    print("• Audio processing libraries (librosa, soundfile)")
    print("• PyTorch for neural network models")
    print("• All required Python packages")
    print("• Directory structure for Indian language models")
    print("• Sample model configurations")
    print()
    print("🚀 Next steps:")
    print("1. Run 'python index.py' to launch the control center")
    print("2. Select any Indian language from the dropdown")
    print("3. The system will use offline TTS for authentic pronunciation")
    print("4. For real models, download from AI4Bharat/Indic-TTS repository")
    print()
    print("📚 Supported Indian Languages:")
    print("• Hindi, Bengali, Tamil, Telugu, Marathi")
    print("• Gujarati, Kannada, Malayalam, Punjabi")
    print("• Odia, Assamese, Nepali, Urdu")
    print()
    
    return True

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n❌ Setup interrupted by user")
    except Exception as e:
        print(f"\n❌ Setup failed with error: {e}")
        import traceback
        traceback.print_exc()
