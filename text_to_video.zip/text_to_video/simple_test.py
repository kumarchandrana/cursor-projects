"""
Simple test script to verify the text-to-video components work
"""

def test_tts():
    """Test text-to-speech functionality"""
    print("Testing Text-to-Speech...")
    try:
        from tts_module import TextToSpeech
        tts = TextToSpeech()
        
        # Test basic TTS
        test_text = "Hello, this is a test of the text to speech system."
        audio_path = tts.generate_speech(test_text)
        
        if audio_path:
            print(f"✅ TTS working! Audio saved to: {audio_path}")
            return True
        else:
            print("❌ TTS failed")
            return False
    except Exception as e:
        print(f"❌ TTS error: {str(e)}")
        return False

def test_animation():
    """Test animation functionality (without rendering)"""
    print("\nTesting Animation Module...")
    try:
        from animation_module import TextAnimation
        animator = TextAnimation()
        print("✅ Animation module imported successfully")
        return True
    except Exception as e:
        print(f"❌ Animation error: {str(e)}")
        return False

def test_video_sync():
    """Test video synchronization module"""
    print("\nTesting Video Sync Module...")
    try:
        from video_sync import VideoSynchronizer
        sync = VideoSynchronizer()
        print("✅ Video sync module imported successfully")
        return True
    except Exception as e:
        print(f"❌ Video sync error: {str(e)}")
        return False

def test_pipeline():
    """Test the main pipeline"""
    print("\nTesting Main Pipeline...")
    try:
        from text_to_video_pipeline import TextToVideoPipeline
        pipeline = TextToVideoPipeline()
        print("✅ Main pipeline imported successfully")
        return True
    except Exception as e:
        print(f"❌ Pipeline error: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("=" * 50)
    print("🧪 Text-to-Video Generator - Component Test")
    print("=" * 50)
    
    tests = [
        test_tts,
        test_animation,
        test_video_sync,
        test_pipeline
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All components are working!")
        print("\nNext steps:")
        print("1. Install FFmpeg for full video generation")
        print("2. Run 'python gui_interface.py' for the GUI")
        print("3. Run 'python cli_interface.py \"Your text here\"' for CLI")
    else:
        print("⚠️  Some components need attention")
        print("Check the error messages above for details")
    
    print("=" * 50)

if __name__ == "__main__":
    main()
