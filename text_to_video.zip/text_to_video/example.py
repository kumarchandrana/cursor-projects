"""
Example usage of the text-to-video pipeline
"""

from text_to_video_pipeline import TextToVideoPipeline

def example_automatic_mode():
    """Example of automatic mode"""
    print("=== Automatic Mode Example ===")
    
    # Sample text
    text = """
    Welcome to the Text to Video Generator!
    
    This amazing tool can convert any text into a professional-looking video.
    It supports multiple animation styles and automatically synchronizes audio with visuals.
    
    You can use it for:
    - Educational content
    - Social media posts
    - Presentations
    - Marketing videos
    
    The process is simple: just enter your text and let the AI do the rest!
    """
    
    # Initialize pipeline
    pipeline = TextToVideoPipeline()
    
    # Generate video automatically
    result = pipeline.automatic_mode(
        text=text,
        title="Text to Video Demo",
        animation_type="simple"  # Try "typing" or "slides" too
    )
    
    if result['success']:
        print(f"✅ Video generated successfully!")
        print(f"📹 Final Video: {result['final_video']}")
        print(f"⏱️  Processing Time: {result['processing_time']:.2f} seconds")
        print(f"🎵 Duration: {result['total_duration']:.2f} seconds")
    else:
        print(f"❌ Error: {result['error']}")

def example_semi_manual_mode():
    """Example of semi-manual mode"""
    print("\n=== Semi-Manual Mode Example ===")
    
    # Sample text
    text = """
    This is a demonstration of the semi-manual mode.
    
    In this mode, you get separate components that you can adjust manually.
    This gives you more control over the final output.
    
    You can:
    - Choose different animation styles
    - Adjust timing manually
    - Mix and match components
    - Fine-tune synchronization
    """
    
    # Initialize pipeline
    pipeline = TextToVideoPipeline()
    
    # Generate components
    result = pipeline.semi_manual_mode(
        text=text,
        title="Semi-Manual Demo"
    )
    
    if result['success']:
        print(f"✅ Components generated successfully!")
        print(f"🎵 Audio Files: {len(result['audio_files'])} files")
        print(f"🎬 Animation Options: {len(result['animations'])} styles")
        print(f"📝 Subtitle File: {result['subtitle_file']}")
        
        # Show available animations
        print("\nAvailable animations:")
        for name, path in result['animations'].items():
            print(f"  - {name}: {path}")
        
        # Example of manual synchronization
        print("\n--- Manual Synchronization Example ---")
        selected_animation = "simple"  # Choose animation style
        animation_path = result['animations'][selected_animation]
        
        # Synchronize manually
        synchronized = pipeline.manual_sync(
            audio_files=result['audio_files'],
            animation_path=animation_path,
            output_path="example_manual_sync.mp4"
        )
        
        if synchronized:
            print(f"✅ Manual sync completed: {synchronized}")
        else:
            print("❌ Manual sync failed")
    else:
        print(f"❌ Error: {result['error']}")

def example_different_animations():
    """Example showing different animation styles"""
    print("\n=== Different Animation Styles Example ===")
    
    text = "This is a test of different animation styles."
    
    pipeline = TextToVideoPipeline()
    
    # Test different animation types
    animation_types = ["simple", "typing", "slides"]
    
    for anim_type in animation_types:
        print(f"\n--- Testing {anim_type} animation ---")
        result = pipeline.automatic_mode(
            text=text,
            title=f"{anim_type.title()} Animation",
            animation_type=anim_type
        )
        
        if result['success']:
            print(f"✅ {anim_type} animation generated: {result['final_video']}")
        else:
            print(f"❌ {anim_type} animation failed: {result['error']}")

def example_batch_processing():
    """Example of batch processing multiple texts"""
    print("\n=== Batch Processing Example ===")
    
    texts = [
        "First video: Welcome to our channel!",
        "Second video: Today we'll learn about Python programming.",
        "Third video: Let's create amazing videos together!"
    ]
    
    pipeline = TextToVideoPipeline()
    
    for i, text in enumerate(texts, 1):
        print(f"\n--- Processing video {i} ---")
        result = pipeline.automatic_mode(
            text=text,
            title=f"Batch Video {i}",
            animation_type="simple"
        )
        
        if result['success']:
            print(f"✅ Video {i} generated: {result['final_video']}")
        else:
            print(f"❌ Video {i} failed: {result['error']}")

if __name__ == "__main__":
    print("Text to Video Generator - Examples")
    print("=" * 50)
    
    try:
        # Run examples
        example_automatic_mode()
        example_semi_manual_mode()
        example_different_animations()
        example_batch_processing()
        
        print("\n" + "=" * 50)
        print("All examples completed!")
        print("Check the 'output' folder for generated videos.")
        
    except KeyboardInterrupt:
        print("\n⚠️  Examples cancelled by user")
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        print("Make sure you have installed all dependencies:")
        print("pip install -r requirements.txt")
