# Text to Video Generator

A comprehensive Python application that converts text into animated videos with both automatic and semi-manual modes. Perfect for creating educational content, presentations, or social media videos.

## Features

### 🚀 Automatic Mode
- **One-click generation**: Enter text → Get video
- **Multiple animation styles**: Simple text, typing effect, slide show
- **Automatic synchronization**: Audio and animation perfectly timed
- **Built-in subtitles**: Automatically generated and synced
- **High-quality output**: 1080p MP4 videos

### 🎛️ Semi-Manual Mode
- **Component generation**: Separate audio, animation, and subtitle files
- **Manual adjustment**: Fine-tune timing and synchronization
- **Multiple animation options**: Choose from different styles
- **Flexible workflow**: Mix and match components as needed

## Installation

### Prerequisites
- Python 3.8 or higher
- FFmpeg (for video processing)

### Install FFmpeg

**Windows:**
```bash
# Using chocolatey
choco install ffmpeg

# Or download from https://ffmpeg.org/download.html
```

**macOS:**
```bash
# Using homebrew
brew install ffmpeg
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install ffmpeg

# CentOS/RHEL
sudo yum install ffmpeg
```

### Install Python Dependencies

```bash
pip install -r requirements.txt
```

## Usage

### GUI Interface (Recommended)

Launch the graphical interface:

```bash
python gui_interface.py
```

**Features:**
- Easy text input with large text area
- Mode selection (Automatic/Semi-Manual)
- Animation style selection
- File loading and saving
- Real-time progress tracking
- Results display with file paths

### Command Line Interface

#### Automatic Mode

```bash
# Basic usage
python cli_interface.py "Your text here"

# With title and animation style
python cli_interface.py "Your text here" --title "My Video" --animation typing

# Specify output directory
python cli_interface.py "Your text here" --output ./my_videos --cleanup
```

#### Semi-Manual Mode

```bash
# Generate components for manual adjustment
python cli_interface.py "Your text here" --mode semi_manual

# Manual synchronization
python cli_interface.py --manual_sync animation.mp4 audio1.mp3 audio2.mp3
```

### Programmatic Usage

```python
from text_to_video_pipeline import TextToVideoPipeline

# Initialize pipeline
pipeline = TextToVideoPipeline()

# Automatic mode
result = pipeline.automatic_mode(
    text="Your text here",
    title="Video Title",
    animation_type="simple"  # or "typing" or "slides"
)

# Semi-manual mode
result = pipeline.semi_manual_mode(
    text="Your text here",
    title="Video Title"
)

# Manual synchronization
synchronized_video = pipeline.manual_sync(
    audio_files=result['audio_files'],
    animation_path=result['animations']['simple'],
    output_path="final_video.mp4"
)
```

## Configuration

Edit `config.py` to customize:

### Audio Settings
```python
AUDIO_SETTINGS = {
    'lang': 'en',        # Language code
    'slow': False,       # Slow speech
    'tld': 'com'         # Top-level domain
}
```

### Video Settings
```python
VIDEO_SETTINGS = {
    'fps': 30,                    # Frames per second
    'resolution': (1920, 1080),   # Video resolution
    'duration_per_word': 0.5,     # Seconds per word
    'background_color': '#1a1a1a', # Background color
    'text_color': '#ffffff'       # Text color
}
```

### Animation Settings
```python
ANIMATION_SETTINGS = {
    'text_size': 48,           # Text font size
    'title_size': 72,          # Title font size
    'margin': 0.1,             # Page margin
    'fade_duration': 0.5,      # Fade in/out duration
    'slide_duration': 2.0      # Slide display duration
}
```

## File Structure

```
text_to_video/
├── requirements.txt          # Python dependencies
├── config.py                # Configuration settings
├── tts_module.py            # Text-to-speech functionality
├── animation_module.py      # Animation generation
├── video_sync.py           # Video synchronization
├── text_to_video_pipeline.py # Main pipeline
├── gui_interface.py        # Graphical interface
├── cli_interface.py        # Command-line interface
├── output/                 # Generated videos
├── temp/                   # Temporary files
└── README.md              # This file
```

## Animation Styles

### Simple Text
- Clean, centered text display
- Fade-in animation
- Suitable for most content

### Typing Effect
- Character-by-character typing animation
- Realistic typing speed
- Great for code or step-by-step content

### Slide Show
- Sentence-by-sentence display
- Smooth transitions between slides
- Perfect for presentations

## Troubleshooting

### Common Issues

**1. FFmpeg not found**
```
Error: FFmpeg not found
```
**Solution:** Install FFmpeg and ensure it's in your system PATH.

**2. Audio generation fails**
```
Error generating speech: [Errno 11001] getaddrinfo failed
```
**Solution:** Check your internet connection. gTTS requires internet access.

**3. Manim rendering issues**
```
Error creating text animation: ...
```
**Solution:** Ensure you have the latest version of Manim and all dependencies.

**4. Memory issues with large texts**
```
Error: Out of memory
```
**Solution:** Split large texts into smaller chunks or increase system memory.

### Performance Tips

1. **Use shorter texts** for faster processing
2. **Choose simple animations** for quicker rendering
3. **Clean up temp files** regularly
4. **Close other applications** during video generation

## Advanced Usage

### Custom Animation Styles

Create custom animations by extending the `TextAnimation` class:

```python
from animation_module import TextAnimation

class CustomAnimation(TextAnimation):
    def create_custom_scene(self, text, output_path):
        # Your custom animation logic here
        pass
```

### Batch Processing

Process multiple texts:

```python
texts = ["Text 1", "Text 2", "Text 3"]
pipeline = TextToVideoPipeline()

for i, text in enumerate(texts):
    result = pipeline.automatic_mode(text, f"Video {i+1}")
    if result['success']:
        print(f"Generated: {result['final_video']}")
```

### API Integration

Integrate with web APIs:

```python
def generate_video_from_api(api_text):
    pipeline = TextToVideoPipeline()
    return pipeline.automatic_mode(api_text)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is open source and available under the MIT License.

## Support

For issues and questions:
1. Check the troubleshooting section
2. Search existing issues
3. Create a new issue with detailed information

## Changelog

### Version 1.0.0
- Initial release
- Automatic and semi-manual modes
- GUI and CLI interfaces
- Multiple animation styles
- Audio synchronization
- Subtitle generation
