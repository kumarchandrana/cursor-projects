"""
Simple video creator that works without FFmpeg
Creates a basic video by combining audio and static image
"""

import os
import time
from PIL import Image, ImageDraw, ImageFont
from tts_module import TextToSpeech
from simple_animation import SimpleAnimation
from config import OUTPUT_SETTINGS, VIDEO_SETTINGS

class SimpleVideoCreator:
    def __init__(self):
        self.tts = TextToSpeech()
        self.animator = SimpleAnimation()
        self.output_settings = OUTPUT_SETTINGS
        
    def create_simple_video(self, text, title=None, language='en', voice_style='normal'):
        """
        Create a simple video without FFmpeg
        
        Args:
            text (str): Text content
            title (str, optional): Title
            language (str): Language code (e.g., 'en', 'hi', 'or')
            voice_style (str): Voice style ('normal', 'funny', 'deep', 'fast')
            
        Returns:
            dict: Results with file paths
        """
        try:
            print("🎬 Creating Simple Video (No FFmpeg Required)")
            print("=" * 50)
            
            # Create output directories
            os.makedirs(self.output_settings['output_dir'], exist_ok=True)
            os.makedirs(self.output_settings['temp_dir'], exist_ok=True)
            
            # Step 1: Generate speech
            print(f"Step 1: Generating speech in {language} with {voice_style} voice...")
            audio_result = self.tts.generate_speech_with_timing(text, language=language, voice_style=voice_style)
            
            if not audio_result:
                raise Exception("Failed to generate speech")
            
            print(f"✅ Generated {len(audio_result['audio_files'])} audio segments")
            print(f"⏱️  Total duration: {audio_result['total_duration']:.2f} seconds")
            
            # Step 2: Create text image
            print("Step 2: Creating text image...")
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            image_path = os.path.join(self.output_settings['temp_dir'], f'text_image_{timestamp}.png')
            
            image_result = self.animator.create_text_image(text, title, image_path)
            
            if not image_result:
                raise Exception("Failed to create text image")
            
            print(f"✅ Created text image: {image_result}")
            
            # Step 3: Create video script
            print("Step 3: Creating video script...")
            script_path = os.path.join(self.output_settings['output_dir'], f'video_script_{timestamp}.txt')
            
            with open(script_path, 'w', encoding='utf-8') as f:
                f.write(f"VIDEO SCRIPT - {timestamp}\n")
                f.write("=" * 50 + "\n\n")
                
                if title:
                    f.write(f"TITLE: {title}\n\n")
                
                f.write("TEXT CONTENT:\n")
                f.write(text)
                f.write(f"\n\nAUDIO DURATION: {audio_result['total_duration']:.2f} seconds")
                f.write(f"\nAUDIO SEGMENTS: {len(audio_result['audio_files'])}")
                f.write(f"\nTEXT IMAGE: {image_result}")
                
                f.write(f"\n\nAUDIO FILES:\n")
                for i, audio_info in enumerate(audio_result['audio_files']):
                    f.write(f"  {i+1}. {audio_info['text'][:50]}... ({audio_info['duration']:.2f}s)\n")
                
                f.write(f"\n\nINSTRUCTIONS FOR VIDEO CREATION:\n")
                f.write("1. Import the text image into your video editor\n")
                f.write("2. Import all audio files in sequence\n")
                f.write("3. Sync the audio with the image\n")
                f.write("4. Export as MP4 video\n")
                f.write(f"\nTotal duration: {audio_result['total_duration']:.2f} seconds")
            
            print(f"✅ Created video script: {script_path}")
            
            # Step 4: Create simple HTML video player
            print("Step 4: Creating HTML video player...")
            html_path = os.path.join(self.output_settings['output_dir'], f'video_player_{timestamp}.html')
            
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(f"""
<!DOCTYPE html>
<html>
<head>
    <title>Text to Video - {title or 'Untitled'}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #1a1a1a; color: white; }}
        .container {{ max-width: 1200px; margin: 0 auto; }}
        .video-area {{ text-align: center; margin: 20px 0; }}
        .text-image {{ max-width: 100%; height: auto; border: 2px solid #333; }}
        .audio-controls {{ margin: 20px 0; }}
        .audio-file {{ margin: 10px 0; padding: 10px; background: #333; border-radius: 5px; }}
        .script {{ background: #222; padding: 20px; border-radius: 5px; margin: 20px 0; }}
        h1, h2 {{ color: #4CAF50; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🎬 Text to Video Generator</h1>
        <h2>Title: {title or 'Untitled'}</h2>
        
        <div class="video-area">
            <img src="../temp/{os.path.basename(image_result)}" alt="Text Image" class="text-image">
        </div>
        
        <div class="audio-controls">
            <h2>🎵 Audio Files</h2>
""")
                
                for i, audio_info in enumerate(audio_result['audio_files']):
                    f.write(f"""
            <div class="audio-file">
                <h3>Segment {i+1}</h3>
                <p><strong>Text:</strong> {audio_info['text']}</p>
                <p><strong>Duration:</strong> {audio_info['duration']:.2f} seconds</p>
                <audio controls>
                    <source src="../temp/{os.path.basename(audio_info['path'])}" type="audio/mpeg">
                    Your browser does not support the audio element.
                </audio>
            </div>
""")
                
                f.write(f"""
        </div>
        
        <div class="script">
            <h2>📝 Full Text Script</h2>
            <p><strong>Total Duration:</strong> {audio_result['total_duration']:.2f} seconds</p>
            <p><strong>Text Content:</strong></p>
            <p style="white-space: pre-line; background: #111; padding: 15px; border-radius: 3px;">{text}</p>
        </div>
        
        <div class="script">
            <h2>🎬 Video Creation Instructions</h2>
            <ol>
                <li>Download the text image and audio files</li>
                <li>Import them into your video editor (e.g., DaVinci Resolve, Adobe Premiere, or even Windows Movie Maker)</li>
                <li>Place the image as the video track</li>
                <li>Add the audio files in sequence</li>
                <li>Export as MP4 video</li>
            </ol>
            <p><strong>Note:</strong> This creates a static image video. For animated text, install FFmpeg and use the full pipeline.</p>
        </div>
    </div>
</body>
</html>
""")
            
            print(f"✅ Created HTML player: {html_path}")
            
            # Results
            print("\n" + "=" * 50)
            print("🎉 Simple Video Created Successfully!")
            print("=" * 50)
            print(f"📝 Video Script: {script_path}")
            print(f"🖼️  Text Image: {image_result}")
            print(f"🌐 HTML Player: {html_path}")
            print(f"🎵 Audio Files: {len(audio_result['audio_files'])} segments")
            print(f"⏱️  Total Duration: {audio_result['total_duration']:.2f} seconds")
            
            print(f"\n📁 Files created in: {self.output_settings['output_dir']}")
            print(f"📁 Audio files in: {self.output_settings['temp_dir']}")
            
            return {
                'success': True,
                'script_file': script_path,
                'image_file': image_result,
                'html_player': html_path,
                'audio_files': audio_result['audio_files'],
                'total_duration': audio_result['total_duration'],
                'text': text,
                'title': title
            }
            
        except Exception as e:
            print(f"❌ Error creating simple video: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

def main():
    """Test the simple video creator"""
    creator = SimpleVideoCreator()
    
    text = """
    Welcome to the Text to Video Generator!
    
    This amazing tool can convert any text into a professional-looking video.
    It supports multiple animation styles and automatically synchronizes audio with visuals.
    
    You can use it for:
    - Educational content
    - Social media posts
    - Presentations
    - Marketing videos
    
    The process is simple: just enter your text and let the AI do the rest!
    """
    
    result = creator.create_simple_video(text, "Text to Video Demo")
    
    if result['success']:
        print(f"\n🎬 Open the HTML file to view your video: {result['html_player']}")
    else:
        print(f"\n❌ Error: {result['error']}")

if __name__ == "__main__":
    main()
