"""
Configuration settings for the text-to-video pipeline
"""

# Audio settings
AUDIO_SETTINGS = {
    'lang': 'en',
    'slow': False,
    'tld': 'com'
}

# Voice styles with enhanced natural settings
VOICE_STYLES = {
    'normal': {
        'name': 'Natural Narration',
        'description': 'Clear, professional news-reading style with natural flow',
        'slow': False,
        'pitch_shift': 1.0,
        'speed_multiplier': 1.0,
        'enhancement': 'natural'
    },
    'funny': {
        'name': 'Playful Voice',
        'description': 'Energetic, cartoonish voice with natural variations',
        'slow': False,
        'pitch_shift': 1.3,
        'speed_multiplier': 1.1,
        'enhancement': 'echo'
    },
    'deep': {
        'name': 'Rich Voice',
        'description': 'Deep, warm, authoritative voice with natural resonance',
        'slow': True,
        'pitch_shift': 0.8,
        'speed_multiplier': 0.9,
        'enhancement': 'lowpass'
    },
    'fast': {
        'name': 'Energetic Voice',
        'description': 'Quick, dynamic delivery with natural rhythm',
        'slow': False,
        'pitch_shift': 1.05,
        'speed_multiplier': 1.3,
        'enhancement': 'compression'
    },
    'ancient': {
        'name': 'Ancient Oriya Voice',
        'description': 'Traditional, reverent voice with ancient characteristics',
        'slow': True,
        'pitch_shift': 0.85,
        'speed_multiplier': 0.7,
        'enhancement': 'ancient',
        'reverb': True,
        'echo': True
    }
}

# Language settings with comprehensive Indian language support
LANGUAGE_SETTINGS = {
    # International Languages
    'en': {
        'name': 'English',
        'tld': 'com',
        'slow': False
    },
    'es': {
        'name': 'Spanish',
        'tld': 'com',
        'slow': False
    },
    'fr': {
        'name': 'French',
        'tld': 'com',
        'slow': False
    },
    'de': {
        'name': 'German',
        'tld': 'com',
        'slow': False
    },
    'ar': {
        'name': 'Arabic',
        'tld': 'com',
        'slow': False
    },
    'ja': {
        'name': 'Japanese',
        'tld': 'com',
        'slow': False
    },
    'ko': {
        'name': 'Korean',
        'tld': 'com',
        'slow': False
    },
    'zh': {
        'name': 'Chinese',
        'tld': 'com',
        'slow': False
    },
    
    # Indian Languages with Offline TTS Support
    'hi': {
        'name': 'Hindi (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'bn': {
        'name': 'Bengali (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'ta': {
        'name': 'Tamil (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'te': {
        'name': 'Telugu (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'mr': {
        'name': 'Marathi (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'gu': {
        'name': 'Gujarati (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'kn': {
        'name': 'Kannada (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'ml': {
        'name': 'Malayalam (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'pa': {
        'name': 'Punjabi (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'or': {
        'name': 'Odia (Offline TTS)',
        'tld': 'com',
        'slow': True,  # Slower for more traditional, ancient feel
        'fallback': 'hi',  # Falls back to Hindi if offline TTS not available
        'ancient_voice': True,  # Special flag for ancient voice processing
        'traditional_style': True,
        'offline_tts': True,  # Uses AI4Bharat/Indic-TTS for authentic pronunciation
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'as': {
        'name': 'Assamese (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'ne': {
        'name': 'Nepali (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    },
    'ur': {
        'name': 'Urdu (Offline TTS)',
        'tld': 'com',
        'slow': False,
        'offline_tts': True,
        'authentic_pronunciation': True,
        'indian_language': True
    }
}

# Video settings
VIDEO_SETTINGS = {
    'fps': 30,
    'resolution': (1920, 1080),
    'duration_per_word': 0.5,  # seconds per word for timing
    'background_color': '#1a1a1a',
    'text_color': '#ffffff'
}

# Animation settings
ANIMATION_SETTINGS = {
    'text_size': 48,
    'title_size': 72,
    'margin': 0.1,
    'fade_duration': 0.5,
    'slide_duration': 2.0,
    'background_color': '#1a1a1a',
    'text_color': '#ffffff'
}

# Output settings
OUTPUT_SETTINGS = {
    'output_dir': 'output',
    'temp_dir': 'temp',
    'audio_format': 'mp3',
    'video_format': 'mp4'
}
