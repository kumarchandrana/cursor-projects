"""
Simple GUI interface for the text-to-video pipeline
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import os
from text_to_video_pipeline import TextToVideoPipeline

class TextToVideoGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Text to Video Generator")
        self.root.geometry("800x600")
        
        # Initialize pipeline
        self.pipeline = TextToVideoPipeline()
        
        # Create GUI elements
        self.create_widgets()
        
    def create_widgets(self):
        """Create and arrange GUI widgets"""
        
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="Text to Video Generator", font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Mode selection
        mode_frame = ttk.LabelFrame(main_frame, text="Generation Mode", padding="10")
        mode_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.mode_var = tk.StringVar(value="automatic")
        ttk.Radiobutton(mode_frame, text="Automatic (Text → Video)", variable=self.mode_var, value="automatic").grid(row=0, column=0, sticky=tk.W)
        ttk.Radiobutton(mode_frame, text="Semi-Manual (Adjust after generation)", variable=self.mode_var, value="semi_manual").grid(row=1, column=0, sticky=tk.W)
        
        # Animation type (for automatic mode)
        self.animation_var = tk.StringVar(value="simple")
        animation_frame = ttk.LabelFrame(main_frame, text="Animation Style", padding="10")
        animation_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        ttk.Radiobutton(animation_frame, text="Simple Text", variable=self.animation_var, value="simple").grid(row=0, column=0, sticky=tk.W)
        ttk.Radiobutton(animation_frame, text="Typing Effect", variable=self.animation_var, value="typing").grid(row=0, column=1, sticky=tk.W)
        ttk.Radiobutton(animation_frame, text="Slide Show", variable=self.animation_var, value="slides").grid(row=0, column=2, sticky=tk.W)
        
        # Voice and Language settings
        voice_frame = ttk.LabelFrame(main_frame, text="Voice & Language Settings", padding="10")
        voice_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Language selection
        ttk.Label(voice_frame, text="Language:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.language_var = tk.StringVar(value="en")
        language_combo = ttk.Combobox(voice_frame, textvariable=self.language_var, 
                                     values=["en", "hi", "bn", "ta", "te", "mr", "gu", "kn", "ml", "pa", "or", "as", "ne", "ur", "es", "fr", "de", "ar", "ja", "ko", "zh"],
                                     state="readonly", width=10)
        language_combo.grid(row=0, column=1, sticky=tk.W, padx=(0, 20))
        
        # Voice style selection
        ttk.Label(voice_frame, text="Voice Style:").grid(row=0, column=2, sticky=tk.W, padx=(0, 10))
        self.voice_style_var = tk.StringVar(value="normal")
        voice_combo = ttk.Combobox(voice_frame, textvariable=self.voice_style_var,
                                  values=["normal", "funny", "deep", "fast", "ancient"],
                                  state="readonly", width=15)
        voice_combo.grid(row=0, column=3, sticky=tk.W)
        
        # Update language names for display
        language_names = {
            "en": "English", 
            "hi": "Hindi (Offline TTS)", "bn": "Bengali (Offline TTS)", "ta": "Tamil (Offline TTS)", 
            "te": "Telugu (Offline TTS)", "mr": "Marathi (Offline TTS)", "gu": "Gujarati (Offline TTS)", 
            "kn": "Kannada (Offline TTS)", "ml": "Malayalam (Offline TTS)", "pa": "Punjabi (Offline TTS)", 
            "or": "Odia (Offline TTS)", "as": "Assamese (Offline TTS)", "ne": "Nepali (Offline TTS)", 
            "ur": "Urdu (Offline TTS)", 
            "es": "Spanish", "fr": "French", "de": "German", "ar": "Arabic", 
            "ja": "Japanese", "ko": "Korean", "zh": "Chinese"
        }
        voice_names = {
            "normal": "Natural Narration", "funny": "Playful Voice",
            "deep": "Rich Voice", "fast": "Energetic Voice", "ancient": "Ancient Oriya Voice"
        }
        
        # Set display values
        language_combo['values'] = [f"{code} - {language_names.get(code, code)}" for code in language_combo['values']]
        voice_combo['values'] = [f"{code} - {voice_names.get(code, code)}" for code in voice_combo['values']]
        
        # Set initial display values
        language_combo.set("en - English")
        voice_combo.set("normal - Normal Narration")
        
        # Store references to comboboxes for later use
        self.language_combo = language_combo
        self.voice_combo = voice_combo
        
        # Title input
        ttk.Label(main_frame, text="Title (Optional):").grid(row=4, column=0, sticky=tk.W, pady=(0, 5))
        self.title_entry = ttk.Entry(main_frame, width=50)
        self.title_entry.grid(row=4, column=1, sticky=(tk.W, tk.E), pady=(0, 5))
        
        # Text input
        ttk.Label(main_frame, text="Text to Convert:").grid(row=5, column=0, sticky=(tk.W, tk.N), pady=(0, 5))
        self.text_area = scrolledtext.ScrolledText(main_frame, width=60, height=10, wrap=tk.WORD)
        self.text_area.grid(row=5, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Buttons frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=6, column=0, columnspan=2, pady=(0, 10))
        
        # Generate button
        self.generate_btn = ttk.Button(button_frame, text="Generate Video", command=self.generate_video)
        self.generate_btn.grid(row=0, column=0, padx=(0, 10))
        
        # Load text button
        ttk.Button(button_frame, text="Load Text File", command=self.load_text_file).grid(row=0, column=1, padx=(0, 10))
        
        # Clear button
        ttk.Button(button_frame, text="Clear", command=self.clear_inputs).grid(row=0, column=2, padx=(0, 10))
        
        # Refresh button
        refresh_btn = ttk.Button(button_frame, text="Refresh", command=self.refresh_page)
        refresh_btn.grid(row=0, column=3, padx=(0, 10))
        
        # Add tooltip for refresh button
        self._create_tooltip(refresh_btn, "Refresh page (F5 or Ctrl+R)\nClears all inputs and resets to defaults")
        
        # Open output folder button
        ttk.Button(button_frame, text="Open Output Folder", command=self.open_output_folder).grid(row=0, column=4)
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, mode='indeterminate')
        self.progress.grid(row=7, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Status label
        self.status_label = ttk.Label(main_frame, text="Ready to generate video")
        self.status_label.grid(row=8, column=0, columnspan=2, sticky=tk.W)
        
        # Results frame
        self.results_frame = ttk.LabelFrame(main_frame, text="Results", padding="10")
        self.results_frame.grid(row=9, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(10, 0))
        
        # Configure grid weights for resizing
        main_frame.rowconfigure(5, weight=1)
        main_frame.rowconfigure(9, weight=1)
        
        # Bind keyboard shortcuts
        self.root.bind('<F5>', lambda event: self.refresh_page())
        self.root.bind('<Control-r>', lambda event: self.refresh_page())
        
    def generate_video(self):
        """Generate video based on selected mode"""
        text = self.text_area.get("1.0", tk.END).strip()
        if not text:
            messagebox.showerror("Error", "Please enter some text to convert")
            return
        
        title = self.title_entry.get().strip() or None
        mode = self.mode_var.get()
        
        # Get language and voice style
        language = self.language_var.get().split(' - ')[0]  # Extract code from "code - name"
        voice_style = self.voice_style_var.get().split(' - ')[0]  # Extract code from "code - name"
        
        # Check if language is supported
        from config import LANGUAGE_SETTINGS
        if language not in LANGUAGE_SETTINGS:
            messagebox.showerror(
                "Unsupported Language", 
                f"Language '{language}' is not supported by Google Text-to-Speech.\n\n"
                f"Supported languages include:\n"
                f"• English (en)\n"
                f"• Hindi (hi)\n"
                f"• Bengali (bn)\n"
                f"• Tamil (ta)\n"
                f"• Telugu (te)\n"
                f"• Marathi (mr)\n"
                f"• Gujarati (gu)\n"
                f"• Kannada (kn)\n"
                f"• Malayalam (ml)\n"
                f"• Punjabi (pa)\n\n"
                f"Please select a supported language and try again."
            )
            return
        
        # Disable generate button and start progress
        self.generate_btn.config(state='disabled')
        self.progress.start()
        self.status_label.config(text="Generating video...")
        
        # Run generation in separate thread
        thread = threading.Thread(target=self._generate_video_thread, args=(text, title, mode, language, voice_style))
        thread.daemon = True
        thread.start()
    
    def _generate_video_thread(self, text, title, mode, language, voice_style):
        """Generate video in separate thread"""
        try:
            print(f"GUI: Starting video generation with language: {language}, voice_style: {voice_style}")
            if mode == "automatic":
                animation_type = self.animation_var.get()
                result = self.pipeline.automatic_mode(text, title, animation_type, language, voice_style)
            else:  # semi_manual
                result = self.pipeline.semi_manual_mode(text, title, language, voice_style)
            
            print(f"GUI: Pipeline result: {result}")
            print(f"GUI: Result success: {result.get('success') if result else 'None'}")
            
            # Update UI in main thread
            self.root.after(0, self._update_results, result)
            
        except Exception as e:
            print(f"GUI: Exception in video generation: {str(e)}")
            print(f"GUI: Exception type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            self.root.after(0, self._show_error, str(e))
    
    def _update_results(self, result):
        """Update UI with results"""
        print(f"GUI: _update_results called with result: {result}")
        self.progress.stop()
        self.generate_btn.config(state='normal')
        
        if result and result.get('success'):
            print(f"GUI: Success! Fallback mode: {result.get('fallback_mode')}")
            if result.get('fallback_mode'):
                self.status_label.config(text="Video components generated successfully! (Fallback mode)")
            else:
                self.status_label.config(text="Video generated successfully!")
            self._display_results(result)
        else:
            print(f"GUI: Failed result: {result}")
            self.status_label.config(text="Error generating video")
            error_msg = result.get('error', 'Unknown error') if result else 'No result returned'
            messagebox.showerror("Error", error_msg)
    
    def _show_error(self, error_msg):
        """Show error message"""
        self.progress.stop()
        self.generate_btn.config(state='normal')
        self.status_label.config(text="Error generating video")
        
        # Provide more helpful error messages
        if "Failed to create animation" in error_msg:
            detailed_msg = f"{error_msg}\n\nThis usually means:\n• Manim is not properly installed\n• FFmpeg is missing\n• Dependencies are not available\n\nThe system will try to use a simple fallback mode."
        else:
            detailed_msg = error_msg
            
        messagebox.showerror("Error", detailed_msg)
    
    def _display_results(self, result):
        """Display generation results"""
        # Clear previous results
        for widget in self.results_frame.winfo_children():
            widget.destroy()
        
        if 'final_video' in result:
            # Automatic mode results (full video)
            ttk.Label(self.results_frame, text="Generated Files:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
            
            ttk.Label(self.results_frame, text=f"Final Video: {result['final_video']}").grid(row=1, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Processing Time: {result['processing_time']:.2f} seconds").grid(row=2, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Duration: {result['total_duration']:.2f} seconds").grid(row=3, column=0, sticky=tk.W)
            
            # Open video button
            ttk.Button(self.results_frame, text="Open Video", 
                      command=lambda: os.startfile(result['final_video'])).grid(row=4, column=0, pady=(10, 0))
        
        elif 'html_player' in result:
            # Fallback mode results
            ttk.Label(self.results_frame, text="Generated Components:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
            
            ttk.Label(self.results_frame, text=f"HTML Player: {result['html_player']}").grid(row=1, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Video Script: {result['script_file']}").grid(row=2, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Text Image: {result['image_file']}").grid(row=3, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Audio Files: {len(result['audio_files'])} files").grid(row=4, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Total Duration: {result['total_duration']:.2f} seconds").grid(row=5, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Processing Time: {result['processing_time']:.2f} seconds").grid(row=6, column=0, sticky=tk.W)
            
            if result.get('fallback_mode'):
                ttk.Label(self.results_frame, text="Note: Fallback mode - Install FFmpeg for full video generation", 
                         foreground="orange").grid(row=7, column=0, sticky=tk.W, pady=(5, 0))
            
            # Open HTML player button
            ttk.Button(self.results_frame, text="Open HTML Player", 
                      command=lambda: os.startfile(result['html_player'])).grid(row=8, column=0, pady=(10, 0))
            
            # Open output folder button
            ttk.Button(self.results_frame, text="Open Output Folder", 
                      command=lambda: os.startfile(os.path.dirname(result['html_player']))).grid(row=9, column=0, pady=(5, 0))
        
        else:
            # Semi-manual mode results
            ttk.Label(self.results_frame, text="Generated Components:", font=("Arial", 10, "bold")).grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
            
            ttk.Label(self.results_frame, text=f"Audio Files: {len(result['audio_files'])} files").grid(row=1, column=0, sticky=tk.W)
            if 'animations' in result:
                ttk.Label(self.results_frame, text=f"Animation Options: {len(result['animations'])} styles").grid(row=2, column=0, sticky=tk.W)
            if 'subtitle_file' in result:
                ttk.Label(self.results_frame, text=f"Subtitle File: {result['subtitle_file']}").grid(row=3, column=0, sticky=tk.W)
            ttk.Label(self.results_frame, text=f"Total Duration: {result['total_duration']:.2f} seconds").grid(row=4, column=0, sticky=tk.W)
            
            # Manual sync button
            if 'animations' in result:
                ttk.Button(self.results_frame, text="Manual Sync Options", 
                          command=lambda: self._show_manual_sync_options(result)).grid(row=5, column=0, pady=(10, 0))
    
    def _show_manual_sync_options(self, result):
        """Show manual synchronization options"""
        sync_window = tk.Toplevel(self.root)
        sync_window.title("Manual Synchronization")
        sync_window.geometry("600x400")
        
        # Animation selection
        ttk.Label(sync_window, text="Select Animation Style:").grid(row=0, column=0, sticky=tk.W, pady=10)
        animation_var = tk.StringVar(value=list(result['animations'].keys())[0])
        animation_combo = ttk.Combobox(sync_window, textvariable=animation_var, 
                                     values=list(result['animations'].keys()), state="readonly")
        animation_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(10, 0), pady=10)
        
        # Sync button
        def sync_video():
            selected_animation = animation_var.get()
            animation_path = result['animations'][selected_animation]
            output_path = os.path.join(self.pipeline.output_settings['output_dir'], 
                                     f'manual_sync_{selected_animation}.mp4')
            
            synchronized = self.pipeline.manual_sync(result['audio_files'], animation_path, output_path)
            if synchronized:
                messagebox.showinfo("Success", f"Video synchronized: {synchronized}")
                os.startfile(synchronized)
            else:
                messagebox.showerror("Error", "Failed to synchronize video")
        
        ttk.Button(sync_window, text="Synchronize Video", command=sync_video).grid(row=1, column=0, columnspan=2, pady=20)
        
        sync_window.columnconfigure(1, weight=1)
    
    def load_text_file(self):
        """Load text from file"""
        file_path = filedialog.askopenfilename(
            title="Select Text File",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    content = file.read()
                    self.text_area.delete("1.0", tk.END)
                    self.text_area.insert("1.0", content)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load file: {str(e)}")
    
    def clear_inputs(self):
        """Clear all inputs"""
        self.text_area.delete("1.0", tk.END)
        self.title_entry.delete(0, tk.END)
        
        # Clear results
        for widget in self.results_frame.winfo_children():
            widget.destroy()
        
        self.status_label.config(text="Ready to generate video")
    
    def refresh_page(self):
        """Refresh the entire page - clear all inputs and reset to defaults"""
        # Ask for confirmation if there's content
        if (self.text_area.get("1.0", tk.END).strip() or 
            self.title_entry.get().strip() or 
            len(self.results_frame.winfo_children()) > 0):
            
            result = messagebox.askyesno(
                "Confirm Refresh", 
                "This will clear all inputs and results. Are you sure you want to refresh?",
                icon='question'
            )
            if not result:
                return
        
        # Clear all inputs
        self.clear_inputs()
        
        # Reset to default values
        self.mode_var.set("automatic")
        self.animation_var.set("simple")
        self.language_var.set("en - English")
        self.voice_style_var.set("normal - Normal Narration")
        
        # Update combobox display values
        if hasattr(self, 'language_combo'):
            self.language_combo.set("en - English")
        if hasattr(self, 'voice_combo'):
            self.voice_combo.set("normal - Normal Narration")
        
        # Stop any running progress
        self.progress.stop()
        
        # Re-enable generate button
        self.generate_btn.config(state='normal')
        
        # Update status
        self.status_label.config(text="Page refreshed - Ready to generate video")
        
        print("Page refreshed successfully")
    
    def _create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        def show_tooltip(event):
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = tk.Label(tooltip, text=text, background="lightyellow", 
                           relief="solid", borderwidth=1, font=("Arial", 9))
            label.pack()
            
            widget.tooltip = tooltip
        
        def hide_tooltip(event):
            if hasattr(widget, 'tooltip'):
                widget.tooltip.destroy()
                del widget.tooltip
        
        widget.bind("<Enter>", show_tooltip)
        widget.bind("<Leave>", hide_tooltip)
    
    def open_output_folder(self):
        """Open output folder"""
        output_dir = self.pipeline.output_settings['output_dir']
        if os.path.exists(output_dir):
            os.startfile(output_dir)
        else:
            messagebox.showinfo("Info", "Output folder does not exist yet")

def main():
    """Main function to run the GUI"""
    root = tk.Tk()
    app = TextToVideoGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
