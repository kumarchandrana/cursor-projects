#!/usr/bin/env python3
"""
Text to Video Generator - Project Launcher
Simple launcher script to start the project
"""

import os
import sys
import subprocess

def main():
    """Main launcher function"""
    print("=" * 50)
    print("🎬 Text to Video Generator")
    print("=" * 50)
    print()
    
    print("Choose how to launch the application:")
    print("1. 🖥️  GUI Interface (Recommended)")
    print("2. 🎛️  Control Center (Index Page)")
    print("3. ⚡ Quick Start Demo")
    print("4. 🔧 CLI Interface")
    print("5. 🧪 System Test")
    print("6. 📁 Open Output Folder")
    print("0. ❌ Exit")
    print()
    
    while True:
        try:
            choice = input("Enter your choice (0-6): ").strip()
            
            if choice == '0':
                print("Goodbye! 👋")
                break
            elif choice == '1':
                print("Launching GUI Interface...")
                subprocess.run([sys.executable, 'gui_interface.py'])
                break
            elif choice == '2':
                print("Launching Control Center...")
                subprocess.run([sys.executable, 'index.py'])
                break
            elif choice == '3':
                print("Running Quick Start Demo...")
                subprocess.run([sys.executable, 'quick_start.py'])
                break
            elif choice == '4':
                print("Launching CLI Interface...")
                subprocess.run([sys.executable, 'cli_interface.py'])
                break
            elif choice == '5':
                print("Running System Test...")
                subprocess.run([sys.executable, 'simple_test.py'])
                break
            elif choice == '6':
                print("Opening Output Folder...")
                output_dir = os.path.join(os.getcwd(), 'output')
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)
                if os.name == 'nt':  # Windows
                    os.startfile(output_dir)
                elif os.name == 'posix':  # macOS and Linux
                    subprocess.run(['open', output_dir])
                break
            else:
                print("❌ Invalid choice. Please enter a number between 0-6.")
                
        except KeyboardInterrupt:
            print("\nGoodbye! 👋")
            break
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            break

if __name__ == "__main__":
    main()
