"""
Main text-to-video pipeline with automatic and semi-manual modes
"""

import os
import time
from datetime import datetime
from tts_module import TextToSpeech
from animation_module import TextAnimation
from video_sync import VideoSynchronizer
from config import OUTPUT_SETTINGS

class TextToVideoPipeline:
    def __init__(self):
        self.tts = TextToSpeech()
        self.animator = TextAnimation()
        self.synchronizer = VideoSynchronizer()
        self.output_settings = OUTPUT_SETTINGS
        
        # Create output directories
        os.makedirs(self.output_settings['output_dir'], exist_ok=True)
        os.makedirs(self.output_settings['temp_dir'], exist_ok=True)
    
    def automatic_mode(self, text, title=None, animation_type='simple', language='en', voice_style='normal'):
        """
        Fully automatic mode: text → video
        
        Args:
            text (str): Input text
            title (str, optional): Title for the video
            animation_type (str): Type of animation ('simple', 'typing', 'slides')
            language (str): Language code (e.g., 'en', 'hi', 'or')
            voice_style (str): Voice style ('normal', 'funny', 'deep', 'fast')
            
        Returns:
            dict: Results including paths to generated files
        """
        print("Starting automatic text-to-video generation...")
        start_time = time.time()
        
        try:
            # Try full video generation first
            try:
                # Step 1: Generate speech
                print(f"Step 1: Generating speech in {language} with {voice_style} voice...")
                audio_result = self.tts.generate_speech_with_timing(text, language=language, voice_style=voice_style)
                if not audio_result:
                    raise Exception(f"Failed to generate speech for language '{language}' with voice style '{voice_style}'. Check console output for detailed error information.")
                
                # Step 2: Create animation
                print("Step 2: Creating animation...")
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                animation_path = os.path.join(
                    self.output_settings['temp_dir'],
                    f'animation_{timestamp}.mp4'
                )
                
                if animation_type == 'typing':
                    animation_file = self.animator.create_typing_animation(text, animation_path)
                elif animation_type == 'slides':
                    sentences = self.tts.split_text_by_sentences(text)
                    animation_file = self.animator.create_slide_animation(sentences, animation_path)
                else:  # simple
                    animation_file = self.animator.create_text_scene(text, title, animation_path)
                
                if not animation_file:
                    raise Exception(f"Failed to create animation for type '{animation_type}'. Check if Manim is properly installed and dependencies are available.")
                
                # Step 3: Synchronize audio and animation
                print("Step 3: Synchronizing audio and animation...")
                final_video_path = os.path.join(
                    self.output_settings['output_dir'],
                    f'auto_video_{timestamp}.mp4'
                )
                
                # Use the first audio file for simple sync
                main_audio = audio_result['audio_files'][0]['path']
                synchronized_video = self.synchronizer.sync_audio_animation(
                    main_audio, animation_file, final_video_path
                )
                
                if not synchronized_video:
                    raise Exception("Failed to synchronize video")
                
                # Step 4: Add subtitles
                print("Step 4: Adding subtitles...")
                subtitle_path = os.path.join(
                    self.output_settings['temp_dir'],
                    f'subtitles_{timestamp}.srt'
                )
                self.synchronizer.create_subtitles(text, audio_result['total_duration'], subtitle_path)
                
                # Create final video with subtitles
                final_with_subtitles = os.path.join(
                    self.output_settings['output_dir'],
                    f'final_video_{timestamp}.mp4'
                )
                self.synchronizer.add_subtitles_to_video(
                    synchronized_video, subtitle_path, final_with_subtitles
                )
                
                end_time = time.time()
                processing_time = end_time - start_time
                
                print(f"Automatic generation completed in {processing_time:.2f} seconds")
                
                return {
                    'success': True,
                    'final_video': final_with_subtitles,
                    'audio_files': audio_result['audio_files'],
                    'animation_file': animation_file,
                    'subtitle_file': subtitle_path,
                    'processing_time': processing_time,
                    'total_duration': audio_result['total_duration']
                }
                
            except Exception as e:
                print(f"Full video generation failed: {str(e)}")
                print("Falling back to simple video creation...")
                
                # Fallback to simple video creation
                from simple_video_creator import SimpleVideoCreator
                simple_creator = SimpleVideoCreator()
                
                result = simple_creator.create_simple_video(text, title, language, voice_style)
                
                if result['success']:
                    end_time = time.time()
                    processing_time = end_time - start_time
                    
                    result['processing_time'] = processing_time
                    result['fallback_mode'] = True
                    
                    print(f"Simple video creation completed in {processing_time:.2f} seconds")
                    print("Note: This is a fallback mode. Install FFmpeg for full video generation.")
                
                return result
            
        except Exception as e:
            print(f"Error in automatic mode: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def semi_manual_mode(self, text, title=None, language='en', voice_style='normal'):
        """
        Semi-manual mode: Generate components for manual adjustment
        
        Args:
            text (str): Input text
            title (str, optional): Title for the video
            language (str): Language code (e.g., 'en', 'hi', 'or')
            voice_style (str): Voice style ('normal', 'funny', 'deep', 'fast')
            
        Returns:
            dict: Results with separate components for manual editing
        """
        print("Starting semi-manual text-to-video generation...")
        start_time = time.time()
        
        try:
            # Step 1: Generate speech with detailed timing
            print(f"Step 1: Generating speech with timing in {language} with {voice_style} voice...")
            audio_result = self.tts.generate_speech_with_timing(text, language=language, voice_style=voice_style)
            if not audio_result:
                raise Exception("Failed to generate speech")
            
            # Step 2: Create multiple animation options
            print("Step 2: Creating animation options...")
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Create different animation styles
            animations = {}
            
            # Simple text animation
            simple_path = os.path.join(
                self.output_settings['temp_dir'],
                f'simple_animation_{timestamp}.mp4'
            )
            animations['simple'] = self.animator.create_text_scene(text, title, simple_path)
            
            # Typing animation
            typing_path = os.path.join(
                self.output_settings['temp_dir'],
                f'typing_animation_{timestamp}.mp4'
            )
            animations['typing'] = self.animator.create_typing_animation(text, typing_path)
            
            # Slide animation
            sentences = self.tts.split_text_by_sentences(text)
            slide_path = os.path.join(
                self.output_settings['temp_dir'],
                f'slide_animation_{timestamp}.mp4'
            )
            animations['slides'] = self.animator.create_slide_animation(sentences, slide_path)
            
            # Step 3: Create subtitle file
            print("Step 3: Creating subtitles...")
            subtitle_path = os.path.join(
                self.output_settings['temp_dir'],
                f'subtitles_{timestamp}.srt'
            )
            self.synchronizer.create_subtitles(text, audio_result['total_duration'], subtitle_path)
            
            end_time = time.time()
            processing_time = end_time - start_time
            
            print(f"Semi-manual generation completed in {processing_time:.2f} seconds")
            print("Components ready for manual adjustment:")
            print(f"- Audio files: {len(audio_result['audio_files'])} files")
            print(f"- Animation options: {len(animations)} styles")
            print(f"- Subtitles: {subtitle_path}")
            
            return {
                'success': True,
                'audio_files': audio_result['audio_files'],
                'animations': animations,
                'subtitle_file': subtitle_path,
                'processing_time': processing_time,
                'total_duration': audio_result['total_duration'],
                'text': text,
                'title': title
            }
            
        except Exception as e:
            print(f"Error in semi-manual mode: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def manual_sync(self, audio_files, animation_path, output_path=None):
        """
        Manual synchronization of audio and animation
        
        Args:
            audio_files (list): List of audio file info
            animation_path (str): Path to animation file
            output_path (str, optional): Path to save final video
            
        Returns:
            str: Path to synchronized video
        """
        try:
            if output_path is None:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = os.path.join(
                    self.output_settings['output_dir'],
                    f'manual_sync_{timestamp}.mp4'
                )
            
            # Use the synchronizer to create the final video
            synchronized_video = self.synchronizer.create_synchronized_video_with_timing(
                audio_files, animation_path, output_path
            )
            
            return synchronized_video
            
        except Exception as e:
            print(f"Error in manual sync: {str(e)}")
            return None
    
    def cleanup_temp_files(self):
        """Clean up temporary files"""
        try:
            import shutil
            if os.path.exists(self.output_settings['temp_dir']):
                shutil.rmtree(self.output_settings['temp_dir'])
                os.makedirs(self.output_settings['temp_dir'], exist_ok=True)
                print("Temporary files cleaned up")
        except Exception as e:
            print(f"Error cleaning up temp files: {str(e)}")
    
    def get_available_animations(self):
        """Get list of available animation types"""
        return ['simple', 'typing', 'slides']
