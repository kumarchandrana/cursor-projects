"""
Video synchronization module using MoviePy
"""

import os
try:
    from moviepy.editor import *
except ImportError:
    from moviepy import *
from config import VIDEO_SETTINGS, OUTPUT_SETTINGS
import tempfile

class VideoSynchronizer:
    def __init__(self):
        self.video_settings = VIDEO_SETTINGS
        self.output_settings = OUTPUT_SETTINGS
        
    def sync_audio_animation(self, audio_path, animation_path, output_path=None):
        """
        Synchronize audio with animation
        
        Args:
            audio_path (str): Path to audio file
            animation_path (str): Path to animation video file
            output_path (str, optional): Path to save final video
            
        Returns:
            str: Path to final synchronized video
        """
        try:
            # Create output directory
            if output_path:
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
            else:
                output_path = os.path.join(
                    self.output_settings['output_dir'],
                    f'final_video.{self.output_settings["video_format"]}'
                )
                os.makedirs(self.output_settings['output_dir'], exist_ok=True)
            
            # Load audio and video
            audio_clip = AudioFileClip(audio_path)
            video_clip = VideoFileClip(animation_path)
            
            # Get durations
            audio_duration = audio_clip.duration
            video_duration = video_clip.duration
            
            # Adjust video duration to match audio
            if video_duration < audio_duration:
                # Loop video if it's shorter than audio
                loops_needed = int(audio_duration / video_duration) + 1
                video_clip = concatenate_videoclips([video_clip] * loops_needed)
                video_clip = video_clip.subclip(0, audio_duration)
            elif video_duration > audio_duration:
                # Trim video if it's longer than audio
                video_clip = video_clip.subclip(0, audio_duration)
            
            # Set audio to video
            final_video = video_clip.set_audio(audio_clip)
            
            # Write final video
            final_video.write_videofile(
                output_path,
                fps=self.video_settings['fps'],
                codec='libx264',
                audio_codec='aac'
            )
            
            # Clean up
            audio_clip.close()
            video_clip.close()
            final_video.close()
            
            print(f"Video synchronized successfully: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"Error synchronizing video: {str(e)}")
            return None
    
    def create_subtitles(self, text, audio_duration, output_path=None):
        """
        Create subtitle file for the video
        
        Args:
            text (str): Text content
            audio_duration (float): Duration of audio in seconds
            output_path (str, optional): Path to save subtitle file
            
        Returns:
            str: Path to subtitle file
        """
        try:
            if output_path is None:
                output_path = os.path.join(
                    self.output_settings['temp_dir'],
                    'subtitles.srt'
                )
            
            # Split text into sentences for subtitles
            sentences = text.split('. ')
            if len(sentences) > 1 and not sentences[-1].endswith('.'):
                sentences[-1] += '.'
            
            # Calculate timing for each sentence
            time_per_sentence = audio_duration / len(sentences)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                for i, sentence in enumerate(sentences):
                    start_time = i * time_per_sentence
                    end_time = (i + 1) * time_per_sentence
                    
                    # Convert to SRT format
                    start_srt = self._seconds_to_srt_time(start_time)
                    end_srt = self._seconds_to_srt_time(end_time)
                    
                    f.write(f"{i + 1}\n")
                    f.write(f"{start_srt} --> {end_srt}\n")
                    f.write(f"{sentence.strip()}\n\n")
            
            return output_path
            
        except Exception as e:
            print(f"Error creating subtitles: {str(e)}")
            return None
    
    def _seconds_to_srt_time(self, seconds):
        """Convert seconds to SRT time format (HH:MM:SS,mmm)"""
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        milliseconds = int((seconds % 1) * 1000)
        return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"
    
    def add_subtitles_to_video(self, video_path, subtitle_path, output_path=None):
        """
        Add subtitles to video
        
        Args:
            video_path (str): Path to video file
            subtitle_path (str): Path to subtitle file
            output_path (str, optional): Path to save video with subtitles
            
        Returns:
            str: Path to video with subtitles
        """
        try:
            if output_path is None:
                output_path = os.path.join(
                    self.output_settings['output_dir'],
                    'video_with_subtitles.mp4'
                )
            
            # Load video
            video = VideoFileClip(video_path)
            
            # Create subtitle clip
            subtitle_clip = SubtitlesClip(subtitle_path, lambda txt: TextClip(txt, font='Arial', fontsize=24, color='white'))
            
            # Composite video with subtitles
            final_video = CompositeVideoClip([video, subtitle_clip])
            
            # Write final video
            final_video.write_videofile(
                output_path,
                fps=self.video_settings['fps'],
                codec='libx264'
            )
            
            # Clean up
            video.close()
            final_video.close()
            
            return output_path
            
        except Exception as e:
            print(f"Error adding subtitles: {str(e)}")
            return None
    
    def create_synchronized_video_with_timing(self, audio_files, animation_path, output_path=None):
        """
        Create synchronized video with precise timing for each sentence
        
        Args:
            audio_files (list): List of audio file info with timing
            animation_path (str): Path to animation video
            output_path (str, optional): Path to save final video
            
        Returns:
            str: Path to final video
        """
        try:
            if output_path is None:
                output_path = os.path.join(
                    self.output_settings['output_dir'],
                    'synchronized_video.mp4'
                )
            
            # Load animation video
            animation = VideoFileClip(animation_path)
            
            # Create clips for each sentence
            clips = []
            for audio_info in audio_files:
                # Load audio
                audio = AudioFileClip(audio_info['path'])
                
                # Create text clip for this sentence
                text_clip = TextClip(
                    audio_info['text'],
                    fontsize=self.animation_settings['text_size'],
                    color=self.animation_settings['text_color'],
                    font='Arial'
                ).set_duration(audio_info['duration']).set_start(audio_info['start_time'])
                
                # Create video clip with text
                video_clip = text_clip.set_audio(audio)
                clips.append(video_clip)
            
            # Concatenate all clips
            final_video = concatenate_videoclips(clips)
            
            # Write final video
            final_video.write_videofile(
                output_path,
                fps=self.video_settings['fps'],
                codec='libx264',
                audio_codec='aac'
            )
            
            # Clean up
            for clip in clips:
                clip.close()
            final_video.close()
            
            return output_path
            
        except Exception as e:
            print(f"Error creating synchronized video: {str(e)}")
            return None
