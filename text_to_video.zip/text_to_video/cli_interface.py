"""
Command-line interface for the text-to-video pipeline
"""

import argparse
import sys
import os
from text_to_video_pipeline import TextToVideoPipeline

def main():
    """Main CLI function"""
    parser = argparse.ArgumentParser(description="Convert text to video with automatic or semi-manual modes")
    
    # Required arguments
    parser.add_argument("text", help="Text to convert to video")
    parser.add_argument("--mode", choices=["automatic", "semi_manual"], default="automatic",
                       help="Generation mode (default: automatic)")
    
    # Optional arguments
    parser.add_argument("--title", help="Title for the video")
    parser.add_argument("--animation", choices=["simple", "typing", "slides"], default="simple",
                       help="Animation type for automatic mode (default: simple)")
    parser.add_argument("--output", help="Output directory (default: ./output)")
    parser.add_argument("--temp", help="Temporary directory (default: ./temp)")
    parser.add_argument("--cleanup", action="store_true", help="Clean up temporary files after generation")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Initialize pipeline
    pipeline = TextToVideoPipeline()
    
    # Override output directories if specified
    if args.output:
        pipeline.output_settings['output_dir'] = args.output
        os.makedirs(args.output, exist_ok=True)
    
    if args.temp:
        pipeline.output_settings['temp_dir'] = args.temp
        os.makedirs(args.temp, exist_ok=True)
    
    print(f"Starting text-to-video generation in {args.mode} mode...")
    print(f"Text: {args.text[:100]}{'...' if len(args.text) > 100 else ''}")
    
    try:
        if args.mode == "automatic":
            result = pipeline.automatic_mode(args.text, args.title, args.animation)
        else:  # semi_manual
            result = pipeline.semi_manual_mode(args.text, args.title)
        
        if result['success']:
            print("\n✅ Generation completed successfully!")
            
            if 'final_video' in result:
                # Automatic mode results
                print(f"📹 Final Video: {result['final_video']}")
                print(f"⏱️  Processing Time: {result['processing_time']:.2f} seconds")
                print(f"🎵 Duration: {result['total_duration']:.2f} seconds")
                
                # Open video if on Windows
                if os.name == 'nt':
                    try:
                        os.startfile(result['final_video'])
                    except:
                        pass
            
            elif 'html_player' in result:
                # Fallback mode results
                print(f"🌐 HTML Player: {result['html_player']}")
                print(f"📝 Video Script: {result['script_file']}")
                print(f"🖼️  Text Image: {result['image_file']}")
                print(f"🎵 Audio Files: {len(result['audio_files'])} files")
                print(f"⏱️  Total Duration: {result['total_duration']:.2f} seconds")
                print(f"⏱️  Processing Time: {result['processing_time']:.2f} seconds")
                
                if result.get('fallback_mode'):
                    print("\n📝 Note: This is fallback mode. Install FFmpeg for full video generation.")
                    print("🌐 Open the HTML file to view your video with audio player.")
                
                # Open HTML player if on Windows
                if os.name == 'nt':
                    try:
                        os.startfile(result['html_player'])
                    except:
                        pass
            
            else:
                # Semi-manual mode results
                print(f"🎵 Audio Files: {len(result['audio_files'])} files")
                if 'animations' in result:
                    print(f"🎬 Animation Options: {len(result['animations'])} styles")
                    print("\nAvailable animations:")
                    for name, path in result['animations'].items():
                        print(f"  - {name}: {path}")
                if 'subtitle_file' in result:
                    print(f"📝 Subtitle File: {result['subtitle_file']}")
                print(f"⏱️  Total Duration: {result['total_duration']:.2f} seconds")
                
                print("\nTo manually synchronize, use:")
                print("python cli_interface.py --manual_sync <animation_path> <audio_files>")
        
        else:
            print(f"❌ Error: {result['error']}")
            sys.exit(1)
    
    except KeyboardInterrupt:
        print("\n⚠️  Generation cancelled by user")
        sys.exit(1)
    
    except Exception as e:
        print(f"❌ Unexpected error: {str(e)}")
        sys.exit(1)
    
    finally:
        if args.cleanup:
            pipeline.cleanup_temp_files()

def manual_sync():
    """Manual synchronization function"""
    parser = argparse.ArgumentParser(description="Manually synchronize audio and animation")
    parser.add_argument("animation_path", help="Path to animation file")
    parser.add_argument("audio_files", nargs="+", help="Paths to audio files")
    parser.add_argument("--output", help="Output path for synchronized video")
    
    args = parser.parse_args()
    
    # Initialize pipeline
    pipeline = TextToVideoPipeline()
    
    # Create audio file info
    audio_files = []
    for i, audio_path in enumerate(args.audio_files):
        if os.path.exists(audio_path):
            duration = pipeline.tts.get_audio_duration(audio_path)
            audio_files.append({
                'path': audio_path,
                'text': f"Audio segment {i+1}",
                'start_time': sum(f['duration'] for f in audio_files),
                'duration': duration,
                'end_time': sum(f['duration'] for f in audio_files) + duration
            })
        else:
            print(f"Warning: Audio file not found: {audio_path}")
    
    if not audio_files:
        print("Error: No valid audio files found")
        sys.exit(1)
    
    # Synchronize
    synchronized = pipeline.manual_sync(audio_files, args.animation_path, args.output)
    
    if synchronized:
        print(f"✅ Video synchronized: {synchronized}")
    else:
        print("❌ Failed to synchronize video")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--manual_sync":
        sys.argv.pop(1)  # Remove --manual_sync from argv
        manual_sync()
    else:
        main()
