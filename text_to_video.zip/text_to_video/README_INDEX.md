# Text to Video Generator - Control Center

## 🎛️ Index Page Overview

The **Index Page** (`index.py`) serves as the main control center for the Text to Video Generator project. It provides a comprehensive dashboard to access all features and monitor system status.

## 🚀 How to Launch

### Option 1: Direct Launch (Recommended)
```bash
python index.py
```

### Option 2: Using the Launcher Script
```bash
python launch.py
```

### Option 3: Windows Batch File
Double-click `launch.bat` (Windows only)

## 🎯 Features of the Index Page

### 📊 System Status Dashboard
- **Real-time Dependency Check**: Monitors all required modules
- **System Health**: Shows status of Python, gTTS, Manim, MoviePy, Pydub, FFmpeg
- **Last Checked Time**: Timestamp of the last system check

### ⚡ Quick Actions Panel
1. **🎬 Launch GUI**: Opens the main Text to Video Generator interface
2. **⚡ Quick Start**: Runs a demonstration of the system
3. **🔧 CLI Interface**: Opens command-line interface for automation
4. **📁 Open Output**: Opens the output folder with generated files
5. **🧪 Test System**: Runs comprehensive system tests

### 📋 Project Information
- **Project Overview**: Complete description of features and capabilities
- **Language Support**: List of all supported languages including Odia
- **Voice Styles**: Available voice options including Ancient Oriya Voice
- **Technical Components**: Details about TTS, Animation, and Video modules

### 📁 Recent Files
- **File Browser**: Shows the 10 most recent generated files
- **Quick Access**: Double-click any file to open it
- **File Types**: Supports .mp4, .html, and .txt files

## 🎨 Interface Layout

```
┌─────────────────────────────────────────────────────────┐
│                Text to Video Generator                  │
│              Control Center & Dashboard                 │
├─────────────────┬───────────────────────────────────────┤
│   Quick Actions │           Project Information         │
│                 │                                       │
│  🎬 Launch GUI  │  📊 Project Overview                  │
│  ⚡ Quick Start │  🌍 Language Support                  │
│  🔧 CLI Interface│  🎵 Voice Styles                     │
│  📁 Open Output │                                       │
│  🧪 Test System │  📁 Recent Files                      │
│                 │                                       │
│  System Status  │                                       │
│  ┌─────────────┐│                                       │
│  │ ✅ Python   ││                                       │
│  │ ✅ gTTS     ││                                       │
│  │ ❌ Manim    ││                                       │
│  │ ✅ MoviePy  ││                                       │
│  │ ✅ Pydub    ││                                       │
│  │ ❌ FFmpeg   ││                                       │
│  └─────────────┘│                                       │
└─────────────────┴───────────────────────────────────────┘
```

## 🔧 System Requirements Check

The Index Page automatically checks for:

### ✅ Required Dependencies
- **Python 3.7+**: Core runtime environment
- **gTTS**: Google Text-to-Speech for voice generation
- **MoviePy**: Video processing and synchronization
- **Pydub**: Audio processing and enhancement

### ⚠️ Optional Dependencies
- **Manim**: Advanced animation engine (for full video generation)
- **FFmpeg**: Video encoding (for complete video output)

### 📝 Status Indicators
- **✅ Available**: Component is installed and working
- **❌ Not available**: Component is missing or not working
- **Last checked**: Timestamp of the last system check

## 🎯 Quick Start Guide

1. **Launch the Index Page**:
   ```bash
   python index.py
   ```

2. **Check System Status**: Review the System Status panel to ensure all dependencies are available

3. **Choose Your Action**:
   - For **GUI Interface**: Click "🎬 Launch GUI"
   - For **Quick Demo**: Click "⚡ Quick Start"
   - For **Command Line**: Click "🔧 CLI Interface"

4. **Monitor Progress**: Watch the status bar for real-time updates

## 🌟 Special Features

### 🏛️ Ancient Oriya Voice Support
- **Automatic Detection**: When Odia language is selected, ancient voice characteristics are automatically applied
- **Traditional Sound**: Deep, reverent voice with temple-like reverb effects
- **Cultural Authenticity**: Honors traditional Oriya recitation styles

### 📁 File Management
- **Recent Files**: Automatically tracks and displays recently generated files
- **Quick Access**: Double-click any file to open it with the default application
- **Output Organization**: All generated files are organized in the `output/` directory

### 🔄 System Monitoring
- **Real-time Status**: Live monitoring of all system components
- **Dependency Tracking**: Automatic detection of missing or outdated dependencies
- **Error Reporting**: Clear error messages and troubleshooting guidance

## 🛠️ Troubleshooting

### Common Issues

1. **"Module not found" errors**:
   - Install missing dependencies: `pip install gtts moviepy pydub`
   - For Manim: `pip install manim`

2. **FFmpeg not available**:
   - Download and install FFmpeg from https://ffmpeg.org/
   - Add FFmpeg to your system PATH

3. **GUI not launching**:
   - Check if tkinter is installed: `python -m tkinter`
   - On Linux: `sudo apt-get install python3-tk`

### Getting Help

- **System Test**: Use "🧪 Test System" to run comprehensive diagnostics
- **Status Panel**: Check the System Status panel for specific error details
- **Output Folder**: Review generated files in the output directory

## 🎉 Success Indicators

When everything is working correctly, you should see:
- ✅ All dependencies marked as "Available"
- 🎬 GUI launches without errors
- 📁 Output folder contains generated files
- 🎵 Audio files play with proper voice characteristics

## 📞 Support

For additional help or feature requests, refer to the main project documentation or create an issue in the project repository.

---

**Happy Video Creating! 🎬✨**
