"""
Working demo of the text-to-video generator
This version focuses on core functionality without complex dependencies
"""

import os
import time
from tts_module import TextToSpeech
from config import OUTPUT_SETTINGS

def create_simple_video(text, title=None):
    """
    Create a simple text-to-video demo
    """
    print("🎬 Creating Text-to-Video Demo")
    print("=" * 40)
    
    # Initialize TTS
    tts = TextToSpeech()
    
    # Create output directory
    os.makedirs(OUTPUT_SETTINGS['output_dir'], exist_ok=True)
    os.makedirs(OUTPUT_SETTINGS['temp_dir'], exist_ok=True)
    
    # Step 1: Generate speech
    print("Step 1: Generating speech...")
    audio_result = tts.generate_speech_with_timing(text)
    
    if not audio_result:
        print("❌ Failed to generate speech")
        return False
    
    print(f"✅ Generated {len(audio_result['audio_files'])} audio segments")
    print(f"⏱️  Total duration: {audio_result['total_duration']:.2f} seconds")
    
    # Step 2: Show what we have
    print("\nStep 2: Generated components:")
    print(f"📁 Audio files in: {OUTPUT_SETTINGS['temp_dir']}")
    for i, audio_info in enumerate(audio_result['audio_files']):
        print(f"  - Segment {i+1}: {audio_info['text'][:50]}...")
        print(f"    Duration: {audio_info['duration']:.2f}s")
    
    # Step 3: Create a simple text file with the content
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    text_file = os.path.join(OUTPUT_SETTINGS['output_dir'], f'video_script_{timestamp}.txt')
    
    with open(text_file, 'w', encoding='utf-8') as f:
        if title:
            f.write(f"TITLE: {title}\n\n")
        f.write("TEXT CONTENT:\n")
        f.write(text)
        f.write(f"\n\nAUDIO DURATION: {audio_result['total_duration']:.2f} seconds")
        f.write(f"\nAUDIO SEGMENTS: {len(audio_result['audio_files'])}")
    
    print(f"\n✅ Text script saved: {text_file}")
    
    # Step 4: Show next steps
    print("\n" + "=" * 40)
    print("🎉 Demo completed successfully!")
    print("\nWhat was generated:")
    print(f"📝 Text script: {text_file}")
    print(f"🎵 Audio files: {len(audio_result['audio_files'])} segments")
    print(f"⏱️  Total duration: {audio_result['total_duration']:.2f} seconds")
    
    print("\nNext steps to complete video generation:")
    print("1. Install FFmpeg: https://ffmpeg.org/download.html")
    print("2. Add FFmpeg to your system PATH")
    print("3. Run the full pipeline with video generation")
    
    print("\nFor now, you can:")
    print("- Listen to the generated audio files")
    print("- Use the text script for manual video creation")
    print("- Try the GUI interface: python gui_interface.py")
    
    return True

def main():
    """Main demo function"""
    print("🚀 Text-to-Video Generator - Working Demo")
    print("=" * 50)
    
    # Sample text
    text = """
    Welcome to the Text to Video Generator!
    
    This amazing tool can convert any text into a professional-looking video.
    It supports multiple animation styles and automatically synchronizes audio with visuals.
    
    You can use it for:
    - Educational content
    - Social media posts
    - Presentations
    - Marketing videos
    
    The process is simple: just enter your text and let the AI do the rest!
    """
    
    title = "Text to Video Demo"
    
    # Run the demo
    success = create_simple_video(text, title)
    
    if success:
        print("\n🎬 Demo completed! Check the output folder for results.")
    else:
        print("\n❌ Demo failed. Please check the error messages above.")

if __name__ == "__main__":
    main()
