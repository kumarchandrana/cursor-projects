"""
Quick start script for Text to Video Generator
This script helps users get started quickly with a simple example
"""

import os
import sys
import subprocess

def check_dependencies():
    """Check if required dependencies are installed"""
    print("Checking dependencies...")
    
    required_packages = [
        'gtts', 'manim', 'moviepy', 'Pillow', 'numpy'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package} - Missing")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\nMissing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing_packages)
            print("✅ Dependencies installed successfully!")
        except subprocess.CalledProcessError:
            print("❌ Failed to install dependencies. Please run:")
            print("pip install -r requirements.txt")
            return False
    
    return True

def check_ffmpeg():
    """Check if FFmpeg is installed"""
    print("\nChecking FFmpeg...")
    
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, check=True)
        print("✅ FFmpeg is installed")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        print("❌ FFmpeg not found")
        print("\nPlease install FFmpeg:")
        print("Windows: choco install ffmpeg")
        print("macOS: brew install ffmpeg")
        print("Linux: sudo apt install ffmpeg")
        return False

def run_example():
    """Run a simple example"""
    print("\nRunning example...")
    
    try:
        from text_to_video_pipeline import TextToVideoPipeline
        
        # Simple example text
        text = """
        Welcome to the Text to Video Generator!
        
        This is a quick demonstration of how easy it is to convert text into video.
        Just enter your text and let the AI create a professional-looking video for you.
        
        You can use this for:
        - Educational content
        - Social media posts
        - Presentations
        - Marketing videos
        
        The process is completely automatic!
        """
        
        print("Generating video...")
        pipeline = TextToVideoPipeline()
        
        result = pipeline.automatic_mode(
            text=text,
            title="Quick Start Demo",
            animation_type="simple"
        )
        
        if result['success']:
            print(f"\n✅ Video generated successfully!")
            print(f"📹 Location: {result['final_video']}")
            print(f"⏱️  Duration: {result['total_duration']:.2f} seconds")
            print(f"⏱️  Processing time: {result['processing_time']:.2f} seconds")
            
            # Try to open the video
            if os.name == 'nt':  # Windows
                try:
                    os.startfile(result['final_video'])
                    print("🎬 Video opened in default player")
                except:
                    print("📁 Check the output folder for your video")
            else:
                print("📁 Check the output folder for your video")
        else:
            print(f"❌ Error: {result['error']}")
            return False
            
    except Exception as e:
        print(f"❌ Error running example: {str(e)}")
        return False
    
    return True

def main():
    """Main quick start function"""
    print("=" * 60)
    print("🚀 Text to Video Generator - Quick Start")
    print("=" * 60)
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Please install dependencies first")
        return
    
    # Check FFmpeg
    if not check_ffmpeg():
        print("\n⚠️  FFmpeg is required for video processing")
        print("Please install FFmpeg and run this script again")
        return
    
    # Run example
    if run_example():
        print("\n" + "=" * 60)
        print("🎉 Quick start completed successfully!")
        print("\nNext steps:")
        print("1. Run 'python gui_interface.py' for the graphical interface")
        print("2. Run 'python cli_interface.py \"Your text here\"' for command line")
        print("3. Check 'example.py' for more examples")
        print("4. Read 'README.md' for detailed documentation")
        print("=" * 60)
    else:
        print("\n❌ Quick start failed. Please check the error messages above.")

if __name__ == "__main__":
    main()
