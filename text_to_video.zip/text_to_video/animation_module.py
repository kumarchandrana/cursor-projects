"""
Animation module using Manim for creating text-based animations
"""

import os
import numpy as np
try:
    from manim import *
except ImportError:
    print("Warning: Manim not properly installed. Some features may not work.")
    # Create dummy classes for testing
    class Scene:
        def __init__(self): pass
        def construct(self): pass
        def render(self): pass
    class Text:
        def __init__(self, *args, **kwargs): pass
        def to_edge(self, *args, **kwargs): return self
        def move_to(self, *args, **kwargs): return self
    class VGroup:
        def __init__(self, *args): pass
        def arrange(self, *args, **kwargs): return self
        def move_to(self, *args, **kwargs): return self
    class Write:
        def __init__(self, *args, **kwargs): pass
    class FadeIn:
        def __init__(self, *args, **kwargs): pass
    class FadeOut:
        def __init__(self, *args, **kwargs): pass
    ORIGIN = (0, 0, 0)
    UP = (0, 1, 0)
    DOWN = (0, -1, 0)
    LEFT = (-1, 0, 0)
    RIGHT = (1, 0, 0)
    config = type('config', (), {'pixel_height': 1080, 'pixel_width': 1920, 'frame_rate': 30})()
    
from config import ANIMATION_SETTINGS, VIDEO_SETTINGS

class TextAnimation:
    def __init__(self):
        self.animation_settings = ANIMATION_SETTINGS
        self.video_settings = VIDEO_SETTINGS
        
    def create_text_scene(self, text, title=None, output_path=None):
        """
        Create a simple text animation scene
        
        Args:
            text (str): Main text content
            title (str, optional): Title text
            output_path (str): Path to save the video
            
        Returns:
            str: Path to generated video file
        """
        try:
            # Check if Manim is properly available
            try:
                from manim import Scene, Text, VGroup, Write, FadeIn, FadeOut, ORIGIN, UP, DOWN, LEFT, RIGHT, config
                manim_available = True
            except ImportError:
                manim_available = False
                print("Manim not available, using simple animation fallback")
            
            if not manim_available:
                # Use simple animation fallback
                from simple_animation import SimpleAnimation
                simple_anim = SimpleAnimation()
                
                # Create a simple text image as fallback
                if output_path:
                    # Change extension to .png for image output
                    image_path = output_path.replace('.mp4', '.png')
                else:
                    image_path = os.path.join('temp', 'text_animation.png')
                    os.makedirs('temp', exist_ok=True)
                
                result = simple_anim.create_text_image(text, title, image_path)
                if result:
                    print(f"Created simple text image: {result}")
                    return result
                else:
                    raise Exception("Failed to create simple text image")
            
            # If simple animation fails, try Manim (original code)
            # Create output directory
            if output_path and os.path.dirname(output_path):
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # Create a closure to capture the settings
            def create_text_scene_class(anim_settings, scene_title, scene_text):
                class TextScene(Scene):
                    def construct(self):
                        # Set background color
                        try:
                            self.camera.background_color = anim_settings['background_color']
                        except:
                            self.camera.background_color = '#1a1a1a'
                        
                        # Create title if provided
                        if scene_title:
                            title_text = Text(
                                scene_title,
                                font_size=anim_settings['title_size'],
                                color=anim_settings['text_color']
                            ).to_edge(UP, buff=anim_settings['margin'])
                            
                            # Animate title
                            self.play(Write(title_text))
                            self.wait(1)
                        
                        # Split text into lines for better display
                        lines = self._split_text_into_lines(scene_text, 60)
                        
                        # Create text objects for each line
                        text_objects = []
                        for i, line in enumerate(lines):
                            text_obj = Text(
                                line,
                                font_size=anim_settings['text_size'],
                                color=anim_settings['text_color']
                            )
                            text_objects.append(text_obj)
                        
                        # Arrange text objects vertically
                        if len(text_objects) > 1:
                            text_group = VGroup(*text_objects).arrange(DOWN, aligned_edge=LEFT, buff=0.3)
                        else:
                            text_group = text_objects[0]
                        
                        # Center the text group
                        text_group.move_to(ORIGIN)
                        
                        # Animate text appearance
                        if len(text_objects) > 1:
                            for text_obj in text_objects:
                                self.play(FadeIn(text_obj), run_time=0.5)
                        else:
                            self.play(Write(text_group), run_time=2)
                        
                        # Hold the final frame
                        self.wait(3)
                    
                    def _split_text_into_lines(self, text, max_chars):
                        """Split text into lines with maximum character limit"""
                        words = text.split()
                        lines = []
                        current_line = ""
                        
                        for word in words:
                            if len(current_line + " " + word) <= max_chars:
                                current_line += (" " + word) if current_line else word
                            else:
                                if current_line:
                                    lines.append(current_line)
                                current_line = word
                        
                        if current_line:
                            lines.append(current_line)
                        
                        return lines
                
                return TextScene
            
            TextScene = create_text_scene_class(self.animation_settings, title, text)
            
            # Render the scene
            config.pixel_height = self.video_settings['resolution'][1]
            config.pixel_width = self.video_settings['resolution'][0]
            config.frame_rate = self.video_settings['fps']
            
            scene = TextScene()
            scene.render()
            
            # Move the output file to desired location
            if output_path:
                default_output = scene.renderer.file_writer.movie_file_path
                if os.path.exists(default_output):
                    # Ensure the output directory exists
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    # Copy the file instead of renaming to avoid issues
                    import shutil
                    shutil.copy2(default_output, output_path)
                    return output_path
                else:
                    print(f"Warning: Default output file not found: {default_output}")
                    return None
            
            return scene.renderer.file_writer.movie_file_path
            
        except Exception as e:
            print(f"Error creating text animation: {str(e)}")
            print(f"Error type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return None
    
    def create_typing_animation(self, text, output_path=None):
        """
        Create a typing animation effect
        
        Args:
            text (str): Text to animate
            output_path (str): Path to save the video
            
        Returns:
            str: Path to generated video file
        """
        try:
            # Check if Manim is properly available
            try:
                from manim import Scene, Text, Write, ORIGIN, config
                manim_available = True
            except ImportError:
                manim_available = False
                print("Manim not available, using simple animation fallback for typing")
            
            if not manim_available:
                # Use simple animation fallback
                from simple_animation import SimpleAnimation
                simple_anim = SimpleAnimation()
                
                # Create a simple text image as fallback
                if output_path:
                    image_path = output_path.replace('.mp4', '.png')
                else:
                    image_path = os.path.join('temp', 'typing_animation.png')
                    os.makedirs('temp', exist_ok=True)
                
                result = simple_anim.create_text_image(text, None, image_path)
                if result:
                    print(f"Created simple typing image: {result}")
                    return result
                else:
                    raise Exception("Failed to create simple typing image")
            
            # Create a closure to capture the settings
            def create_typing_scene_class(anim_settings, scene_text):
                class TypingScene(Scene):
                    def construct(self):
                        self.camera.background_color = anim_settings['background_color']
                        
                        # Create text object
                        text_obj = Text(
                            scene_text,
                            font_size=anim_settings['text_size'],
                            color=anim_settings['text_color']
                        ).move_to(ORIGIN)
                        
                        # Create typing effect
                        self.play(Write(text_obj), run_time=len(scene_text) * 0.05)
                        self.wait(2)
                
                return TypingScene
            
            TypingScene = create_typing_scene_class(self.animation_settings, text)
            
            config.pixel_height = self.video_settings['resolution'][1]
            config.pixel_width = self.video_settings['resolution'][0]
            config.frame_rate = self.video_settings['fps']
            
            scene = TypingScene()
            scene.render()
            
            if output_path:
                default_output = scene.renderer.file_writer.movie_file_path
                if os.path.exists(default_output):
                    # Ensure the output directory exists
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    # Copy the file instead of renaming to avoid issues
                    import shutil
                    shutil.copy2(default_output, output_path)
                    return output_path
                else:
                    print(f"Warning: Default output file not found: {default_output}")
                    return None
            
            return scene.renderer.file_writer.movie_file_path
            
        except Exception as e:
            print(f"Error creating typing animation: {str(e)}")
            print(f"Error type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return None
    
    def create_slide_animation(self, sentences, output_path=None):
        """
        Create a slide-based animation for multiple sentences
        
        Args:
            sentences (list): List of sentences to animate
            output_path (str): Path to save the video
            
        Returns:
            str: Path to generated video file
        """
        try:
            # Check if Manim is properly available
            try:
                from manim import Scene, Text, FadeIn, FadeOut, ORIGIN, config
                manim_available = True
            except ImportError:
                manim_available = False
                print("Manim not available, using simple animation fallback for slides")
            
            if not manim_available:
                # Use simple animation fallback
                from simple_animation import SimpleAnimation
                simple_anim = SimpleAnimation()
                
                # Create a simple text image as fallback
                if output_path:
                    image_path = output_path.replace('.mp4', '.png')
                else:
                    image_path = os.path.join('temp', 'slide_animation.png')
                    os.makedirs('temp', exist_ok=True)
                
                # Combine all sentences into one text
                combined_text = " ".join(sentences)
                result = simple_anim.create_text_image(combined_text, None, image_path)
                if result:
                    print(f"Created simple slide image: {result}")
                    return result
                else:
                    raise Exception("Failed to create simple slide image")
            
            # Create a closure to capture the settings
            def create_slide_scene_class(anim_settings, scene_sentences):
                class SlideScene(Scene):
                    def construct(self):
                        self.camera.background_color = anim_settings['background_color']
                        
                        for i, sentence in enumerate(scene_sentences):
                            # Create text object
                            text_obj = Text(
                                sentence,
                                font_size=anim_settings['text_size'],
                                color=anim_settings['text_color']
                            ).move_to(ORIGIN)
                            
                            # Fade in
                            self.play(FadeIn(text_obj), run_time=anim_settings['fade_duration'])
                            
                            # Hold
                            self.wait(anim_settings['slide_duration'])
                            
                            # Fade out (except for last slide)
                            if i < len(scene_sentences) - 1:
                                self.play(FadeOut(text_obj), run_time=anim_settings['fade_duration'])
                
                return SlideScene
            
            SlideScene = create_slide_scene_class(self.animation_settings, sentences)
            
            config.pixel_height = self.video_settings['resolution'][1]
            config.pixel_width = self.video_settings['resolution'][0]
            config.frame_rate = self.video_settings['fps']
            
            scene = SlideScene()
            scene.render()
            
            if output_path:
                default_output = scene.renderer.file_writer.movie_file_path
                if os.path.exists(default_output):
                    # Ensure the output directory exists
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    # Copy the file instead of renaming to avoid issues
                    import shutil
                    shutil.copy2(default_output, output_path)
                    return output_path
                else:
                    print(f"Warning: Default output file not found: {default_output}")
                    return None
            
            return scene.renderer.file_writer.movie_file_path
            
        except Exception as e:
            print(f"Error creating slide animation: {str(e)}")
            print(f"Error type: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            return None
