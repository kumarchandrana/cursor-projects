#!/usr/bin/env python3
"""
Text to Video Generator - Main Index Page
Control Center for the entire project
"""

import tkinter as tk
from tkinter import ttk, messagebox
import os
import sys
import subprocess
import webbrowser
from datetime import datetime

class TextToVideoIndex:
    def __init__(self, root):
        self.root = root
        self.root.title("Text to Video Generator - Control Center")
        self.root.geometry("1000x700")
        self.root.configure(bg='#f0f0f0')
        
        # Set window icon (if available)
        try:
            self.root.iconbitmap('icon.ico')
        except:
            pass
        
        self.create_widgets()
        self.check_dependencies()
        self.setup_keyboard_shortcuts()
        
    def create_widgets(self):
        """Create the main interface widgets"""
        # Main title
        title_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        title_frame.pack(fill='x', padx=10, pady=10)
        title_frame.pack_propagate(False)
        
        title_label = tk.Label(title_frame, text="Text to Video Generator", 
                              font=('Arial', 24, 'bold'), fg='white', bg='#2c3e50')
        title_label.pack(expand=True)
        
        subtitle_label = tk.Label(title_frame, text="Control Center & Project Dashboard", 
                                 font=('Arial', 12), fg='#bdc3c7', bg='#2c3e50')
        subtitle_label.pack()
        
        # Main content frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        # Left panel - Quick Actions
        left_panel = tk.Frame(main_frame, bg='#ecf0f1', width=300)
        left_panel.pack(side='left', fill='y', padx=(0, 10))
        left_panel.pack_propagate(False)
        
        # Quick Actions section
        actions_frame = tk.LabelFrame(left_panel, text="Quick Actions", 
                                     font=('Arial', 12, 'bold'), bg='#ecf0f1')
        actions_frame.pack(fill='x', padx=10, pady=10)
        
        # Action buttons
        self.create_action_button(actions_frame, "🎬 Launch GUI", self.launch_gui, 
                                 "Open the main Text to Video Generator interface")
        self.create_action_button(actions_frame, "⚡ Quick Start", self.quick_start, 
                                 "Run a quick demonstration")
        self.create_action_button(actions_frame, "🔧 CLI Interface", self.launch_cli, 
                                 "Open command-line interface")
        self.create_action_button(actions_frame, "📁 Open Output", self.open_output_folder, 
                                 "View generated videos and files")
        self.create_action_button(actions_frame, "🧪 Test System", self.test_system, 
                                 "Test all components and dependencies")
        self.create_action_button(actions_frame, "🔄 Refresh System", self.refresh_system, 
                                 "Refresh system status and reload information")
        
        # Project Status section
        status_frame = tk.LabelFrame(left_panel, text="System Status", 
                                    font=('Arial', 12, 'bold'), bg='#ecf0f1')
        status_frame.pack(fill='x', padx=10, pady=10)
        
        self.status_text = tk.Text(status_frame, height=8, width=35, 
                                  font=('Consolas', 9), bg='#2c3e50', fg='#ecf0f1')
        self.status_text.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Right panel - Project Information
        right_panel = tk.Frame(main_frame, bg='#ecf0f1')
        right_panel.pack(side='right', fill='both', expand=True)
        
        # Project Overview
        overview_frame = tk.LabelFrame(right_panel, text="Project Overview", 
                                      font=('Arial', 12, 'bold'), bg='#ecf0f1')
        overview_frame.pack(fill='x', padx=10, pady=10)
        
        overview_text = """
🎯 Text to Video Generator is a comprehensive tool that converts text into professional animated videos with voice narration.

✨ Key Features:
• Multi-language support (including Odia with ancient voice)
• Multiple animation styles (Simple, Typing, Slides)
• Voice styles (Natural, Playful, Rich, Energetic, Ancient)
• Automatic video generation with audio synchronization
• Fallback mode for systems without FFmpeg
• HTML video player for easy viewing

🔧 Technical Components:
• TTS Module: Google Text-to-Speech with voice enhancement
• Animation Module: Manim-based text animations
• Video Sync: MoviePy for audio-video synchronization
• GUI Interface: User-friendly graphical interface
• CLI Interface: Command-line automation support
        """
        
        overview_label = tk.Label(overview_frame, text=overview_text, 
                                 font=('Arial', 10), bg='#ecf0f1', justify='left')
        overview_label.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Language Support
        lang_frame = tk.LabelFrame(right_panel, text="Supported Languages", 
                                  font=('Arial', 12, 'bold'), bg='#ecf0f1')
        lang_frame.pack(fill='x', padx=10, pady=10)
        
        lang_text = """
🌍 Languages with Voice Support:
• English, Hindi, Bengali, Tamil, Telugu
• Marathi, Gujarati, Kannada, Malayalam, Punjabi
• Spanish, French, German, Arabic, Japanese, Korean, Chinese
• Odia (with special ancient voice characteristics)

🎵 Voice Styles Available:
• Natural Narration - Professional quality
• Playful Voice - Energetic and fun
• Rich Voice - Deep and authoritative
• Energetic Voice - Quick and dynamic
• Ancient Oriya Voice - Traditional and reverent
        """
        
        lang_label = tk.Label(lang_frame, text=lang_text, 
                             font=('Arial', 10), bg='#ecf0f1', justify='left')
        lang_label.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Recent Files
        recent_frame = tk.LabelFrame(right_panel, text="Recent Files", 
                                    font=('Arial', 12, 'bold'), bg='#ecf0f1')
        recent_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self.recent_listbox = tk.Listbox(recent_frame, font=('Arial', 10))
        self.recent_listbox.pack(fill='both', expand=True, padx=5, pady=5)
        self.recent_listbox.bind('<Double-1>', self.open_recent_file)
        
        self.load_recent_files()
        
        # Bottom status bar
        status_bar = tk.Frame(self.root, bg='#34495e', height=30)
        status_bar.pack(fill='x', side='bottom')
        status_bar.pack_propagate(False)
        
        self.status_label = tk.Label(status_bar, text="Ready", 
                                    font=('Arial', 10), fg='white', bg='#34495e')
        self.status_label.pack(side='left', padx=10, pady=5)
        
        # Version info
        version_label = tk.Label(status_bar, text="v1.0 - Text to Video Generator", 
                                font=('Arial', 9), fg='#bdc3c7', bg='#34495e')
        version_label.pack(side='right', padx=10, pady=5)
        
        # Refresh info
        self.refresh_label = tk.Label(status_bar, text="Press F5 or Ctrl+R to refresh", 
                                     font=('Arial', 8), fg='#95a5a6', bg='#34495e')
        self.refresh_label.pack(side='right', padx=10, pady=5)
        
    def create_action_button(self, parent, text, command, tooltip):
        """Create a styled action button"""
        btn = tk.Button(parent, text=text, command=command, 
                       font=('Arial', 11, 'bold'), bg='#3498db', fg='white',
                       relief='flat', padx=20, pady=8, cursor='hand2')
        btn.pack(fill='x', padx=5, pady=3)
        
        # Add hover effects
        def on_enter(e):
            btn.config(bg='#2980b9')
        def on_leave(e):
            btn.config(bg='#3498db')
        
        btn.bind('<Enter>', on_enter)
        btn.bind('<Leave>', on_leave)
        
        # Add tooltip
        self.create_tooltip(btn, tooltip)
        
    def create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        def show_tooltip(event):
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = tk.Label(tooltip, text=text, background='#2c3e50', 
                           foreground='white', font=('Arial', 9), padx=5, pady=3)
            label.pack()
            
            widget.tooltip = tooltip
            
        def hide_tooltip(event):
            if hasattr(widget, 'tooltip'):
                widget.tooltip.destroy()
                del widget.tooltip
                
        widget.bind('<Enter>', show_tooltip)
        widget.bind('<Leave>', hide_tooltip)
        
    def check_dependencies(self):
        """Check system dependencies and update status"""
        self.update_status("Checking system dependencies...")
        
        dependencies = {
            'Python': sys.version.split()[0],
            'gTTS': self.check_module('gtts'),
            'Manim': self.check_module('manim'),
            'MoviePy': self.check_module('moviepy'),
            'Pydub': self.check_module('pydub'),
            'FFmpeg': self.check_ffmpeg(),
            'TTS (Indic)': self.check_module('TTS'),
            'Indian TTS': self.check_indian_tts()
        }
        
        status_text = "System Status:\n"
        status_text += "=" * 30 + "\n"
        
        for dep, status in dependencies.items():
            if status:
                status_text += f"✅ {dep}: {status}\n"
            else:
                status_text += f"❌ {dep}: Not available\n"
        
        status_text += "\n" + "=" * 30 + "\n"
        status_text += f"Last checked: {datetime.now().strftime('%H:%M:%S')}\n"
        
        self.status_text.delete(1.0, tk.END)
        self.status_text.insert(1.0, status_text)
        
        self.update_status("System check completed")
        
    def check_module(self, module_name):
        """Check if a Python module is available"""
        try:
            __import__(module_name)
            return "Available"
        except ImportError:
            return None
            
    def check_ffmpeg(self):
        """Check if FFmpeg is available"""
        try:
            result = subprocess.run(['ffmpeg', '-version'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return "Available"
        except:
            pass
        return None
        
    def check_indian_tts(self):
        """Check if Indian TTS module is available"""
        try:
            from indian_tts_module import IndianTTS
            tts = IndianTTS()
            if tts.is_available:
                return "Available"
        except ImportError:
            pass
        except Exception:
            pass
        return None
        
    def update_status(self, message):
        """Update the status bar"""
        self.status_label.config(text=message)
        self.root.update_idletasks()
        
    def launch_gui(self):
        """Launch the main GUI interface"""
        try:
            self.update_status("Launching GUI interface...")
            subprocess.Popen([sys.executable, 'gui_interface.py'])
            self.update_status("GUI launched successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch GUI: {str(e)}")
            self.update_status("Failed to launch GUI")
            
    def quick_start(self):
        """Run quick start demonstration"""
        try:
            self.update_status("Running quick start demo...")
            subprocess.Popen([sys.executable, 'quick_start.py'])
            self.update_status("Quick start launched")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to run quick start: {str(e)}")
            self.update_status("Failed to run quick start")
            
    def launch_cli(self):
        """Launch CLI interface"""
        try:
            self.update_status("Launching CLI interface...")
            subprocess.Popen([sys.executable, 'cli_interface.py'])
            self.update_status("CLI launched successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch CLI: {str(e)}")
            self.update_status("Failed to launch CLI")
            
    def open_output_folder(self):
        """Open the output folder"""
        try:
            output_dir = os.path.join(os.getcwd(), 'output')
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            
            if os.name == 'nt':  # Windows
                os.startfile(output_dir)
            elif os.name == 'posix':  # macOS and Linux
                subprocess.run(['open', output_dir])
            
            self.update_status("Output folder opened")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open output folder: {str(e)}")
            self.update_status("Failed to open output folder")
            
    def test_system(self):
        """Test all system components"""
        try:
            self.update_status("Running system tests...")
            subprocess.Popen([sys.executable, 'simple_test.py'])
            self.update_status("System tests launched")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to run system tests: {str(e)}")
            self.update_status("Failed to run system tests")
            
    def refresh_system(self):
        """Refresh system status and reload information"""
        try:
            self.update_status("Refreshing system...")
            
            # Show refresh progress
            refresh_steps = [
                "Clearing recent files list...",
                "Reloading recent files...",
                "Checking system dependencies...",
                "Verifying Indian TTS status...",
                "Updating system status...",
                "Finalizing refresh..."
            ]
            
            for i, step in enumerate(refresh_steps):
                self.update_status(step)
                self.root.update_idletasks()
                # Small delay to show progress
                self.root.after(100)
            
            # Clear and reload recent files
            self.recent_listbox.delete(0, tk.END)
            self.load_recent_files()
            
            # Refresh system dependencies
            self.check_dependencies()
            
            # Update status with refresh timestamp
            current_time = datetime.now().strftime('%H:%M:%S')
            self.update_status(f"System refreshed at {current_time}")
            
            # Count recent files
            file_count = self.recent_listbox.size()
            
            # Show success message with details
            messagebox.showinfo("Refresh Complete", 
                              f"System status has been refreshed successfully!\n\n"
                              f"✅ Dependencies rechecked\n"
                              f"✅ Recent files reloaded ({file_count} files found)\n"
                              f"✅ Indian TTS status verified\n"
                              f"✅ System status updated\n\n"
                              f"Last refreshed: {current_time}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh system: {str(e)}")
            self.update_status("Failed to refresh system")
        
    def setup_keyboard_shortcuts(self):
        """Setup keyboard shortcuts for common actions"""
        # F5 for refresh
        self.root.bind('<F5>', lambda event: self.refresh_system())
        
        # Ctrl+R for refresh
        self.root.bind('<Control-r>', lambda event: self.refresh_system())
        
        # Ctrl+O for open output
        self.root.bind('<Control-o>', lambda event: self.open_output_folder())
        
        # Ctrl+G for launch GUI
        self.root.bind('<Control-g>', lambda event: self.launch_gui())
        
        # Ctrl+T for test system
        self.root.bind('<Control-t>', lambda event: self.test_system())
            
    def load_recent_files(self):
        """Load recent files from output directory"""
        try:
            output_dir = os.path.join(os.getcwd(), 'output')
            if os.path.exists(output_dir):
                files = []
                for file in os.listdir(output_dir):
                    if file.endswith(('.mp4', '.html', '.txt')):
                        file_path = os.path.join(output_dir, file)
                        mod_time = os.path.getmtime(file_path)
                        files.append((mod_time, file))
                
                # Sort by modification time (newest first)
                files.sort(reverse=True)
                
                # Add to listbox
                for _, filename in files[:10]:  # Show only 10 most recent
                    self.recent_listbox.insert(tk.END, filename)
                    
        except Exception as e:
            print(f"Error loading recent files: {e}")
            
    def open_recent_file(self, event):
        """Open a recent file"""
        selection = self.recent_listbox.curselection()
        if selection:
            filename = self.recent_listbox.get(selection[0])
            file_path = os.path.join(os.getcwd(), 'output', filename)
            
            try:
                if os.name == 'nt':  # Windows
                    os.startfile(file_path)
                elif os.name == 'posix':  # macOS and Linux
                    subprocess.run(['open', file_path])
                self.update_status(f"Opened {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open file: {str(e)}")

def main():
    """Main function to run the index page"""
    root = tk.Tk()
    app = TextToVideoIndex(root)
    
    # Center the window
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (root.winfo_width() // 2)
    y = (root.winfo_screenheight() // 2) - (root.winfo_height() // 2)
    root.geometry(f"+{x}+{y}")
    
    root.mainloop()

if __name__ == "__main__":
    main()
