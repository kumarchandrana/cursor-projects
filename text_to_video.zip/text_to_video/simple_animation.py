"""
Simple animation fallback for when FFmpeg/Manim is not available
"""

import os
from PIL import Image, ImageDraw, ImageFont
from config import ANIMATION_SETTINGS, VIDEO_SETTINGS

class SimpleAnimation:
    def __init__(self):
        self.animation_settings = ANIMATION_SETTINGS
        self.video_settings = VIDEO_SETTINGS
        
    def create_text_image(self, text, title=None, output_path=None):
        """
        Create a simple text image as fallback animation
        
        Args:
            text (str): Main text content
            title (str, optional): Title text
            output_path (str): Path to save the image
            
        Returns:
            str: Path to generated image
        """
        try:
            # Create output directory
            if output_path:
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
            else:
                output_path = os.path.join('temp', 'simple_text.png')
                os.makedirs('temp', exist_ok=True)
            
            # Image dimensions
            width, height = self.video_settings['resolution']
            
            # Create image with background color
            bg_color = self.animation_settings.get('background_color', '#1a1a1a')
            if bg_color.startswith('#'):
                bg_color = tuple(int(bg_color[i:i+2], 16) for i in (1, 3, 5))
            else:
                bg_color = (26, 26, 26)  # Default dark background
            
            image = Image.new('RGB', (width, height), bg_color)
            draw = ImageDraw.Draw(image)
            
            # Try to load a font, fallback to default
            try:
                title_font = ImageFont.truetype("arial.ttf", self.animation_settings.get('title_size', 72))
                text_font = ImageFont.truetype("arial.ttf", self.animation_settings.get('text_size', 48))
            except:
                try:
                    title_font = ImageFont.load_default()
                    text_font = ImageFont.load_default()
                except:
                    title_font = None
                    text_font = None
            
            # Text color
            text_color = self.animation_settings.get('text_color', '#ffffff')
            if text_color.startswith('#'):
                text_color = tuple(int(text_color[i:i+2], 16) for i in (1, 3, 5))
            else:
                text_color = (255, 255, 255)  # Default white
            
            y_position = 100
            
            # Draw title if provided
            if title:
                if title_font:
                    draw.text((width//2, y_position), title, font=title_font, fill=text_color, anchor="mm")
                else:
                    draw.text((width//2, y_position), title, fill=text_color, anchor="mm")
                y_position += 100
            
            # Split text into lines for better display
            lines = self._split_text_into_lines(text, 80)
            
            # Draw main text
            for line in lines:
                if text_font:
                    draw.text((width//2, y_position), line, font=text_font, fill=text_color, anchor="mm")
                else:
                    draw.text((width//2, y_position), line, fill=text_color, anchor="mm")
                y_position += 60
            
            # Save image
            image.save(output_path, 'PNG')
            print(f"Simple text image created: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"Error creating simple animation: {str(e)}")
            return None
    
    def _split_text_into_lines(self, text, max_chars):
        """Split text into lines with maximum character limit"""
        words = text.split()
        lines = []
        current_line = ""
        
        for word in words:
            if len(current_line + " " + word) <= max_chars:
                current_line += (" " + word) if current_line else word
            else:
                if current_line:
                    lines.append(current_line)
                current_line = word
        
        if current_line:
            lines.append(current_line)
        
        return lines
