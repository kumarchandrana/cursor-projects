"""
Text-to-Speech module using Google Text-to-Speech (gTTS)
Enhanced with voice styles and multiple language support
"""

import os
import numpy as np
from gtts import gTTS
from config import AUDIO_SETTINGS, OUTPUT_SETTINGS, VOICE_STYLES, LANGUAGE_SETTINGS
import tempfile
import time

# Import Indian TTS modules
try:
    from indian_tts_module import IndianTTS
    INDIAN_TTS_AVAILABLE = True
except ImportError:
    INDIAN_TTS_AVAILABLE = False
    print("Warning: Indian TTS module not available. Using gTTS fallback.")

try:
    from odia_tts_module import OdiaTTS
    ODIA_TTS_AVAILABLE = True
except ImportError:
    ODIA_TTS_AVAILABLE = False

class TextToSpeech:
    def __init__(self):
        self.audio_settings = AUDIO_SETTINGS
        self.output_settings = OUTPUT_SETTINGS
        self.voice_styles = VOICE_STYLES
        self.language_settings = LANGUAGE_SETTINGS
        
        # Initialize Indian TTS if available
        if INDIAN_TTS_AVAILABLE:
            try:
                self.indian_tts = IndianTTS()
                print("✅ Indian TTS module initialized")
            except Exception as e:
                print(f"❌ Failed to initialize Indian TTS: {e}")
                self.indian_tts = None
        else:
            self.indian_tts = None
            
        # Initialize Odia TTS if available (legacy support)
        if ODIA_TTS_AVAILABLE:
            try:
                self.odia_tts = OdiaTTS()
                print("✅ Odia TTS module initialized")
            except Exception as e:
                print(f"❌ Failed to initialize Odia TTS: {e}")
                self.odia_tts = None
        else:
            self.odia_tts = None
        
    def generate_speech(self, text, output_path=None, language='en', voice_style='normal'):
        """
        Convert text to speech and save as audio file
        
        Args:
            text (str): Text to convert to speech
            output_path (str, optional): Path to save audio file
            language (str): Language code (e.g., 'en', 'hi', 'or')
            voice_style (str): Voice style ('normal', 'funny', 'deep', 'fast')
            
        Returns:
            str: Path to generated audio file
        """
        try:
            # Create output directory if it doesn't exist
            os.makedirs(self.output_settings['temp_dir'], exist_ok=True)
            
            # Generate temporary file if no output path provided
            if output_path is None:
                temp_file = tempfile.NamedTemporaryFile(
                    suffix=f'.{self.output_settings["audio_format"]}',
                    dir=self.output_settings['temp_dir'],
                    delete=False
                )
                output_path = temp_file.name
                temp_file.close()
            
            # Check if language is supported
            if language not in self.language_settings:
                raise ValueError(f"Language '{language}' is not supported. Supported languages: {list(self.language_settings.keys())}")
            
            # Get language settings
            lang_settings = self.language_settings.get(language, self.language_settings['en'])
            
            # Check if language is supported by gTTS
            if not self._is_language_supported_by_gtts(language):
                # Check if it's an Indian language with offline TTS support
                lang_settings = self.language_settings.get(language, {})
                
                if lang_settings.get('indian_language') and self.indian_tts and self.indian_tts.is_model_available(language):
                    print(f"Using offline {lang_settings['name']} for authentic pronunciation...")
                    return self._generate_indian_speech(text, language, output_path, voice_style)
                elif language == 'or' and self.odia_tts and self.odia_tts.is_model_available():
                    print("Using offline Odia TTS for authentic pronunciation...")
                    return self._generate_odia_speech(text, output_path, voice_style)
                else:
                    print(f"Warning: Language '{language}' is not supported by gTTS. Using fallback to Hindi.")
                    # Use Hindi as fallback for unsupported languages
                    fallback_language = 'hi'
                    fallback_settings = self.language_settings.get('hi', self.language_settings['en'])
                    
                    # Special handling for Odia ancient voice
                    if language == 'or' and fallback_settings.get('ancient_voice'):
                        print("Applying ancient Oriya voice characteristics...")
                        # Use slower, more traditional settings for ancient feel
                        fallback_settings = fallback_settings.copy()
                        fallback_settings['slow'] = True
                    
                    print(f"Creating gTTS with fallback language: {fallback_language}")
                    print(f"Text length: {len(text)} characters")
                    print(f"Text preview: {text[:100]}...")
                    tts = gTTS(
                        text=text,
                        lang=fallback_language,
                        slow=fallback_settings['slow'],
                        tld=fallback_settings['tld']
                    )
            else:
                # Create gTTS object with original language
                print(f"Creating gTTS with language: {language}")
                print(f"Text length: {len(text)} characters")
                print(f"Text preview: {text[:100]}...")
                tts = gTTS(
                    text=text,
                    lang=language,
                    slow=lang_settings['slow'],
                    tld=lang_settings['tld']
                )
            
            # Save audio file
            print(f"Saving audio to: {output_path}")
            tts.save(output_path)
            print(f"Audio saved successfully")
            
            # Apply base quality enhancements
            try:
                output_path = self._enhance_base_audio_quality(output_path)
                print(f"Base audio quality enhanced: {output_path}")
            except Exception as enhance_error:
                print(f"Warning: Failed to enhance base audio quality: {str(enhance_error)}")
                print("Using original audio quality")
            
            # Apply voice style effects and natural enhancements
            print(f"Applying voice style: {voice_style}")
            try:
                # Special processing for Odia ancient voice
                if language == 'or' and lang_settings.get('ancient_voice'):
                    print("Applying ancient Oriya voice processing...")
                    # Force ancient voice style for Odia
                    output_path = self._apply_ancient_odia_voice(output_path, voice_style)
                else:
                    output_path = self._apply_voice_style(output_path, voice_style)
                print(f"Voice style applied successfully: {output_path}")
            except Exception as style_error:
                print(f"Warning: Failed to apply voice style {voice_style}: {str(style_error)}")
                print("Using original audio without voice effects")
            
            print(f"Audio generated successfully: {output_path}")
            return output_path
            
        except Exception as e:
            print(f"Error generating speech: {str(e)}")
            print(f"Error type: {type(e).__name__}")
            print(f"Language attempted: {language}")
            print(f"Voice style: {voice_style}")
            import traceback
            traceback.print_exc()
            return None
    
    def _is_language_supported_by_gtts(self, language_code):
        """
        Check if a language code is supported by gTTS
        
        Args:
            language_code (str): Language code to check
            
        Returns:
            bool: True if supported, False otherwise
        """
        # List of languages actually supported by gTTS
        gtts_supported_languages = {
            'en', 'hi', 'bn', 'ta', 'te', 'mr', 'gu', 'kn', 'ml', 'pa', 
            'es', 'fr', 'de', 'ar', 'ja', 'ko', 'zh', 'ru', 'pt', 'it',
            'nl', 'sv', 'da', 'no', 'fi', 'pl', 'tr', 'th', 'vi', 'id',
            'ms', 'tl', 'he', 'uk', 'cs', 'hu', 'ro', 'bg', 'hr', 'sk',
            'sl', 'et', 'lv', 'lt', 'mt', 'cy', 'ga', 'is', 'mk', 'sq',
            'sr', 'bs', 'ca', 'eu', 'gl', 'af', 'sw', 'zu', 'xh', 'st',
            'tn', 'ss', 'ts', 've', 'nr', 'nso', 'zu', 'xh', 'af', 'sw'
        }
        
        return language_code in gtts_supported_languages
    
    def _generate_indian_speech(self, text, language_code, output_path, voice_style):
        """
        Generate Indian language speech using offline TTS
        
        Args:
            text (str): Text to convert
            language_code (str): Language code (e.g., 'hi', 'bn', 'ta')
            output_path (str): Path to save audio file
            voice_style (str): Voice style to apply
            
        Returns:
            str: Path to generated audio file
        """
        try:
            if not self.indian_tts or not self.indian_tts.is_model_available(language_code):
                print(f"❌ {language_code} TTS models not available. Using gTTS fallback.")
                return None
                
            lang_name = self.language_settings.get(language_code, {}).get('name', language_code)
            print(f"Generating authentic {lang_name} speech...")
            print(f"Text: {text[:100]}...")
            
            # Generate speech using Indian TTS
            result_path = self.indian_tts.generate_speech(text, language_code, output_path, voice_style)
            
            if result_path:
                print(f"✅ Authentic {lang_name} speech generated: {result_path}")
                return result_path
            else:
                print(f"❌ Failed to generate {lang_name} speech. Using gTTS fallback.")
                return None
                
        except Exception as e:
            print(f"❌ Error generating {language_code} speech: {e}")
            return None
    
    def _generate_odia_speech(self, text, output_path, voice_style):
        """
        Generate Odia speech using offline TTS
        
        Args:
            text (str): Odia text to convert
            output_path (str): Path to save audio file
            voice_style (str): Voice style to apply
            
        Returns:
            str: Path to generated audio file
        """
        try:
            if not self.odia_tts or not self.odia_tts.is_model_available():
                print("❌ Odia TTS models not available. Using Hindi fallback.")
                return None
                
            print(f"Generating authentic Odia speech...")
            print(f"Text: {text[:100]}...")
            
            # Generate speech using Odia TTS
            result_path = self.odia_tts.generate_speech(text, output_path, voice_style)
            
            if result_path:
                print(f"✅ Authentic Odia speech generated: {result_path}")
                return result_path
            else:
                print("❌ Failed to generate Odia speech. Using Hindi fallback.")
                return None
                
        except Exception as e:
            print(f"❌ Error generating Odia speech: {e}")
            return None
    
    def _enhance_base_audio_quality(self, audio_path):
        """
        Enhance base audio quality for more natural sound
        
        Args:
            audio_path (str): Path to original audio file
            
        Returns:
            str: Path to enhanced audio file
        """
        try:
            from pydub import AudioSegment
            from pydub.effects import normalize, compress_dynamic_range
            
            # Load audio
            audio = AudioSegment.from_mp3(audio_path)
            
            print("Enhancing base audio quality...")
            
            # Apply gentle normalization
            audio = normalize(audio)
            
            # Apply subtle dynamic range compression for more natural speech
            audio = compress_dynamic_range(
                audio, 
                threshold=-25.0, 
                ratio=2.5, 
                attack=10.0, 
                release=100.0
            )
            
            # Apply gentle high-pass filter to remove low-frequency noise
            audio = audio.high_pass_filter(80)
            
            # Apply gentle low-pass filter to remove harsh high frequencies
            audio = audio.low_pass_filter(8000)
            
            # Final normalization
            audio = normalize(audio)
            
            # Create enhanced filename
            base_name = os.path.splitext(audio_path)[0]
            enhanced_path = f"{base_name}_enhanced.mp3"
            
            # Export with high quality
            audio.export(enhanced_path, format="mp3", bitrate="192k")
            
            print(f"Base audio quality enhanced: {enhanced_path}")
            return enhanced_path
            
        except ImportError:
            print("pydub not available for base quality enhancement")
            return audio_path
        except Exception as e:
            print(f"Error enhancing base audio quality: {str(e)}")
            return audio_path
    
    def _apply_ancient_voice_effects(self, audio):
        """
        Apply ancient voice effects for traditional Oriya sound
        
        Args:
            audio: AudioSegment object
            
        Returns:
            AudioSegment: Enhanced audio with ancient characteristics
        """
        try:
            from pydub import AudioSegment
            from pydub.effects import normalize, compress_dynamic_range
            
            print("Applying ancient Oriya voice effects...")
            
            # Lower the pitch for more traditional, reverent sound
            audio = audio._spawn(audio.raw_data, overrides={
                "frame_rate": int(audio.frame_rate * 0.85)
            }).set_frame_rate(audio.frame_rate)
            
            # Apply gentle low-pass filter for warmer, more traditional sound
            audio = audio.low_pass_filter(3000)
            
            # Add subtle reverb effect for ancient temple-like atmosphere
            # Create a simple reverb by adding delayed, quieter copies
            reverb_delay = 150  # milliseconds
            reverb_audio = audio - 6  # Quieter reverb
            reverb_audio = reverb_audio + AudioSegment.silent(duration=reverb_delay)
            audio = audio.overlay(reverb_audio, position=reverb_delay)
            
            # Add another layer for more depth
            reverb_audio2 = audio - 8
            reverb_audio2 = reverb_audio2 + AudioSegment.silent(duration=reverb_delay * 2)
            audio = audio.overlay(reverb_audio2, position=reverb_delay * 2)
            
            # Apply gentle compression for more controlled, traditional delivery
            audio = compress_dynamic_range(
                audio, 
                threshold=-20.0, 
                ratio=3.0, 
                attack=15.0, 
                release=150.0
            )
            
            # Add slight echo for ancient, mystical feel
            echo_audio = audio - 4
            echo_audio = echo_audio + AudioSegment.silent(duration=200)
            audio = audio.overlay(echo_audio, position=200)
            
            # Final normalization
            audio = normalize(audio)
            
            print("Ancient voice effects applied successfully")
            return audio
            
        except Exception as e:
            print(f"Error applying ancient voice effects: {str(e)}")
            return audio
    
    def _apply_ancient_odia_voice(self, audio_path, voice_style):
        """
        Apply ancient Odia voice processing for traditional Oriya sound
        
        Args:
            audio_path (str): Path to original audio file
            voice_style (str): Voice style to apply
            
        Returns:
            str: Path to enhanced audio file
        """
        try:
            from pydub import AudioSegment
            from pydub.effects import normalize, compress_dynamic_range
            
            # Load audio
            audio = AudioSegment.from_mp3(audio_path)
            
            print("Applying ancient Odia voice characteristics...")
            
            # Apply base ancient effects
            audio = self._apply_ancient_voice_effects(audio)
            
            # Additional Odia-specific enhancements
            # Make it even slower and more reverent for traditional feel
            audio = audio._spawn(audio.raw_data, overrides={
                "frame_rate": int(audio.frame_rate * 0.8)
            }).set_frame_rate(audio.frame_rate)
            
            # Apply temple-like reverb for ancient atmosphere
            temple_reverb = audio - 5
            temple_reverb = temple_reverb + AudioSegment.silent(duration=300)
            audio = audio.overlay(temple_reverb, position=300)
            
            # Add subtle echo for mystical ancient feel
            echo_audio = audio - 6
            echo_audio = echo_audio + AudioSegment.silent(duration=400)
            audio = audio.overlay(echo_audio, position=400)
            
            # Apply traditional compression for controlled delivery
            audio = compress_dynamic_range(
                audio, 
                threshold=-18.0, 
                ratio=2.5, 
                attack=20.0, 
                release=200.0
            )
            
            # Final normalization
            audio = normalize(audio)
            
            # Create enhanced filename
            base_name = os.path.splitext(audio_path)[0]
            ancient_path = f"{base_name}_ancient_odia.mp3"
            
            # Export with high quality
            audio.export(ancient_path, format="mp3", bitrate="192k")
            
            print(f"Ancient Odia voice applied: {ancient_path}")
            return ancient_path
            
        except Exception as e:
            print(f"Error applying ancient Odia voice: {str(e)}")
            return audio_path
    
    def _apply_voice_style(self, audio_path, voice_style):
        """
        Apply voice style effects to audio file with enhanced quality
        
        Args:
            audio_path (str): Path to original audio file
            voice_style (str): Voice style to apply
            
        Returns:
            str: Path to modified audio file
        """
        try:
            # Get voice style settings
            style_settings = self.voice_styles.get(voice_style, self.voice_styles['normal'])
            
            # Try to use pydub for audio processing
            try:
                from pydub import AudioSegment
                from pydub.effects import normalize, compress_dynamic_range
                
                # Load audio with high quality settings
                audio = AudioSegment.from_mp3(audio_path)
                
                # Apply audio quality enhancements
                print(f"Enhancing audio quality for {voice_style} voice...")
                
                # Normalize audio for consistent volume
                audio = normalize(audio)
                
                # Apply dynamic range compression for more natural sound
                audio = compress_dynamic_range(audio, threshold=-20.0, ratio=4.0, attack=5.0, release=50.0)
                
                # Apply pitch shifting with better quality
                if style_settings['pitch_shift'] != 1.0:
                    # Use more sophisticated pitch shifting
                    pitch_factor = style_settings['pitch_shift']
                    if pitch_factor > 1.0:
                        # Higher pitch - use formant shifting technique
                        audio = audio._spawn(audio.raw_data, overrides={
                            "frame_rate": int(audio.frame_rate * (pitch_factor ** 0.5))
                        }).set_frame_rate(audio.frame_rate)
                    else:
                        # Lower pitch - use time stretching
                        audio = audio._spawn(audio.raw_data, overrides={
                            "frame_rate": int(audio.frame_rate * (pitch_factor ** 0.5))
                        }).set_frame_rate(audio.frame_rate)
                
                # Apply speed changes with better quality
                if style_settings['speed_multiplier'] != 1.0:
                    speed_factor = style_settings['speed_multiplier']
                    if speed_factor > 1.0:
                        # Speed up with pitch preservation
                        audio = audio.speedup(playback_speed=speed_factor, chunk_size=150, crossfade=25)
                    else:
                        # Slow down with pitch preservation
                        audio = audio._spawn(audio.raw_data, overrides={
                            "frame_rate": int(audio.frame_rate * speed_factor)
                        }).set_frame_rate(audio.frame_rate)
                
                # Apply voice-specific enhancements
                if voice_style == 'funny':
                    # Add slight echo and reverb for cartoonish effect
                    audio = audio + audio - 3  # Simple echo effect
                elif voice_style == 'deep':
                    # Apply low-pass filter simulation for deeper voice
                    audio = audio.low_pass_filter(2000)
                elif voice_style == 'fast':
                    # Add slight compression for energetic sound
                    audio = compress_dynamic_range(audio, threshold=-15.0, ratio=3.0, attack=3.0, release=30.0)
                elif voice_style == 'ancient':
                    # Apply ancient voice characteristics
                    audio = self._apply_ancient_voice_effects(audio)
                
                # Final normalization for consistent output
                audio = normalize(audio)
                
                # Create new filename with style
                base_name = os.path.splitext(audio_path)[0]
                new_path = f"{base_name}_{voice_style}_enhanced.mp3"
                
                # Export with high quality settings
                audio.export(new_path, format="mp3", bitrate="192k")
                
                print(f"Applied enhanced {voice_style} voice style: {new_path}")
                return new_path
                
            except ImportError:
                print("pydub not available for voice effects, using original audio")
                return audio_path
                
        except Exception as e:
            print(f"Error applying voice style: {str(e)}")
            return audio_path
    
    def get_audio_duration(self, audio_path):
        """
        Get duration of audio file in seconds
        
        Args:
            audio_path (str): Path to audio file
            
        Returns:
            float: Duration in seconds
        """
        try:
            try:
                from moviepy.editor import AudioFileClip
            except ImportError:
                from moviepy import AudioFileClip
            with AudioFileClip(audio_path) as audio:
                return audio.duration
        except Exception as e:
            print(f"Error getting audio duration: {str(e)}")
            return 0
    
    def split_text_by_sentences(self, text):
        """
        Split text into sentences for better timing control
        
        Args:
            text (str): Input text
            
        Returns:
            list: List of sentences
        """
        import re
        # Split by sentence endings, keeping the punctuation
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        return [s.strip() for s in sentences if s.strip()]
    
    def generate_speech_with_timing(self, text, output_dir=None, language='en', voice_style='normal'):
        """
        Generate speech and return timing information
        
        Args:
            text (str): Text to convert
            output_dir (str, optional): Directory to save audio files
            language (str): Language code (e.g., 'en', 'hi', 'or')
            voice_style (str): Voice style ('normal', 'funny', 'deep', 'fast')
            
        Returns:
            dict: Dictionary with audio path and timing info
        """
        if output_dir is None:
            output_dir = self.output_settings['temp_dir']
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate single audio file for the entire text
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        audio_path = os.path.join(output_dir, f'complete_audio_{timestamp}.{self.output_settings["audio_format"]}')
        
        generated_path = self.generate_speech(text, audio_path, language, voice_style)
        
        if generated_path:
            duration = self.get_audio_duration(generated_path)
            audio_files = [{
                'path': generated_path,
                'text': text,
                'start_time': 0,
                'duration': duration,
                'end_time': duration,
                'language': language,
                'voice_style': voice_style
            }]
            
            return {
                'audio_files': audio_files,
                'total_duration': duration,
                'text': text,
                'language': language,
                'voice_style': voice_style
            }
        else:
            return None
    
    def get_available_languages(self):
        """
        Get list of available languages
        
        Returns:
            dict: Dictionary of language codes and names
        """
        return {code: settings['name'] for code, settings in self.language_settings.items()}
    
    def get_available_voice_styles(self):
        """
        Get list of available voice styles
        
        Returns:
            dict: Dictionary of voice style codes and names
        """
        return {code: settings['name'] for code, settings in self.voice_styles.items()}
    
    def get_language_info(self, language_code):
        """
        Get information about a specific language
        
        Args:
            language_code (str): Language code
            
        Returns:
            dict: Language information
        """
        return self.language_settings.get(language_code, self.language_settings['en'])
    
    def get_voice_style_info(self, voice_style_code):
        """
        Get information about a specific voice style
        
        Args:
            voice_style_code (str): Voice style code
            
        Returns:
            dict: Voice style information
        """
        return self.voice_styles.get(voice_style_code, self.voice_styles['normal'])
