jQuery(document).ready(function($) {
    
    // Initialize Flatpickr date-time picker
    const dateTimePicker = flatpickr(".birth-datetime-picker", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        time_24hr: true,
        minuteIncrement: 1,
        maxDate: "today",
        yearDropdown: true,
        yearDropdownDecades: true,
        yearDropdownDecade: 10,
        yearDropdownMin: 1900,
        yearDropdownMax: new Date().getFullYear(),
        defaultHour: 12,
        defaultMinute: 0,
        placeholder: "Select your date and time of birth",
        onChange: function(selectedDates, dateStr, instance) {
            // Enable calculate button when date is selected
            if (selectedDates.length > 0) {
                $('#calculate_age_btn').prop('disabled', false);
            }
        }
    });
    
    // Variables for real-time updates
    let updateInterval;
    let lastBirthDateTime = null;
    
    // Calculate Age Button Click Handler
    $('#calculate_age_btn').on('click', function() {
        const birthDateTime = $('.birth-datetime-picker').val();
        
        if (!birthDateTime) {
            showMessage('Please select a valid date and time of birth.', 'error');
            return;
        }
        
        // Store the birth datetime for real-time updates
        lastBirthDateTime = birthDateTime;
        
        // Show loading spinner
        showLoading(true);
        
        // Make AJAX request
        $.ajax({
            url: age_calculator_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'calculate_age',
                birth_datetime: birthDateTime,
                nonce: age_calculator_ajax.nonce
            },
            success: function(response) {
                showLoading(false);
                
                if (response.success) {
                    updateAgeDisplay(response.data);
                    showMessage('Age calculated successfully!', 'success');
                    
                    // Start real-time updates
                    startRealTimeUpdates();
                } else {
                    showMessage(response.data || 'An error occurred while calculating age.', 'error');
                }
            },
            error: function(xhr, status, error) {
                showLoading(false);
                showMessage('An error occurred while calculating age. Please try again.', 'error');
                console.error('AJAX Error:', error);
            }
        });
    });
    
    // Function to update age display
    function updateAgeDisplay(data) {
        // Update each age unit with animation
        updateAgeUnit('years', data.years);
        updateAgeUnit('months', data.months);
        updateAgeUnit('days', data.days);
        updateAgeUnit('hours', data.hours);
        updateAgeUnit('minutes', data.minutes);
        updateAgeUnit('seconds', data.seconds);
        
        // Update last updated timestamp
        $('#last_updated').text(data.last_updated);
        
        // Show the result section
        $('#age_result').show();
    }
    
    // Function to update individual age units with animation
    function updateAgeUnit(unit, value) {
        const element = $(`#${unit}`);
        const currentValue = parseInt(element.text());
        
        if (currentValue !== value) {
            element.text(value);
            element.addClass('updated');
            
            // Remove the animation class after animation completes
            setTimeout(() => {
                element.removeClass('updated');
            }, 600);
        }
    }
    
    // Function to start real-time updates
    function startRealTimeUpdates() {
        // Clear any existing interval
        if (updateInterval) {
            clearInterval(updateInterval);
        }
        
        // Update every second
        updateInterval = setInterval(function() {
            if (lastBirthDateTime) {
                updateAgeInRealTime();
            }
        }, 1000);
    }
    
    // Function to update age in real-time
    function updateAgeInRealTime() {
        if (!lastBirthDateTime) return;
        
        const birthDate = new Date(lastBirthDateTime);
        const currentDate = new Date();
        
        if (birthDate > currentDate) {
            clearInterval(updateInterval);
            return;
        }
        
        // Calculate time difference
        const timeDiff = currentDate - birthDate;
        
        // Calculate years, months, days, hours, minutes, seconds
        const years = Math.floor(timeDiff / (1000 * 60 * 60 * 24 * 365.25));
        const months = Math.floor((timeDiff % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * 30.44));
        const days = Math.floor((timeDiff % (1000 * 60 * 60 * 24 * 30.44)) / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeDiff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);
        
        // Update display without animation for real-time updates
        $('#years').text(years);
        $('#months').text(months);
        $('#days').text(days);
        $('#hours').text(hours);
        $('#minutes').text(minutes);
        $('#seconds').text(seconds);
        
        // Update timestamp
        const now = new Date();
        const timeString = now.toLocaleString();
        $('#last_updated').text(timeString);
    }
    
    // Function to show/hide loading spinner
    function showLoading(show) {
        if (show) {
            $('#loading_spinner').show();
            $('#age_result').hide();
        } else {
            $('#loading_spinner').hide();
        }
    }
    
    // Function to show messages
    function showMessage(message, type) {
        // Remove any existing messages
        $('.age-calculator-form .error-message, .age-calculator-form .success-message').remove();
        
        const messageClass = type === 'error' ? 'error-message' : 'success-message';
        const messageHtml = `<div class="${messageClass}">${message}</div>`;
        
        $('.age-calculator-form').append(messageHtml);
        
        // Auto-remove success messages after 3 seconds
        if (type === 'success') {
            setTimeout(() => {
                $(`.${messageClass}`).fadeOut(300, function() {
                    $(this).remove();
                });
            }, 3000);
        }
    }
    
    // Initialize calculate button as disabled
    $('#calculate_age_btn').prop('disabled', true);
    
    // Enable calculate button when date is selected
    $('.birth-datetime-picker').on('change', function() {
        const value = $(this).val();
        if (value) {
            $('#calculate_age_btn').prop('disabled', false);
        } else {
            $('#calculate_age_btn').prop('disabled', true);
        }
    });
    
    // Clear real-time updates when page is unloaded
    $(window).on('beforeunload', function() {
        if (updateInterval) {
            clearInterval(updateInterval);
        }
    });
    
    // Add keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Enter key to calculate age
        if (e.key === 'Enter' && !$('#calculate_age_btn').prop('disabled')) {
            $('#calculate_age_btn').click();
        }
        
        // Escape key to clear date picker
        if (e.key === 'Escape') {
            $('.birth-datetime-picker').val('');
            $('#calculate_age_btn').prop('disabled', true);
            $('#age_result').hide();
            if (updateInterval) {
                clearInterval(updateInterval);
            }
        }
    });
    
    // Add hover effects for better UX
    $('.age-unit').hover(
        function() {
            $(this).css('transform', 'translateY(-3px) scale(1.02)');
        },
        function() {
            $(this).css('transform', 'translateY(0) scale(1)');
        }
    );
    
    // Add click effect to calculate button
    $('#calculate_age_btn').on('mousedown', function() {
        $(this).css('transform', 'translateY(1px) scale(0.98)');
    }).on('mouseup mouseleave', function() {
        $(this).css('transform', 'translateY(0) scale(1)');
    });
    
    // Add smooth scrolling to result when it appears
    function scrollToResult() {
        const resultElement = $('#age_result');
        if (resultElement.is(':visible')) {
            $('html, body').animate({
                scrollTop: resultElement.offset().top - 50
            }, 500);
        }
    }
    
    // Call scroll function after age calculation
    const originalUpdateAgeDisplay = updateAgeDisplay;
    updateAgeDisplay = function(data) {
        originalUpdateAgeDisplay(data);
        setTimeout(scrollToResult, 100);
    };
    
    // Add accessibility features
    $('.birth-datetime-picker').attr('aria-label', 'Select your date and time of birth');
    $('#calculate_age_btn').attr('aria-label', 'Calculate age based on selected date and time');
    
    // Add focus management
    $('.birth-datetime-picker').on('focus', function() {
        $(this).parent().addClass('focused');
    }).on('blur', function() {
        $(this).parent().removeClass('focused');
    });
    
    // Add touch support for mobile devices
    if ('ontouchstart' in window) {
        $('.age-unit').on('touchstart', function() {
            $(this).addClass('touch-active');
        }).on('touchend touchcancel', function() {
            $(this).removeClass('touch-active');
        });
    }
}); 