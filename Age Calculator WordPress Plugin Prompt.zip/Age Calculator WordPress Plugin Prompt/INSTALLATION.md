# Quick Installation Guide

## Step-by-Step Installation

### 1. Download the Plugin
- Download all files from this repository
- Ensure you have the complete folder structure:
  ```
  age-calculator/
  ├── age-calculator.php
  ├── css/style.css
  ├── js/script.js
  ├── README.md
  └── INSTALLATION.md
  ```

### 2. Upload to WordPress
**Option A: WordPress Admin Upload**
1. Go to your WordPress admin panel
2. Navigate to **Plugins > Add New**
3. Click **Upload Plugin**
4. Choose the `age-calculator` folder
5. Click **Install Now**
6. Click **Activate Plugin**

**Option B: FTP Upload**
1. Upload the `age-calculator` folder to `/wp-content/plugins/`
2. Go to **Plugins > Installed Plugins**
3. Find "Age Calculator" and click **Activate**

### 3. Test the Plugin
1. Create a new page or post
2. Add the shortcode: `[age_calculator]`
3. Publish and view the page
4. Test the date picker and calculation

## Usage Examples

### Basic Usage
```
[age_calculator]
```

### Custom Title
```
[age_calculator title="How Old Am I?"]
```

### Custom Placeholder
```
[age_calculator placeholder="When were you born?"]
```

## Troubleshooting

### Plugin Not Working?
1. Check if plugin is activated
2. Clear browser cache
3. Check browser console for errors
4. Ensure JavaScript is enabled

### Date Picker Issues?
1. Check for JavaScript conflicts
2. Verify jQuery is loaded
3. Clear browser cache
4. Try in incognito/private mode

### Styling Problems?
1. Check for CSS conflicts with theme
2. Clear browser cache
3. Ensure CSS files are loading
4. Check browser developer tools

## Support
If you encounter issues, check the main README.md file for detailed troubleshooting steps. 