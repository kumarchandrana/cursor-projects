# Age Calculator WordPress Plugin

A modern, responsive WordPress plugin that allows users to calculate their current age based on their Date & Time of Birth using a beautiful, interactive interface.

## 🎯 Features

- **Modern Date-Time Picker**: Uses Flatpickr for an intuitive date and time selection
- **Real-Time Updates**: Age updates dynamically every second without page refresh
- **AJAX-Based**: No page refresh required for calculations
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Beautiful UI**: Modern gradient design with smooth animations
- **FontAwesome Icons**: Enhanced visual appeal with professional icons
- **Decade Selection**: Easy year selection with decade dropdowns
- **Accessibility**: Keyboard shortcuts and screen reader support
- **Error Handling**: Comprehensive error messages and validation

## 📋 Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- jQuery (included with WordPress)
- Modern web browser with JavaScript enabled

## 🚀 Installation

### Method 1: Manual Installation

1. **Download the Plugin**
   - Download all plugin files to your computer
   - Create a folder named `age-calculator` in your WordPress plugins directory

2. **Upload to WordPress**
   - Navigate to your WordPress admin panel
   - Go to **Plugins > Add New > Upload Plugin**
   - Choose the `age-calculator` folder
   - Click **Install Now**

3. **Activate the Plugin**
   - Go to **Plugins > Installed Plugins**
   - Find "Age Calculator" and click **Activate**

### Method 2: FTP Upload

1. **Upload Files**
   - Upload the plugin folder to `/wp-content/plugins/age-calculator/`
   - Ensure all files are in the correct directory structure

2. **Activate Plugin**
   - Go to your WordPress admin panel
   - Navigate to **Plugins > Installed Plugins**
   - Find "Age Calculator" and click **Activate**

## 📖 Usage

### Basic Usage

Add the age calculator to any page or post using the shortcode:

```
[age_calculator]
```

### Advanced Usage

You can customize the calculator with parameters:

```
[age_calculator title="My Custom Age Calculator" placeholder="Enter your birth date and time"]
```

### Parameters

- `title`: Custom title for the calculator (default: "Age Calculator")
- `placeholder`: Custom placeholder text for the date picker (default: "Select your date and time of birth")

## 🎨 Features in Detail

### Date-Time Picker
- **Modern Interface**: Clean, intuitive date and time selection
- **Decade Selection**: Easy navigation through years with decade dropdowns
- **Time Selection**: 24-hour format with minute precision
- **Validation**: Prevents future dates and invalid selections

### Real-Time Updates
- **Dynamic Calculation**: Age updates every second automatically
- **Live Display**: Shows years, months, days, hours, minutes, and seconds
- **Smooth Animations**: Visual feedback when values change
- **Timestamp**: Shows when the calculation was last updated

### Responsive Design
- **Mobile-First**: Optimized for touch devices
- **Flexible Layout**: Adapts to different screen sizes
- **Touch Support**: Enhanced touch interactions for mobile users

### User Experience
- **Loading States**: Visual feedback during calculations
- **Error Handling**: Clear error messages for invalid inputs
- **Success Messages**: Confirmation when calculations complete
- **Keyboard Shortcuts**: 
  - `Enter`: Calculate age
  - `Escape`: Clear date picker

## 🛠️ File Structure

```
age-calculator/
├── age-calculator.php      # Main plugin file
├── css/
│   └── style.css          # Stylesheet
├── js/
│   └── script.js          # JavaScript functionality
└── README.md              # This file
```

## 🎯 Shortcode Examples

### Basic Implementation
```
[age_calculator]
```

### Custom Title
```
[age_calculator title="How Old Am I?"]
```

### Custom Placeholder
```
[age_calculator placeholder="When were you born?"]
```

### Full Customization
```
[age_calculator title="Birthday Calculator" placeholder="Enter your birth date and time"]
```

## 🔧 Technical Details

### AJAX Endpoints
- **Action**: `calculate_age`
- **Nonce Verification**: Security checks implemented
- **Error Handling**: Comprehensive error responses

### Dependencies
- **FontAwesome 6.4.0**: Icons via CDN
- **Flatpickr**: Date-time picker library
- **jQuery**: DOM manipulation and AJAX

### Browser Support
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## 🐛 Troubleshooting

### Common Issues

1. **Calculator Not Appearing**
   - Ensure the plugin is activated
   - Check that the shortcode is correctly placed
   - Verify JavaScript is enabled in your browser

2. **Date Picker Not Working**
   - Clear browser cache
   - Check for JavaScript conflicts with other plugins
   - Ensure jQuery is loaded

3. **AJAX Errors**
   - Check WordPress permalink settings
   - Verify server supports AJAX requests
   - Check browser console for JavaScript errors

4. **Styling Issues**
   - Clear browser cache
   - Check for CSS conflicts with theme
   - Ensure CSS files are loading correctly

### Debug Mode

To enable debug mode, add this to your `wp-config.php`:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

## 🔒 Security Features

- **Nonce Verification**: All AJAX requests are secured
- **Input Sanitization**: All user inputs are properly sanitized
- **Output Escaping**: All outputs are properly escaped
- **Date Validation**: Prevents invalid date submissions

## 📱 Mobile Optimization

- **Touch-Friendly**: Large touch targets for mobile devices
- **Responsive Grid**: Age display adapts to screen size
- **Optimized Fonts**: Readable text on all devices
- **Smooth Scrolling**: Enhanced mobile navigation

## 🎨 Customization

### CSS Customization
You can customize the appearance by adding CSS to your theme:

```css
/* Custom color scheme */
.age-calculator-card {
    background: linear-gradient(135deg, #your-color-1 0%, #your-color-2 100%);
}

/* Custom button style */
.calculate-btn {
    background: linear-gradient(45deg, #your-button-color-1, #your-button-color-2);
}
```

### JavaScript Customization
You can extend functionality by adding custom JavaScript:

```javascript
// Custom event listener
jQuery(document).on('age_calculated', function(event, data) {
    console.log('Age calculated:', data);
});
```

## 📄 License

This plugin is licensed under the GPL v2 or later.

## 🤝 Support

For support, feature requests, or bug reports, please contact the plugin developer.

## 📈 Changelog

### Version 1.0.0
- Initial release
- Modern date-time picker integration
- Real-time age updates
- Responsive design
- AJAX-based calculations
- FontAwesome icons
- Comprehensive error handling

---

**Note**: This plugin is designed to work with modern WordPress installations and follows WordPress coding standards and best practices. 