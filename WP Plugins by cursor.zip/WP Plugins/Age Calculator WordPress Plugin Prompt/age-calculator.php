<?php
/**
 * Plugin Name: Age Calculator
 * Plugin URI: https://example.com/age-calculator
 * Description: A WordPress plugin that allows users to calculate their current age based on their Date & Time of Birth using a modern Date-Time Picker.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: age-calculator
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AGE_CALCULATOR_VERSION', '1.0.0');
define('AGE_CALCULATOR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AGE_CALCULATOR_PLUGIN_PATH', plugin_dir_path(__FILE__));

class AgeCalculator {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_calculate_age', array($this, 'calculate_age_ajax'));
        add_action('wp_ajax_nopriv_calculate_age', array($this, 'calculate_age_ajax'));
        add_shortcode('age_calculator', array($this, 'age_calculator_shortcode'));
    }
    
    public function init() {
        // Initialize plugin
    }
    
    public function enqueue_scripts() {
        // Enqueue FontAwesome
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
        
        // Enqueue Flatpickr for modern date-time picker
        wp_enqueue_style('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css');
        wp_enqueue_script('flatpickr', 'https://cdn.jsdelivr.net/npm/flatpickr', array(), null, true);
        
        // Enqueue our custom styles and scripts
        wp_enqueue_style('age-calculator-style', AGE_CALCULATOR_PLUGIN_URL . 'css/style.css', array(), AGE_CALCULATOR_VERSION);
        wp_enqueue_script('age-calculator-script', AGE_CALCULATOR_PLUGIN_URL . 'js/script.js', array('jquery', 'flatpickr'), AGE_CALCULATOR_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('age-calculator-script', 'age_calculator_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('age_calculator_nonce')
        ));
    }
    
    public function age_calculator_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Age Calculator',
            'placeholder' => 'Select your date and time of birth'
        ), $atts);
        
        ob_start();
        ?>
        <div class="age-calculator-container">
            <div class="age-calculator-card">
                <div class="age-calculator-header">
                    <h3><i class="fas fa-birthday-cake"></i> <?php echo esc_html($atts['title']); ?></h3>
                </div>
                
                <div class="age-calculator-form">
                    <div class="form-group">
                        <label for="birth_datetime">
                            <i class="fas fa-calendar-alt"></i> Date & Time of Birth
                        </label>
                        <input type="text" id="birth_datetime" class="birth-datetime-picker" 
                               placeholder="<?php echo esc_attr($atts['placeholder']); ?>" readonly>
                    </div>
                    
                    <button type="button" id="calculate_age_btn" class="calculate-btn">
                        <i class="fas fa-calculator"></i> Calculate Age
                    </button>
                </div>
                
                <div class="age-result" id="age_result" style="display: none;">
                    <div class="result-header">
                        <h4><i class="fas fa-clock"></i> Your Age</h4>
                    </div>
                    <div class="age-display">
                        <div class="age-unit">
                            <span class="age-number" id="years">0</span>
                            <span class="age-label">Years</span>
                        </div>
                        <div class="age-unit">
                            <span class="age-number" id="months">0</span>
                            <span class="age-label">Months</span>
                        </div>
                        <div class="age-unit">
                            <span class="age-number" id="days">0</span>
                            <span class="age-label">Days</span>
                        </div>
                        <div class="age-unit">
                            <span class="age-number" id="hours">0</span>
                            <span class="age-label">Hours</span>
                        </div>
                        <div class="age-unit">
                            <span class="age-number" id="minutes">0</span>
                            <span class="age-label">Minutes</span>
                        </div>
                        <div class="age-unit">
                            <span class="age-number" id="seconds">0</span>
                            <span class="age-label">Seconds</span>
                        </div>
                    </div>
                    <div class="last-updated">
                        <small><i class="fas fa-sync-alt"></i> Last updated: <span id="last_updated">-</span></small>
                    </div>
                </div>
                
                <div class="loading-spinner" id="loading_spinner" style="display: none;">
                    <i class="fas fa-spinner fa-spin"></i> Calculating...
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function calculate_age_ajax() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'age_calculator_nonce')) {
            wp_die('Security check failed');
        }
        
        $birth_datetime = sanitize_text_field($_POST['birth_datetime']);
        
        if (empty($birth_datetime)) {
            wp_send_json_error('Please select a valid date and time.');
        }
        
        try {
            $birth_date = new DateTime($birth_datetime);
            $current_date = new DateTime();
            
            if ($birth_date > $current_date) {
                wp_send_json_error('Birth date cannot be in the future.');
            }
            
            $interval = $current_date->diff($birth_date);
            
            $result = array(
                'years' => $interval->y,
                'months' => $interval->m,
                'days' => $interval->d,
                'hours' => $interval->h,
                'minutes' => $interval->i,
                'seconds' => $interval->s,
                'last_updated' => current_time('Y-m-d H:i:s')
            );
            
            wp_send_json_success($result);
            
        } catch (Exception $e) {
            wp_send_json_error('Invalid date format. Please try again.');
        }
    }
}

// Initialize the plugin
new AgeCalculator();

// Activation hook
register_activation_hook(__FILE__, 'age_calculator_activate');
function age_calculator_activate() {
    // Create necessary directories
    $css_dir = AGE_CALCULATOR_PLUGIN_PATH . 'css';
    $js_dir = AGE_CALCULATOR_PLUGIN_PATH . 'js';
    
    if (!file_exists($css_dir)) {
        wp_mkdir_p($css_dir);
    }
    if (!file_exists($js_dir)) {
        wp_mkdir_p($js_dir);
    }
} 