# Quick Installation Guide - GST Calculator India

## 🚀 Quick Start

### Step 1: Download Files
Ensure you have all the required files:
- `gst-calculator.php` (main plugin file)
- `css/style.css` (styling)
- `js/script.js` (JavaScript functionality)
- `README.md` (documentation)

### Step 2: Upload to WordPress

#### Option A: WordPress Admin Upload
1. Go to **WordPress Admin > Plugins > Add New**
2. Click **Upload Plugin**
3. Choose the `gst-calculator.php` file
4. Click **Install Now**
5. Click **Activate Plugin**

#### Option B: FTP Upload
1. Create folder: `wp-content/plugins/gst-calculator-india/`
2. Upload all files maintaining the structure:
   ```
   gst-calculator-india/
   ├── gst-calculator.php
   ├── css/style.css
   ├── js/script.js
   └── README.md
   ```
3. Go to **Plugins > Installed Plugins**
4. Find "GST Calculator India" and click **Activate**

### Step 3: Use the Calculator

Add this shortcode to any page or post:
```
[gst_calculator]
```

### Step 4: Test the Calculator

1. Create a new page or post
2. Add the shortcode `[gst_calculator]`
3. Publish the page
4. Visit the page and test the calculator

## ✅ Verification Checklist

- [ ] Plugin appears in **Plugins > Installed Plugins**
- [ ] Plugin status shows as "Active"
- [ ] Shortcode `[gst_calculator]` displays calculator
- [ ] Calculator accepts input values
- [ ] "Calculate GST" button works
- [ ] Results display correctly
- [ ] CGST & SGST breakdown shows
- [ ] Mobile responsive design works

## 🔧 Troubleshooting

### Calculator Not Showing?
- Check plugin is activated
- Verify shortcode syntax: `[gst_calculator]`
- Clear browser cache
- Check for JavaScript errors in browser console

### AJAX Not Working?
- Ensure WordPress AJAX is enabled
- Check for plugin conflicts
- Verify nonce security isn't blocking requests

### Styling Issues?
- Clear browser cache
- Check for CSS conflicts with theme
- Verify FontAwesome is loading

## 📞 Need Help?

1. Check the main README.md file
2. Review browser console for errors
3. Test with a default WordPress theme
4. Disable other plugins temporarily

---

**Plugin Version**: 1.0.0  
**WordPress Required**: 5.0+  
**PHP Required**: 7.4+ 