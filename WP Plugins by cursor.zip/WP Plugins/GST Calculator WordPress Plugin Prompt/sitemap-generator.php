<?php
/**
 * GST Calculator India - Sitemap Generator
 * Generates XML sitemap for SEO optimization
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class GST_Calculator_Sitemap {
    
    private $plugin_url;
    private $sitemap_url;
    
    public function __construct() {
        $this->plugin_url = plugin_dir_url(__FILE__);
        $this->sitemap_url = home_url('/gst-calculator-sitemap.xml');
        
        // Add sitemap to robots.txt
        add_action('robots_txt', array($this, 'add_sitemap_to_robots'));
        
        // Generate sitemap on plugin activation
        add_action('gst_calculator_activate', array($this, 'generate_sitemap'));
        
        // Add sitemap rewrite rule
        add_action('init', array($this, 'add_sitemap_rewrite'));
        add_filter('query_vars', array($this, 'add_sitemap_query_var'));
        add_action('template_redirect', array($this, 'serve_sitemap'));
        
        // Auto-regenerate sitemap when content changes
        add_action('save_post', array($this, 'regenerate_sitemap_on_content_change'));
        add_action('wp_update_nav_menu', array($this, 'regenerate_sitemap_on_menu_change'));
    }
    
    /**
     * Add sitemap to robots.txt
     */
    public function add_sitemap_to_robots($output) {
        $output .= "\nSitemap: " . $this->sitemap_url . "\n";
        return $output;
    }
    
    /**
     * Add sitemap rewrite rule
     */
    public function add_sitemap_rewrite() {
        add_rewrite_rule(
            'gst-calculator-sitemap\.xml$',
            'index.php?gst_sitemap=1',
            'top'
        );
    }
    
    /**
     * Add sitemap query variable
     */
    public function add_sitemap_query_var($vars) {
        $vars[] = 'gst_sitemap';
        return $vars;
    }
    
    /**
     * Serve sitemap XML
     */
    public function serve_sitemap() {
        global $wp_query;
        
        if (isset($wp_query->query_vars['gst_sitemap']) && $wp_query->query_vars['gst_sitemap'] == '1') {
            $this->generate_and_serve_sitemap();
        }
    }
    
    /**
     * Generate and serve sitemap
     */
    public function generate_and_serve_sitemap() {
        $xml = $this->generate_sitemap_xml();
        
        // Set headers
        header('Content-Type: application/xml; charset=UTF-8');
        header('Cache-Control: public, max-age=3600'); // Cache for 1 hour
        
        // Output XML
        echo $xml;
        exit;
    }
    
    /**
     * Generate sitemap XML content
     */
    public function generate_sitemap_xml() {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" ';
        $xml .= 'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ';
        $xml .= 'xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 ';
        $xml .= 'http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">' . "\n";
        
        // Add main calculator page
        $xml .= $this->generate_url_entry(
            home_url('/gst-calculator/'),
            '1.0',
            'daily',
            date('Y-m-d')
        );
        
        // Add calculator with different rates
        $gst_rates = array('5', '12', '18', '28');
        foreach ($gst_rates as $rate) {
            $xml .= $this->generate_url_entry(
                home_url('/gst-calculator/?rate=' . $rate),
                '0.8',
                'weekly',
                date('Y-m-d')
            );
        }
        
        // Add help/documentation pages
        $xml .= $this->generate_url_entry(
            home_url('/gst-calculator-help/'),
            '0.7',
            'monthly',
            date('Y-m-d')
        );
        
        $xml .= $this->generate_url_entry(
            home_url('/gst-calculator-faq/'),
            '0.7',
            'monthly',
            date('Y-m-d')
        );
        
        // Add API endpoints (if applicable)
        $xml .= $this->generate_url_entry(
            home_url('/wp-json/gst-calculator/v1/calculate'),
            '0.6',
            'weekly',
            date('Y-m-d')
        );
        
        // Add pages with calculator shortcode
        $pages_with_calculator = $this->get_pages_with_calculator();
        foreach ($pages_with_calculator as $page) {
            $xml .= $this->generate_url_entry(
                get_permalink($page->ID),
                '0.8',
                'weekly',
                get_the_modified_date('Y-m-d', $page->ID)
            );
        }
        
        $xml .= '</urlset>';
        
        return $xml;
    }
    
    /**
     * Generate URL entry for sitemap
     */
    private function generate_url_entry($url, $priority, $changefreq, $lastmod) {
        $entry = "\t<url>\n";
        $entry .= "\t\t<loc>" . esc_url($url) . "</loc>\n";
        $entry .= "\t\t<lastmod>" . $lastmod . "</lastmod>\n";
        $entry .= "\t\t<changefreq>" . $changefreq . "</changefreq>\n";
        $entry .= "\t\t<priority>" . $priority . "</priority>\n";
        $entry .= "\t</url>\n";
        
        return $entry;
    }
    
    /**
     * Get pages with calculator shortcode
     */
    private function get_pages_with_calculator() {
        $args = array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_gst_calculator_shortcode',
                    'value' => '1',
                    'compare' => '='
                )
            )
        );
        
        $query = new WP_Query($args);
        return $query->posts;
    }
    
    /**
     * Generate sitemap on plugin activation
     */
    public function generate_sitemap() {
        $xml = $this->generate_sitemap_xml();
        
        // Save to file
        $upload_dir = wp_upload_dir();
        $sitemap_path = $upload_dir['basedir'] . '/gst-calculator-sitemap.xml';
        
        file_put_contents($sitemap_path, $xml);
        
        // Ping search engines
        $this->ping_search_engines();
    }
    
    /**
     * Regenerate sitemap on content change
     */
    public function regenerate_sitemap_on_content_change($post_id) {
        // Check if post contains calculator shortcode
        $post = get_post($post_id);
        if ($post && has_shortcode($post->post_content, 'gst_calculator')) {
            update_post_meta($post_id, '_gst_calculator_shortcode', '1');
            $this->generate_sitemap();
        }
    }
    
    /**
     * Regenerate sitemap on menu change
     */
    public function regenerate_sitemap_on_menu_change($menu_id) {
        $this->generate_sitemap();
    }
    
    /**
     * Ping search engines about sitemap
     */
    private function ping_search_engines() {
        $search_engines = array(
            'https://www.google.com/ping?sitemap=' . urlencode($this->sitemap_url),
            'https://www.bing.com/ping?sitemap=' . urlencode($this->sitemap_url),
            'https://search.yahoo.com/ping?sitemap=' . urlencode($this->sitemap_url)
        );
        
        foreach ($search_engines as $url) {
            wp_remote_get($url, array(
                'timeout' => 5,
                'blocking' => false
            ));
        }
    }
    
    /**
     * Get sitemap statistics
     */
    public function get_sitemap_stats() {
        $stats = array(
            'total_urls' => 0,
            'last_generated' => '',
            'file_size' => 0,
            'search_engines_pinged' => array()
        );
        
        $upload_dir = wp_upload_dir();
        $sitemap_path = $upload_dir['basedir'] . '/gst-calculator-sitemap.xml';
        
        if (file_exists($sitemap_path)) {
            $stats['total_urls'] = substr_count(file_get_contents($sitemap_path), '<url>');
            $stats['last_generated'] = date('Y-m-d H:i:s', filemtime($sitemap_path));
            $stats['file_size'] = filesize($sitemap_path);
        }
        
        return $stats;
    }
    
    /**
     * Validate sitemap
     */
    public function validate_sitemap() {
        $upload_dir = wp_upload_dir();
        $sitemap_path = $upload_dir['basedir'] . '/gst-calculator-sitemap.xml';
        
        if (!file_exists($sitemap_path)) {
            return false;
        }
        
        $xml = file_get_contents($sitemap_path);
        
        // Basic XML validation
        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadXML($xml);
        $errors = libxml_get_errors();
        libxml_clear_errors();
        
        return empty($errors);
    }
    
    /**
     * Get sitemap URL
     */
    public function get_sitemap_url() {
        return $this->sitemap_url;
    }
}

// Initialize sitemap generator
new GST_Calculator_Sitemap();

/**
 * Add sitemap functionality to main plugin
 */
function gst_calculator_add_sitemap_support() {
    // Include sitemap generator
    require_once plugin_dir_path(__FILE__) . 'sitemap-generator.php';
}

// Hook into plugin initialization
add_action('plugins_loaded', 'gst_calculator_add_sitemap_support');

/**
 * Generate sitemap on plugin activation
 */
function gst_calculator_activate_sitemap() {
    $sitemap = new GST_Calculator_Sitemap();
    $sitemap->generate_sitemap();
}

// Hook into plugin activation
add_action('gst_calculator_activate', 'gst_calculator_activate_sitemap');

/**
 * Admin notice for sitemap generation
 */
function gst_calculator_sitemap_admin_notice() {
    if (isset($_GET['gst_sitemap_generated'])) {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>GST Calculator sitemap has been generated successfully!</p>';
        echo '</div>';
    }
}

add_action('admin_notices', 'gst_calculator_sitemap_admin_notice');

/**
 * Add sitemap info to plugin admin page
 */
function gst_calculator_add_sitemap_info() {
    $sitemap = new GST_Calculator_Sitemap();
    $stats = $sitemap->get_sitemap_stats();
    
    echo '<div class="gst-calculator-sitemap-info">';
    echo '<h3>Sitemap Information</h3>';
    echo '<p><strong>Sitemap URL:</strong> <a href="' . esc_url($sitemap->get_sitemap_url()) . '" target="_blank">' . esc_url($sitemap->get_sitemap_url()) . '</a></p>';
    echo '<p><strong>Total URLs:</strong> ' . esc_html($stats['total_urls']) . '</p>';
    echo '<p><strong>Last Generated:</strong> ' . esc_html($stats['last_generated']) . '</p>';
    echo '<p><strong>File Size:</strong> ' . esc_html(size_format($stats['file_size'])) . '</p>';
    echo '<p><strong>Valid:</strong> ' . ($sitemap->validate_sitemap() ? 'Yes' : 'No') . '</p>';
    echo '</div>';
}

// Add to plugin admin page
add_action('gst_calculator_admin_page', 'gst_calculator_add_sitemap_info'); 