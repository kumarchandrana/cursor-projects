/**
 * GST Calculator India - JavaScript
 * Handles AJAX calculations and user interactions
 * SEO optimized with structured data and analytics
 */

(function($) {
    'use strict';

    // SEO and Analytics Configuration
    const SEO_CONFIG = {
        analytics: {
            enabled: true,
            trackingId: 'GST-CALCULATOR-INDIA',
            events: {
                calculation: 'gst_calculation',
                error: 'gst_error',
                modal_open: 'prompt_modal_open',
                modal_close: 'prompt_modal_close'
            }
        },
        structuredData: {
            updateOnCalculation: true,
            schemaType: 'WebApplication'
        },
        performance: {
            debounceDelay: 300,
            cacheResults: true,
            maxCacheSize: 10
        }
    };

    // Performance and SEO utilities
    const SEOUtils = {
        // Track user interactions for SEO insights
        trackEvent(eventName, data = {}) {
            if (SEO_CONFIG.analytics.enabled) {
                const eventData = {
                    event: eventName,
                    timestamp: Date.now(),
                    userAgent: navigator.userAgent,
                    screenResolution: `${screen.width}x${screen.height}`,
                    ...data
                };
                
                // Send to analytics (replace with your analytics service)
                console.log('SEO Event:', eventData);
                
                // Store in localStorage for analytics
                this.storeAnalyticsData(eventData);
            }
        },

        // Store analytics data locally
        storeAnalyticsData(data) {
            try {
                const existing = JSON.parse(localStorage.getItem('gst_calculator_analytics') || '[]');
                existing.push(data);
                
                // Keep only last 100 events
                if (existing.length > 100) {
                    existing.splice(0, existing.length - 100);
                }
                
                localStorage.setItem('gst_calculator_analytics', JSON.stringify(existing));
            } catch (e) {
                console.warn('Could not store analytics data:', e);
            }
        },

        // Update structured data for SEO
        updateStructuredData(calculationData) {
            if (!SEO_CONFIG.structuredData.updateOnCalculation) return;
            
            const schema = {
                '@context': 'https://schema.org',
                '@type': 'WebApplication',
                'name': 'GST Calculator India',
                'description': 'Free online GST calculator for Indian businesses',
                'url': window.location.href,
                'applicationCategory': 'BusinessApplication',
                'operatingSystem': 'Web Browser',
                'offers': {
                    '@type': 'Offer',
                    'price': '0',
                    'priceCurrency': 'INR',
                    'availability': 'https://schema.org/InStock'
                },
                'interactionStatistic': {
                    '@type': 'InteractionCounter',
                    'interactionType': 'https://schema.org/UseAction',
                    'userInteractionCount': this.getInteractionCount()
                },
                'potentialAction': {
                    '@type': 'CalculateAction',
                    'target': {
                        '@type': 'EntryPoint',
                        'urlTemplate': window.location.href,
                        'inLanguage': 'en-US',
                        'actionPlatform': 'http://schema.org/WebPlatform'
                    },
                    'result': {
                        '@type': 'PriceSpecification',
                        'price': calculationData.gst_amount || '0',
                        'priceCurrency': 'INR'
                    }
                }
            };
            
            // Update existing schema or create new one
            this.updateSchemaScript(schema);
        },

        // Update schema script in DOM
        updateSchemaScript(schema) {
            let schemaScript = document.querySelector('script[data-gst-schema]');
            
            if (!schemaScript) {
                schemaScript = document.createElement('script');
                schemaScript.type = 'application/ld+json';
                schemaScript.setAttribute('data-gst-schema', 'true');
                document.head.appendChild(schemaScript);
            }
            
            schemaScript.textContent = JSON.stringify(schema, null, 2);
        },

        // Get interaction count for analytics
        getInteractionCount() {
            try {
                return parseInt(localStorage.getItem('gst_calculator_interactions') || '0');
            } catch (e) {
                return 0;
            }
        },

        // Increment interaction count
        incrementInteractionCount() {
            try {
                const count = this.getInteractionCount() + 1;
                localStorage.setItem('gst_calculator_interactions', count.toString());
                return count;
            } catch (e) {
                return 0;
            }
        },

        // Performance monitoring
        measurePerformance(operation, callback) {
            const start = performance.now();
            const result = callback();
            const duration = performance.now() - start;
            
            // Log performance metrics
            console.log(`Performance: ${operation} took ${duration.toFixed(2)}ms`);
            
            // Track slow operations
            if (duration > 1000) {
                this.trackEvent('performance_slow_operation', {
                    operation,
                    duration,
                    threshold: 1000
                });
            }
            
            return result;
        },

        // SEO-friendly error handling
        handleError(error, context) {
            console.error('GST Calculator Error:', error, context);
            
            this.trackEvent('error', {
                error: error.message || error,
                context,
                url: window.location.href,
                timestamp: Date.now()
            });
        },

        // Accessibility improvements
        enhanceAccessibility() {
            // Add skip link for keyboard navigation
            if (!document.querySelector('.gst-skip-link')) {
                const skipLink = document.createElement('a');
                skipLink.href = '#gst-calculator-container';
                skipLink.className = 'gst-skip-link';
                skipLink.textContent = 'Skip to GST Calculator';
                document.body.insertBefore(skipLink, document.body.firstChild);
            }
            
            // Add ARIA labels and roles
            const calculator = document.querySelector('.gst-calculator-container');
            if (calculator) {
                calculator.setAttribute('role', 'application');
                calculator.setAttribute('aria-label', 'GST Calculator for Indian businesses');
            }
            
            // Enhance form accessibility
            const form = document.querySelector('.gst-calculator-form');
            if (form) {
                form.setAttribute('role', 'form');
                form.setAttribute('aria-label', 'GST calculation form');
            }
        },

        // SEO-friendly URL handling
        updateURL(calculationData) {
            if (history.pushState) {
                const params = new URLSearchParams();
                if (calculationData.original_price) params.set('price', calculationData.original_price);
                if (calculationData.gst_rate) params.set('rate', calculationData.gst_rate);
                
                const newURL = `${window.location.pathname}?${params.toString()}`;
                history.pushState({}, '', newURL);
            }
        },

        // Parse URL parameters for SEO
        parseURLParameters() {
            const params = new URLSearchParams(window.location.search);
            return {
                price: params.get('price'),
                rate: params.get('rate')
            };
        }
    };

    // Main GST Calculator class
    class GSTCalculator {
        constructor() {
            this.init();
            this.cache = new Map();
            this.setupSEO();
        }

        init() {
            this.bindEvents();
            this.setupFormValidation();
            SEOUtils.enhanceAccessibility();
            this.loadFromURL();
        }

        setupSEO() {
            // Track page load
            SEOUtils.trackEvent('page_load', {
                url: window.location.href,
                referrer: document.referrer
            });
            
            // Parse URL parameters
            const urlParams = SEOUtils.parseURLParameters();
            if (urlParams.price || urlParams.rate) {
                this.populateFromURL(urlParams);
            }
        }

        loadFromURL() {
            const urlParams = SEOUtils.parseURLParameters();
            if (urlParams.price) {
                $('#gst-original-price').val(urlParams.price);
            }
            if (urlParams.rate) {
                $('#gst-rate').val(urlParams.rate);
            }
        }

        populateFromURL(params) {
            if (params.price) {
                $('#gst-original-price').val(params.price);
                this.validateOriginalPrice();
            }
            if (params.rate) {
                $('#gst-rate').val(params.rate);
                this.validateGSTRate();
            }
        }

        bindEvents() {
            // Calculate button click
            $(document).on('click', '#gst-calculate-btn', (e) => {
                e.preventDefault();
                SEOUtils.trackEvent('calculate_button_click');
                this.calculateGST();
            });

            // Enter key press on inputs
            $(document).on('keypress', '#gst-original-price, #gst-rate', (e) => {
                if (e.which === 13) {
                    e.preventDefault();
                    SEOUtils.trackEvent('calculate_enter_key');
                    this.calculateGST();
                }
            });

            // Real-time validation on input change
            $(document).on('input', '#gst-original-price', () => {
                this.validateOriginalPrice();
            });

            $(document).on('change', '#gst-rate', () => {
                this.validateGSTRate();
            });

            // Track form interactions
            $(document).on('focus', '.gst-calculator-form input, .gst-calculator-form select', () => {
                SEOUtils.trackEvent('form_field_focus');
            });

            $(document).on('blur', '.gst-calculator-form input, .gst-calculator-form select', () => {
                SEOUtils.trackEvent('form_field_blur');
            });
        }

        setupFormValidation() {
            // Add validation classes to form elements
            $('#gst-original-price').addClass('gst-input');
            $('#gst-rate').addClass('gst-input');
        }

        validateOriginalPrice() {
            const input = $('#gst-original-price');
            const value = parseFloat(input.val());
            
            input.removeClass('error success');
            
            if (input.val() === '') {
                return false;
            }
            
            if (isNaN(value) || value <= 0) {
                input.addClass('error');
                this.showError('Please enter a valid positive number for the original price.');
                SEOUtils.trackEvent('validation_error', { field: 'original_price', value: input.val() });
                return false;
            }
            
            input.addClass('success');
            this.hideError();
            return true;
        }

        validateGSTRate() {
            const select = $('#gst-rate');
            const value = select.val();
            
            select.removeClass('error success');
            
            if (value === '') {
                return false;
            }
            
            const validRates = ['5', '12', '18', '28'];
            if (!validRates.includes(value)) {
                select.addClass('error');
                this.showError('Please select a valid GST rate.');
                SEOUtils.trackEvent('validation_error', { field: 'gst_rate', value: value });
                return false;
            }
            
            select.addClass('success');
            this.hideError();
            return true;
        }

        validateForm() {
            const originalPriceValid = this.validateOriginalPrice();
            const gstRateValid = this.validateGSTRate();
            
            return originalPriceValid && gstRateValid;
        }

        calculateGST() {
            if (!this.validateForm()) {
                return;
            }

            const originalPrice = parseFloat($('#gst-original-price').val());
            const gstRate = parseFloat($('#gst-rate').val());

            // Check cache first
            const cacheKey = `${originalPrice}-${gstRate}`;
            if (SEO_CONFIG.performance.cacheResults && this.cache.has(cacheKey)) {
                const cachedResult = this.cache.get(cacheKey);
                this.handleCalculationSuccess(cachedResult);
                SEOUtils.trackEvent('calculation_cached');
                return;
            }

            this.showLoading();
            SEOUtils.incrementInteractionCount();

            // Track calculation start
            SEOUtils.trackEvent('calculation_start', {
                original_price: originalPrice,
                gst_rate: gstRate
            });

            SEOUtils.measurePerformance('gst_calculation', () => {
                $.ajax({
                    url: gst_calculator_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'gst_calculate',
                        nonce: gst_calculator_ajax.nonce,
                        original_price: originalPrice,
                        gst_rate: gstRate
                    },
                    success: (response) => {
                        if (response.success) {
                            // Cache the result
                            if (SEO_CONFIG.performance.cacheResults) {
                                this.cache.set(cacheKey, response.data);
                                
                                // Limit cache size
                                if (this.cache.size > SEO_CONFIG.performance.maxCacheSize) {
                                    const firstKey = this.cache.keys().next().value;
                                    this.cache.delete(firstKey);
                                }
                            }
                            
                            this.handleCalculationSuccess(response.data);
                            SEOUtils.updateStructuredData(response.data);
                            SEOUtils.updateURL(response.data);
                            
                            // Track successful calculation
                            SEOUtils.trackEvent('calculation_success', {
                                original_price: originalPrice,
                                gst_rate: gstRate,
                                gst_amount: response.data.gst_amount,
                                total_price: response.data.total_price
                            });
                        } else {
                            this.handleCalculationError(null, 'error', response.data);
                        }
                    },
                    error: (xhr, status, error) => {
                        this.handleCalculationError(xhr, status, error);
                        SEOUtils.handleError(error, 'calculation_ajax_error');
                    }
                });
            });
        }

        handleCalculationSuccess(response) {
            this.hideLoading();
            this.hideError();

            // Update results with enhanced accessibility
            const results = $('.gst-calculator-results');
            results.attr('role', 'region');
            results.attr('aria-label', 'GST calculation results');
            results.attr('aria-live', 'polite');

            $('#gst-amount').text(response.gst_amount);
            $('#total-price').text(response.total_price);
            $('#cgst-amount').text(response.cgst_amount);
            $('#sgst-amount').text(response.sgst_amount);

            this.showResults();
            this.scrollToResults();
            this.addSuccessAnimation();

            // Announce results to screen readers
            const announcement = `Calculation complete. GST amount is ${response.gst_amount}, total price is ${response.total_price}`;
            this.announceToScreenReader(announcement);
        }

        announceToScreenReader(message) {
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'polite');
            announcement.setAttribute('aria-atomic', 'true');
            announcement.className = 'sr-only';
            announcement.textContent = message;
            
            document.body.appendChild(announcement);
            
            setTimeout(() => {
                document.body.removeChild(announcement);
            }, 1000);
        }

        handleCalculationError(xhr, status, error) {
            this.hideLoading();
            
            let errorMessage = 'An error occurred while calculating GST. Please try again.';
            
            if (xhr && xhr.responseJSON && xhr.responseJSON.data) {
                errorMessage = xhr.responseJSON.data;
            } else if (error) {
                errorMessage = error;
            }
            
            this.showError(errorMessage);
            
            // Track error for SEO insights
            SEOUtils.trackEvent('calculation_error', {
                error: errorMessage,
                status: status,
                url: window.location.href
            });
        }

        showLoading() {
            $('.gst-calculator-loading').show();
            $('.gst-calculator-results').hide();
            
            // Announce loading to screen readers
            this.announceToScreenReader('Calculating GST amount, please wait.');
        }

        hideLoading() {
            $('.gst-calculator-loading').hide();
        }

        showResults() {
            $('.gst-calculator-results').show();
        }

        hideResults() {
            $('.gst-calculator-results').hide();
        }

        showError(message) {
            $('.gst-calculator-error').show().find('.error-message').text(message);
            
            // Announce error to screen readers
            this.announceToScreenReader(`Error: ${message}`);
        }

        hideError() {
            $('.gst-calculator-error').hide();
        }

        scrollToResults() {
            const results = $('.gst-calculator-results');
            if (results.length) {
                $('html, body').animate({
                    scrollTop: results.offset().top - 20
                }, 500);
            }
        }

        addSuccessAnimation() {
            $('.gst-calculator-results').addClass('highlight');
            setTimeout(() => {
                $('.gst-calculator-results').removeClass('highlight');
            }, 2000);
        }

        formatCurrency(amount) {
            return new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                minimumFractionDigits: 2
            }).format(amount);
        }

        validateNumberInput(input) {
            const value = input.value.replace(/[^\d.]/g, '');
            input.value = value;
        }
    }

    // Prompt Modal class
    class PromptModal {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Prompt button click
            $(document).on('click', '#gst-prompt-btn', (e) => {
                e.preventDefault();
                this.showModal();
            });

            // Close button click
            $(document).on('click', '#gst-prompt-close', (e) => {
                e.preventDefault();
                this.hideModal();
            });

            // Close modal when clicking outside
            $(document).on('click', '#gst-prompt-modal', (e) => {
                if (e.target.id === 'gst-prompt-modal') {
                    this.hideModal();
                }
            });

            // Close modal with Escape key
            $(document).on('keydown', (e) => {
                if (e.key === 'Escape' && $('#gst-prompt-modal').is(':visible')) {
                    this.hideModal();
                }
            });
        }

        showModal() {
            $('#gst-prompt-modal').fadeIn(300);
            this.loadPromptContent();
            
            // Prevent body scroll
            $('body').addClass('modal-open');
        }

        hideModal() {
            $('#gst-prompt-modal').fadeOut(300);
            
            // Restore body scroll
            $('body').removeClass('modal-open');
        }

        loadPromptContent() {
            // Show loading state
            $('#gst-prompt-content').html(`
                <div class="gst-prompt-loading">
                    <i class="fas fa-spinner fa-spin"></i>
                    <span>Loading requirements...</span>
                </div>
            `);

            // Prepare AJAX data
            const data = {
                action: 'gst_get_prompt',
                nonce: gst_calculator_ajax.nonce
            };

            // Make AJAX request
            $.ajax({
                url: gst_calculator_ajax.ajax_url,
                type: 'POST',
                data: data,
                dataType: 'json',
                timeout: 10000,
                success: (response) => {
                    this.handlePromptSuccess(response);
                },
                error: (xhr, status, error) => {
                    this.handlePromptError(xhr, status, error);
                }
            });
        }

        handlePromptSuccess(response) {
            if (response.success && response.data && response.data.content) {
                $('#gst-prompt-content').html(response.data.content);
                
                // Add smooth scroll to modal content
                this.enableSmoothScroll();
            } else {
                this.handlePromptError(null, 'error', 'Failed to load prompt content');
            }
        }

        handlePromptError(xhr, status, error) {
            let errorMessage = 'Failed to load the original requirements.';
            
            if (status === 'timeout') {
                errorMessage = 'Request timed out. Please check your connection and try again.';
            } else if (error) {
                errorMessage = 'Error: ' + error;
            }
            
            $('#gst-prompt-content').html(`
                <div class="gst-prompt-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span>${errorMessage}</span>
                </div>
            `);
        }

        enableSmoothScroll() {
            // Add smooth scrolling to modal content
            $('#gst-prompt-modal-body').on('scroll', function() {
                // Add scroll indicator if needed
                const scrollTop = $(this).scrollTop();
                const scrollHeight = $(this)[0].scrollHeight;
                const clientHeight = $(this).height();
                
                if (scrollTop + clientHeight >= scrollHeight - 10) {
                    $(this).addClass('scrolled-to-bottom');
                } else {
                    $(this).removeClass('scrolled-to-bottom');
                }
            });
        }
    }

    // Initialize calculator when document is ready
    $(document).ready(function() {
        // Check if GST calculator exists on the page
        if ($('.gst-calculator-container').length > 0) {
            new GSTCalculator();
            
            // Add some additional enhancements
            enhanceCalculator();
        }
        
        // Initialize prompt modal if prompt button exists
        if ($('#gst-prompt-btn').length > 0) {
            new PromptModal();
        }
    });

    // Additional enhancements
    function enhanceCalculator() {
        // Add input formatting for better UX
        $('#gst-original-price').on('input', function() {
            const value = $(this).val();
            if (value && !isNaN(value)) {
                // Format to 2 decimal places
                const formatted = parseFloat(value).toFixed(2);
                if (formatted !== value) {
                    $(this).val(formatted);
                }
            }
        });

        // Add tooltip functionality
        $('.gst-calculator-container').on('mouseenter', '.result-item', function() {
            $(this).addClass('hover');
        }).on('mouseleave', '.result-item', function() {
            $(this).removeClass('hover');
        });

        // Add keyboard navigation
        $('#gst-original-price, #gst-rate').on('keydown', function(e) {
            if (e.key === 'Tab') {
                // Handle tab navigation
                if (e.shiftKey) {
                    // Shift+Tab - previous element
                    if ($(this).attr('id') === 'gst-rate') {
                        $('#gst-original-price').focus();
                        e.preventDefault();
                    }
                } else {
                    // Tab - next element
                    if ($(this).attr('id') === 'gst-original-price') {
                        $('#gst-rate').focus();
                        e.preventDefault();
                    } else if ($(this).attr('id') === 'gst-rate') {
                        $('#gst-calculate-btn').focus();
                        e.preventDefault();
                    }
                }
            }
        });

        // Add accessibility improvements
        $('#gst-calculate-btn').attr('aria-label', 'Calculate GST amount based on entered values');
        $('#gst-original-price').attr('aria-describedby', 'original-price-help');
        $('#gst-rate').attr('aria-describedby', 'gst-rate-help');

        // Add help text (can be styled with CSS)
        if (!$('#original-price-help').length) {
            $('#gst-original-price').after('<small id="original-price-help" class="help-text">Enter the original price before GST</small>');
        }
        if (!$('#gst-rate-help').length) {
            $('#gst-rate').after('<small id="gst-rate-help" class="help-text">Select the applicable GST rate</small>');
        }

        // Mobile-specific enhancements
        enhanceMobileExperience();
    }

    // Mobile-specific enhancements
    function enhanceMobileExperience() {
        // Detect mobile device
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

        if (isMobile || isTouchDevice) {
            // Add touch-friendly interactions
            addTouchSupport();
            
            // Optimize for mobile viewport
            optimizeMobileViewport();
            
            // Add mobile-specific event handlers
            addMobileEventHandlers();
        }
    }

    // Add touch support
    function addTouchSupport() {
        // Prevent zoom on input focus (iOS)
        $('input, select').on('focus', function() {
            if (/iPhone|iPad|iPod/.test(navigator.userAgent)) {
                $(this).css('font-size', '16px');
            }
        });

        // Add touch feedback
        $('.gst-calculate-btn, .gst-prompt-btn').on('touchstart', function() {
            $(this).addClass('touch-active');
        }).on('touchend touchcancel', function() {
            $(this).removeClass('touch-active');
        });

        // Improve touch targets
        $('.gst-calculate-btn, .gst-prompt-btn').css({
            'min-height': '44px',
            'min-width': '44px'
        });

        // Add swipe support for modal
        let startX = 0;
        let startY = 0;
        
        $('#gst-prompt-modal').on('touchstart', function(e) {
            startX = e.originalEvent.touches[0].clientX;
            startY = e.originalEvent.touches[0].clientY;
        });

        $('#gst-prompt-modal').on('touchend', function(e) {
            const endX = e.originalEvent.changedTouches[0].clientX;
            const endY = e.originalEvent.changedTouches[0].clientY;
            const diffX = startX - endX;
            const diffY = startY - endY;

            // Swipe down to close modal
            if (Math.abs(diffY) > Math.abs(diffX) && diffY > 50) {
                $('#gst-prompt-close').click();
            }
        });
    }

    // Optimize mobile viewport
    function optimizeMobileViewport() {
        // Ensure proper viewport meta tag
        if (!$('meta[name="viewport"]').length) {
            $('head').append('<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">');
        }

        // Add mobile-specific CSS
        const mobileCSS = `
            <style>
                @media (max-width: 768px) {
                    .gst-calculator-container {
                        -webkit-overflow-scrolling: touch;
                    }
                    
                    .gst-prompt-modal {
                        -webkit-overflow-scrolling: touch;
                    }
                    
                    input, select, button {
                        -webkit-appearance: none;
                        border-radius: 0;
                    }
                    
                    .gst-calculate-btn, .gst-prompt-btn {
                        -webkit-tap-highlight-color: transparent;
                    }
                }
            </style>
        `;
        $('head').append(mobileCSS);
    }

    // Add mobile event handlers
    function addMobileEventHandlers() {
        // Prevent double-tap zoom on buttons
        $('.gst-calculate-btn, .gst-prompt-btn').on('touchend', function(e) {
            e.preventDefault();
            $(this).click();
        });

        // Add haptic feedback (if supported)
        if ('vibrate' in navigator) {
            $('.gst-calculate-btn').on('click', function() {
                navigator.vibrate(50);
            });
        }

        // Optimize scroll performance
        $('.gst-prompt-modal-body').css({
            '-webkit-overflow-scrolling': 'touch',
            'overflow-scrolling': 'touch'
        });

        // Add pull-to-refresh prevention
        let startY = 0;
        $(document).on('touchstart', function(e) {
            startY = e.originalEvent.touches[0].clientY;
        });

        $(document).on('touchmove', function(e) {
            const currentY = e.originalEvent.touches[0].clientY;
            const diffY = currentY - startY;
            
            // Prevent pull-to-refresh when modal is open
            if ($('#gst-prompt-modal').is(':visible') && diffY > 0) {
                e.preventDefault();
            }
        });
    }

    // Add CSS for additional enhancements
    const additionalCSS = `
        <style>
            .gst-input.error {
                border-color: #e53e3e !important;
                box-shadow: 0 0 0 3px rgba(229, 62, 62, 0.1) !important;
            }
            
            .gst-input.success {
                border-color: #38a169 !important;
                box-shadow: 0 0 0 3px rgba(56, 161, 105, 0.1) !important;
            }
            
            .success-animation {
                animation: successPulse 0.5s ease-in-out;
            }
            
            @keyframes successPulse {
                0% { transform: scale(1); }
                50% { transform: scale(1.02); }
                100% { transform: scale(1); }
            }
            
            .result-item.hover {
                transform: translateY(-3px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
            }
            
            .help-text {
                display: block;
                margin-top: 5px;
                font-size: 12px;
                color: #666;
                font-style: italic;
            }
            
            .gst-input:focus + .help-text {
                color: #667eea;
            }
            
            /* Modal specific styles */
            body.modal-open {
                overflow: hidden;
            }
            
            .gst-prompt-error {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 40px 20px;
                color: #e53e3e;
                gap: 15px;
                text-align: center;
            }
            
            .gst-prompt-error i {
                font-size: 24px;
            }
            
            .gst-prompt-error span {
                font-size: 14px;
                font-weight: 500;
            }
            
            .gst-prompt-modal-body.scrolled-to-bottom {
                box-shadow: inset 0 -10px 20px -10px rgba(0, 0, 0, 0.1);
            }
            
            /* Mobile enhancements */
            .touch-active {
                transform: scale(0.95) !important;
                transition: transform 0.1s ease;
            }
            
            /* Mobile-specific button styles */
            @media (max-width: 768px) {
                .gst-calculate-btn, .gst-prompt-btn {
                    -webkit-tap-highlight-color: transparent;
                    -webkit-touch-callout: none;
                    -webkit-user-select: none;
                    user-select: none;
                }
                
                .gst-calculate-btn:active, .gst-prompt-btn:active {
                    transform: scale(0.98);
                }
                
                /* Improve touch targets */
                input, select, button {
                    min-height: 44px;
                }
                
                /* Prevent zoom on input focus (iOS) */
                input[type="number"], input[type="text"], select {
                    font-size: 16px !important;
                }
                
                /* Smooth scrolling for mobile */
                .gst-calculator-container,
                .gst-prompt-modal-body {
                    -webkit-overflow-scrolling: touch;
                    overflow-scrolling: touch;
                }
            }
            
            /* High contrast mode support */
            @media (prefers-contrast: high) {
                .gst-calculator-container {
                    border-width: 2px;
                }
                
                .form-group input,
                .form-group select {
                    border-width: 2px;
                }
                
                .gst-calculate-btn,
                .gst-prompt-btn {
                    border: 2px solid currentColor;
                }
            }
            
            /* Print styles */
            @media print {
                .gst-calculator-container {
                    box-shadow: none;
                    border: 1px solid #ccc;
                }
                
                .gst-calculate-btn,
                .gst-prompt-btn {
                    display: none;
                }
                
                .gst-prompt-modal {
                    display: none !important;
                }
            }
        </style>
    `;
    
    // Inject additional CSS
    $('head').append(additionalCSS);

})(jQuery); 