<?php
/**
 * Debug Translation Script
 * Upload this to your WordPress root directory and access it via browser
 * to test if the translation functionality is working
 */

// Load WordPress
require_once('wp-config.php');
require_once('wp-load.php');

// Include the plugin file
require_once('wp-content/plugins/indian-language-switcher/indian-language-switcher.php');

echo "<h1>Translation Debug Test</h1>";

// Test the translation functionality
$test_text = "Hello, welcome to our website. This is a test of the translation system.";
$languages = array('hi', 'bn', 'te', 'ta', 'gu');

echo "<h2>Original Text:</h2>";
echo "<p><strong>$test_text</strong></p>";

echo "<h2>Translation Test:</h2>";

foreach ($languages as $lang) {
    echo "<h3>Language: $lang</h3>";
    
    // Create a temporary instance to test translation
    $translator = new IndianLanguageSwitcher();
    
    // Manually set the language
    $translator->current_language = $lang;
    
    // Test translation
    $translated = $translator->translate_content($test_text);
    
    echo "<p><strong>Translated:</strong> $translated</p>";
    
    // Test individual words
    $words = explode(' ', $test_text);
    echo "<p><strong>Word by word:</strong></p><ul>";
    foreach ($words as $word) {
        $word_translated = $translator->translate_content($word);
        echo "<li>'$word' -> '$word_translated'</li>";
    }
    echo "</ul>";
}

echo "<h2>Session and Cookie Test:</h2>";
echo "<p>Session language: " . (isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'Not set') . "</p>";
echo "<p>Cookie language: " . (isset($_COOKIE['ils_current_language']) ? $_COOKIE['ils_current_language'] : 'Not set') . "</p>";

echo "<h2>Translation Mappings Test:</h2>";
$translator = new IndianLanguageSwitcher();
$mappings = $translator->get_translation_mappings();

foreach ($mappings as $lang => $words) {
    echo "<h3>$lang:</h3>";
    echo "<ul>";
    foreach (array_slice($words, 0, 5) as $english => $translated) {
        echo "<li>'$english' -> '$translated'</li>";
    }
    echo "</ul>";
}
?> 