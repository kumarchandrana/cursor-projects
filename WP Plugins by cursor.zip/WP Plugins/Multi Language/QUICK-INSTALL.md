# 🚀 Quick Installation Guide - Indian Language Switcher

## Step 1: Create Plugin Directory
Create this folder in your WordPress:
```
wp-content/plugins/indian-language-switcher/
```

## Step 2: Upload Plugin Files
Upload these files to the plugin directory:

### Main Files:
- `indian-language-switcher.php` (main plugin file)
- `assets/js/ils-script.js`
- `assets/css/ils-style.css`
- `includes/class-ils-widget.php`
- `includes/class-ils-shortcode.php`
- `README.md`
- `INSTALLATION.md`

### Directory Structure:
```
wp-content/plugins/indian-language-switcher/
├── indian-language-switcher.php
├── assets/
│   ├── js/
│   │   └── ils-script.js
│   └── css/
│       └── ils-style.css
├── includes/
│   ├── class-ils-widget.php
│   └── class-ils-shortcode.php
├── README.md
└── INSTALLATION.md
```

## Step 3: Activate Plugin
1. Go to **WordPress Admin > Plugins**
2. Find **"Indian Language Switcher"** in the list
3. Click **"Activate"**

## Step 4: Find the Widget
After activation:
1. Go to **Appearance > Widgets**
2. Look for **"Indian Language Switcher"** in the available widgets
3. Drag it to any widget area (sidebar, footer, etc.)

## Step 5: Configure Widget
1. Click on the widget to expand it
2. Set your preferences:
   - Title (optional)
   - Display Style (dropdown, list, buttons)
   - Show Flags (yes/no)
   - Show Native Names (yes/no)
3. Click **"Save"**

## Alternative: Use Shortcode
If you can't find the widget, use the shortcode anywhere:
```
[indian_language_switcher]
```

## Troubleshooting:
- **Widget not appearing?** Make sure plugin is activated
- **Plugin not in list?** Check all files are uploaded correctly
- **PHP errors?** Check your error log

## Need Help?
Run the diagnostic script:
1. Upload `check-plugin.php` to your WordPress root
2. Visit `http://yoursite.com/check-plugin.php`
3. Follow the instructions it provides

---
**The widget will only appear in Appearance > Widgets AFTER the plugin is installed and activated!** 