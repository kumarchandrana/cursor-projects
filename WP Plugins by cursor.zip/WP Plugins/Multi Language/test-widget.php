<?php
/**
 * Test Widget - Simple widget to verify widget system works
 * Add this to your theme's functions.php or create a simple plugin
 */

// Add this to your theme's functions.php file
add_action('widgets_init', 'register_test_widget');

function register_test_widget() {
    register_widget('Test_Widget');
}

class Test_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'test_widget',
            'Test Widget',
            array('description' => 'A simple test widget')
        );
    }
    
    public function widget($args, $instance) {
        echo $args['before_widget'];
        echo $args['before_title'] . 'Test Widget' . $args['after_title'];
        echo '<p>This is a test widget. If you can see this, the widget system is working!</p>';
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        echo '<p>This is a test widget form.</p>';
    }
    
    public function update($new_instance, $old_instance) {
        return $new_instance;
    }
} 