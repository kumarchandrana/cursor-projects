<?php
/**
 * Translation Test Page
 * Upload this to your WordPress root directory and access it via browser
 * to test if the translation functionality is working
 */

// Load WordPress
require_once('wp-config.php');
require_once('wp-load.php');

// Check if plugin is active
if (!class_exists('IndianLanguageSwitcher')) {
    echo "<h1>Plugin Not Found</h1>";
    echo "<p>The Indian Language Switcher plugin is not active or not found.</p>";
    exit;
}

// Create instance and test
$ils = new IndianLanguageSwitcher();

echo "<h1>Indian Language Switcher - Translation Test</h1>";

// Test basic translation
$test_texts = array(
    "Hello welcome to our website",
    "About contact home",
    "Read more search menu",
    "Blog news language"
);

echo "<h2>Translation Test Results:</h2>";

foreach ($test_texts as $text) {
    echo "<h3>Original: '$text'</h3>";
    $results = $ils->test_translation($text);
    
    echo "<table border='1' style='border-collapse: collapse; margin: 10px 0;'>";
    echo "<tr><th>Language</th><th>Translated</th></tr>";
    
    foreach ($results as $lang => $translated) {
        $lang_name = $ils->supported_languages[$lang]['name'];
        $highlight = ($translated !== $text) ? "style='background-color: #d4edda;'" : "";
        echo "<tr $highlight>";
        echo "<td><strong>$lang_name ($lang)</strong></td>";
        echo "<td>$translated</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Test current language detection
echo "<h2>Current Language Detection:</h2>";
echo "<p>Current Language: <strong>" . $ils->current_language . "</strong></p>";
echo "<p>Session Language: " . (isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'Not set') . "</p>";
echo "<p>Cookie Language: " . (isset($_COOKIE['ils_current_language']) ? $_COOKIE['ils_current_language'] : 'Not set') . "</p>";

// Test supported languages
echo "<h2>Supported Languages:</h2>";
echo "<ul>";
foreach ($ils->supported_languages as $code => $lang) {
    echo "<li><strong>$code</strong> - $lang[name] ($lang[native_name]) $lang[flag]</li>";
}
echo "</ul>";

// Test translation mappings
echo "<h2>Translation Mappings Sample:</h2>";
$mappings = $ils->get_translation_mappings();
foreach (array_slice($mappings, 0, 3) as $lang => $words) {
    echo "<h3>$lang:</h3>";
    echo "<ul>";
    foreach (array_slice($words, 0, 5) as $english => $translated) {
        echo "<li>'$english' → '$translated'</li>";
    }
    echo "</ul>";
}

echo "<h2>Instructions:</h2>";
echo "<ol>";
echo "<li>If you see translations in the table above, the translation system is working.</li>";
echo "<li>If all translations show the same as the original text, there's an issue with the translation mappings or logic.</li>";
echo "<li>Check that the plugin is properly activated in WordPress admin.</li>";
echo "<li>Try switching languages using the language switcher on your main site.</li>";
echo "</ol>";

echo "<p><a href='../'>← Back to WordPress Site</a></p>";
?> 