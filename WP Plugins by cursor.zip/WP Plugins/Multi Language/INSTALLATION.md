# Indian Language Switcher - Installation Guide

## Quick Installation

### Step 1: Upload Plugin
1. Download the plugin files
2. Upload the entire `indian-language-switcher` folder to your WordPress site at:
   ```
   wp-content/plugins/indian-language-switcher/
   ```

### Step 2: Activate Plugin
1. Go to WordPress Admin Dashboard
2. Navigate to **Plugins > Installed Plugins**
3. Find "Indian Language Switcher"
4. Click **Activate**

### Step 3: Verify Installation
1. Look for the floating language switcher in the top-right corner of your site
2. If you don't see it, try adding the shortcode `[indian_language_switcher]` to any post
3. Or add the widget to any widget area

## System Requirements

- **WordPress:** 4.0 or higher
- **PHP:** 5.6 or higher
- **jQuery:** Included with WordPress (usually enabled by default)

## Installation Methods

### Method 1: Manual Upload (Recommended)
1. Download the plugin files
2. Extract the ZIP file
3. Upload the `indian-language-switcher` folder to `wp-content/plugins/`
4. Activate the plugin in WordPress Admin

### Method 2: WordPress Admin Upload
1. Go to **Plugins > Add New**
2. Click **Upload Plugin**
3. Choose the plugin ZIP file
4. Click **Install Now**
5. Click **Activate Plugin**

### Method 3: FTP Upload
1. Connect to your server via FTP
2. Navigate to `wp-content/plugins/`
3. Upload the `indian-language-switcher` folder
4. Activate the plugin in WordPress Admin

## Post-Installation Setup

### 1. Check Plugin Activation
- Go to **Plugins > Installed Plugins**
- Look for "Indian Language Switcher"
- Status should show "Active"

### 2. Test Language Switcher
- Visit your website
- Look for the floating language switcher (top-right corner)
- Try clicking on different languages
- Check if the page reloads and shows translated content

### 3. Alternative Display Methods
If the floating switcher doesn't appear:

**Option A: Use Shortcode**
- Add `[indian_language_switcher]` to any post or page
- This displays the switcher inline

**Option B: Use Widget**
- Go to **Appearance > Widgets**
- Find "Indian Language Switcher" widget
- Add it to any widget area

**Option C: Use Different Styles**
- Shortcode: `[indian_language_switcher style="buttons"]`
- Shortcode: `[indian_language_switcher style="list"]`
- Shortcode: `[indian_language_switcher style="flags"]`

## Troubleshooting Installation

### Plugin Not Appearing in Admin
**Solution:**
1. Check if the plugin folder is in the correct location
2. Verify all files are present:
   - `indian-language-switcher.php`
   - `assets/js/ils-script.js`
   - `assets/css/ils-style.css`
   - `includes/class-ils-widget.php`
   - `includes/class-ils-shortcode.php`

### Plugin Won't Activate
**Possible Causes:**
1. **PHP Version:** Update to PHP 5.6 or higher
2. **WordPress Version:** Update to WordPress 4.0 or higher
3. **File Permissions:** Set files to 644, directories to 755
4. **Memory Limit:** Increase PHP memory limit

### Language Switcher Not Visible
**Solutions:**
1. Check browser console for JavaScript errors
2. Try adding the shortcode to a post
3. Check if your theme loads jQuery
4. Try switching to a default theme temporarily

### Language Switching Not Working
**Solutions:**
1. Check browser console for AJAX errors
2. Verify WordPress AJAX is working
3. Check if sessions are enabled on your server
4. Try refreshing the page after switching languages

## Configuration

### Default Settings
The plugin works out of the box with default settings:
- Default language: English
- Floating switcher position: Top-right corner
- Supported languages: 18 Indian languages
- Translation method: Basic word replacement

### Customization Options
1. **Widget Settings:**
   - Display style (dropdown, list, buttons)
   - Show/hide flags
   - Show/hide native names

2. **Shortcode Options:**
   - `style="dropdown|list|buttons|flags"`
   - `show_flags="true|false"`
   - `show_native_names="true|false"`

3. **CSS Customization:**
   - Edit `assets/css/ils-style.css`
   - Override styles in your theme

## Testing the Installation

### Basic Test
1. Activate the plugin
2. Visit your website
3. Look for the language switcher
4. Click on a different language
5. Check if the page reloads
6. Look for translated words (e.g., "Hello" → "नमस्ते" in Hindi)

### Advanced Test
1. Create a test post with these words:
   - "Hello welcome home about contact"
2. Switch to Hindi language
3. Check if words translate to:
   - "नमस्ते स्वागत है होम हमारे बारे में संपर्क"

### Widget Test
1. Go to **Appearance > Widgets**
2. Add "Indian Language Switcher" widget to sidebar
3. Test different display styles
4. Verify language switching works

## Security Considerations

### File Permissions
Set correct permissions:
```bash
# Files
chmod 644 wp-content/plugins/indian-language-switcher/*.php
chmod 644 wp-content/plugins/indian-language-switcher/assets/css/*
chmod 644 wp-content/plugins/indian-language-switcher/assets/js/*

# Directories
chmod 755 wp-content/plugins/indian-language-switcher/
chmod 755 wp-content/plugins/indian-language-switcher/assets/
chmod 755 wp-content/plugins/indian-language-switcher/includes/
```

### Security Features
- Nonce verification for AJAX requests
- Input sanitization
- Output escaping
- WordPress coding standards compliance

## Performance Optimization

### Recommended Settings
1. **Caching:** The plugin works with most caching plugins
2. **CDN:** CSS/JS files can be served via CDN
3. **Minification:** Consider minifying CSS/JS for production

### Memory Usage
- Plugin uses minimal memory
- Translation mappings are loaded on demand
- Session data is lightweight

## Support

### Getting Help
If you encounter issues:

1. **Check the troubleshooting guide** (`TROUBLESHOOTING.md`)
2. **Run the verification script** (`verify-installation.php`)
3. **Test with debug tools** provided
4. **Check browser console** for errors
5. **Enable WordPress debugging** for detailed logs

### Common Issues
- **Plugin not showing:** Check activation status
- **Language not switching:** Check browser console for errors
- **Translation not working:** Check if basic words like "hello" translate
- **Styling issues:** Check CSS loading in browser

### Debug Mode
Enable WordPress debugging for detailed error messages:
```php
// Add to wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

## Uninstallation

### Remove Plugin
1. Go to **Plugins > Installed Plugins**
2. Find "Indian Language Switcher"
3. Click **Deactivate**
4. Click **Delete**

### Clean Up
The plugin doesn't create database tables, so no cleanup is needed. However, you may want to:
1. Remove any shortcodes from posts
2. Remove widgets from widget areas
3. Clear any cached content

## Next Steps

After successful installation:

1. **Test all features** thoroughly
2. **Customize styling** if needed
3. **Add shortcodes** to important pages
4. **Configure widgets** for better placement
5. **Monitor performance** and user feedback

---

**Note:** This plugin provides basic language switching with word replacement. For full translation capabilities, consider integrating with Google Translate API or similar services. 