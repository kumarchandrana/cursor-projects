<?php
/**
 * Plugin Installation Checker
 * 
 * This script will help diagnose why the widget isn't appearing.
 * Upload this to your WordPress root directory and visit it in your browser.
 */

// Try to load WordPress
if (!defined('ABSPATH')) {
    $wp_load_path = dirname(__FILE__) . '/wp-load.php';
    if (file_exists($wp_load_path)) {
        require_once($wp_load_path);
    } else {
        echo "<h2>❌ WordPress Not Found</h2>";
        echo "<p>Please place this file in your WordPress root directory.</p>";
        exit;
    }
}

echo "<h1>🔍 Indian Language Switcher - Installation Checker</h1>";

// Check if plugin directory exists
$plugin_dir = WP_PLUGIN_DIR . '/indian-language-switcher/';
if (!is_dir($plugin_dir)) {
    echo "<h2>❌ Plugin Directory Missing</h2>";
    echo "<p>The plugin directory <code>$plugin_dir</code> does not exist.</p>";
    echo "<p><strong>Solution:</strong> Create the directory and upload all plugin files.</p>";
    echo "<hr>";
    echo "<h3>Required Directory Structure:</h3>";
    echo "<pre>";
    echo "wp-content/plugins/indian-language-switcher/\n";
    echo "├── indian-language-switcher.php\n";
    echo "├── assets/\n";
    echo "│   ├── js/ils-script.js\n";
    echo "│   └── css/ils-style.css\n";
    echo "├── includes/\n";
    echo "│   ├── class-ils-widget.php\n";
    echo "│   └── class-ils-shortcode.php\n";
    echo "├── README.md\n";
    echo "└── INSTALLATION.md\n";
    echo "</pre>";
    exit;
}

echo "<h2>✅ Plugin Directory Found</h2>";

// Check required files
$required_files = array(
    'indian-language-switcher.php',
    'assets/js/ils-script.js',
    'assets/css/ils-style.css',
    'includes/class-ils-widget.php',
    'includes/class-ils-shortcode.php'
);

$missing_files = array();
foreach ($required_files as $file) {
    $file_path = $plugin_dir . $file;
    if (!file_exists($file_path)) {
        $missing_files[] = $file;
    }
}

if (!empty($missing_files)) {
    echo "<h2>❌ Missing Files</h2>";
    echo "<p>The following files are missing:</p>";
    echo "<ul>";
    foreach ($missing_files as $file) {
        echo "<li><code>$file</code></li>";
    }
    echo "</ul>";
    echo "<p><strong>Solution:</strong> Upload all missing files to the plugin directory.</p>";
} else {
    echo "<h2>✅ All Required Files Found</h2>";
}

// Check if plugin is activated
$active_plugins = get_option('active_plugins');
$plugin_file = 'indian-language-switcher/indian-language-switcher.php';
$is_active = in_array($plugin_file, $active_plugins);

if (!$is_active) {
    echo "<h2>❌ Plugin Not Activated</h2>";
    echo "<p>The plugin is installed but not activated.</p>";
    echo "<p><strong>Solution:</strong></p>";
    echo "<ol>";
    echo "<li>Go to <a href='" . admin_url('plugins.php') . "'>WordPress Admin > Plugins</a></li>";
    echo "<li>Find 'Indian Language Switcher' in the list</li>";
    echo "<li>Click 'Activate'</li>";
    echo "</ol>";
} else {
    echo "<h2>✅ Plugin is Activated</h2>";
}

// Check if widget is registered
if ($is_active) {
    global $wp_widget_factory;
    $widget_exists = isset($wp_widget_factory->widgets['ILS_Language_Switcher_Widget']);
    
    if (!$widget_exists) {
        echo "<h2>❌ Widget Not Registered</h2>";
        echo "<p>The widget class is not properly registered.</p>";
        echo "<p><strong>Possible Issues:</strong></p>";
        echo "<ul>";
        echo "<li>PHP errors in the plugin files</li>";
        echo "<li>Missing includes</li>";
        echo "<li>Class name mismatch</li>";
        echo "</ul>";
        
        // Check for PHP errors
        echo "<h3>Checking for PHP Errors:</h3>";
        $error_log = ini_get('error_log');
        if ($error_log && file_exists($error_log)) {
            $errors = file_get_contents($error_log);
            if (strpos($errors, 'indian-language-switcher') !== false) {
                echo "<p><strong>Found errors in log:</strong></p>";
                echo "<pre>" . htmlspecialchars($errors) . "</pre>";
            } else {
                echo "<p>No errors found in log.</p>";
            }
        }
    } else {
        echo "<h2>✅ Widget is Registered</h2>";
        echo "<p>The widget should appear in <a href='" . admin_url('widgets.php') . "'>Appearance > Widgets</a></p>";
    }
}

// Check WordPress version
$wp_version = get_bloginfo('version');
echo "<h2>📊 System Information</h2>";
echo "<ul>";
echo "<li><strong>WordPress Version:</strong> $wp_version</li>";
echo "<li><strong>PHP Version:</strong> " . phpversion() . "</li>";
echo "<li><strong>Plugin Directory:</strong> $plugin_dir</li>";
echo "</ul>";

echo "<hr>";
echo "<h2>🔧 Next Steps</h2>";
echo "<ol>";
echo "<li>Make sure all files are uploaded correctly</li>";
echo "<li>Activate the plugin if not already activated</li>";
echo "<li>Clear browser cache</li>";
echo "<li>Check for PHP errors in your error log</li>";
echo "<li>Go to <a href='" . admin_url('widgets.php') . "'>Appearance > Widgets</a> to find the widget</li>";
echo "</ol>";

echo "<p><em>Delete this file after troubleshooting is complete.</em></p>";
?> 