<?php
/**
 * Plugin Name: Indian Language Switcher
 * Plugin URI: https://example.com/indian-language-switcher
 * Description: A comprehensive language switcher plugin supporting all Indian languages. Allows users to switch between different Indian languages and translates content accordingly.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: indian-language-switcher
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ILS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ILS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ILS_PLUGIN_VERSION', '1.0.0');

class IndianLanguageSwitcher {
    
    private $supported_languages;
    private $current_language;
    // Cache plugin settings to avoid repeated get_option calls
    private $settings_cache;
    
    public function __construct() {
        $this->init_supported_languages();
        $this->init_hooks();
    }
    
    private function init_supported_languages() {
        $this->supported_languages = array(
            'en' => array(
                'name' => 'English',
                'native_name' => 'English',
                'flag' => '🇮🇳',
                'code' => 'en'
            ),
            'hi' => array(
                'name' => 'Hindi',
                'native_name' => 'हिन्दी',
                'flag' => '🇮🇳',
                'code' => 'hi'
            ),
            'bn' => array(
                'name' => 'Bengali',
                'native_name' => 'বাংলা',
                'flag' => '🇮🇳',
                'code' => 'bn'
            ),
            'te' => array(
                'name' => 'Telugu',
                'native_name' => 'తెలుగు',
                'flag' => '🇮🇳',
                'code' => 'te'
            ),
            'mr' => array(
                'name' => 'Marathi',
                'native_name' => 'मराठी',
                'flag' => '🇮🇳',
                'code' => 'mr'
            ),
            'ta' => array(
                'name' => 'Tamil',
                'native_name' => 'தமிழ்',
                'flag' => '🇮🇳',
                'code' => 'ta'
            ),
            'gu' => array(
                'name' => 'Gujarati',
                'native_name' => 'ગુજરાતી',
                'flag' => '🇮🇳',
                'code' => 'gu'
            ),
            'kn' => array(
                'name' => 'Kannada',
                'native_name' => 'ಕನ್ನಡ',
                'flag' => '🇮🇳',
                'code' => 'kn'
            ),
            'ml' => array(
                'name' => 'Malayalam',
                'native_name' => 'മലയാളം',
                'flag' => '🇮🇳',
                'code' => 'ml'
            ),
            'pa' => array(
                'name' => 'Punjabi',
                'native_name' => 'ਪੰਜਾਬੀ',
                'flag' => '🇮🇳',
                'code' => 'pa'
            ),
            'or' => array(
                'name' => 'Odia',
                'native_name' => 'ଓଡ଼ିଆ',
                'flag' => '🇮🇳',
                'code' => 'or'
            ),
            'as' => array(
                'name' => 'Assamese',
                'native_name' => 'অসমীয়া',
                'flag' => '🇮🇳',
                'code' => 'as'
            ),
            'ur' => array(
                'name' => 'Urdu',
                'native_name' => 'اردو',
                'flag' => '🇮🇳',
                'code' => 'ur'
            ),
            'sa' => array(
                'name' => 'Sanskrit',
                'native_name' => 'संस्कृतम्',
                'flag' => '🇮🇳',
                'code' => 'sa'
            ),
            'ne' => array(
                'name' => 'Nepali',
                'native_name' => 'नेपाली',
                'flag' => '🇮🇳',
                'code' => 'ne'
            ),
            'sd' => array(
                'name' => 'Sindhi',
                'native_name' => 'सिन्धी',
                'flag' => '🇮🇳',
                'code' => 'sd'
            ),
            'ks' => array(
                'name' => 'Kashmiri',
                'native_name' => 'कॉशुर',
                'flag' => '🇮🇳',
                'code' => 'ks'
            ),
            'dv' => array(
                'name' => 'Maldivian',
                'native_name' => 'ދިވެހި',
                'flag' => '🇮🇳',
                'code' => 'dv'
            )
        );
    }
    
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        // Render switcher depending on selected display style
        add_action('wp_footer', array($this, 'render_switcher_footer'));
        // Render early in body for topbar placement (if theme supports wp_body_open)
        add_action('wp_body_open', array($this, 'render_switcher_topbar'), 5);
        add_action('wp_ajax_ils_switch_language', array($this, 'ajax_switch_language'));
        add_action('wp_ajax_nopriv_ils_switch_language', array($this, 'ajax_switch_language'));
        add_action('wp_head', array($this, 'add_meta_tags'));
        
        // Add translation filters after init to ensure current_language is set
        add_action('wp_loaded', array($this, 'add_translation_filters'));
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Include widget and shortcode
        require_once ILS_PLUGIN_PATH . 'includes/class-ils-widget.php';
        require_once ILS_PLUGIN_PATH . 'includes/class-ils-shortcode.php';
        
        // Register widget
        add_action('widgets_init', array($this, 'register_widget'));
    }
    
    public function init() {
        // Start session if not already started
        if (!session_id()) {
            session_start();
        }
        
        // Set current language from session, cookie, or default to English
        if (isset($_SESSION['ils_current_language'])) {
            $this->current_language = $_SESSION['ils_current_language'];
        } elseif (isset($_COOKIE['ils_current_language'])) {
            $this->current_language = $_COOKIE['ils_current_language'];
        } else {
            $this->current_language = 'en';
        }
        
        // Validate language code
        if (!array_key_exists($this->current_language, $this->supported_languages)) {
            $this->current_language = 'en';
        }
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('ils-script', ILS_PLUGIN_URL . 'assets/js/ils-script.js', array('jquery'), ILS_PLUGIN_VERSION, true);
        wp_enqueue_style('ils-style', ILS_PLUGIN_URL . 'assets/css/ils-style.css', array(), ILS_PLUGIN_VERSION);
        
        $options = get_option('ils_settings');
        $use_google_widget = !empty($options['use_google_widget']);
        $display_style = isset($options['display_style']) ? $options['display_style'] : 'floating';
        $languages_list = implode(',', array_keys($this->supported_languages));
        $site_lang = get_bloginfo('language');
        $page_language = substr($site_lang, 0, 2);

        wp_localize_script('ils-script', 'ils_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ils_nonce'),
            'current_language' => $this->current_language,
            'use_google_widget' => $use_google_widget,
            'display_style' => $display_style,
            'languages_list' => $languages_list,
            'page_language' => $page_language
        ));
    }

    public function render_switcher_topbar() {
        $options = get_option('ils_settings');
        $display_style = isset($options['display_style']) ? $options['display_style'] : 'floating';
        if ($display_style === 'topbar') {
            $this->add_language_switcher();
        }
    }

    public function render_switcher_footer() {
        $options = get_option('ils_settings');
        $display_style = isset($options['display_style']) ? $options['display_style'] : 'floating';
        if ($display_style !== 'topbar') {
            $this->add_language_switcher();
        }
    }
    
    public function add_language_switcher() {
        $current_lang = $this->current_language;
        $languages = $this->supported_languages;
        $options = get_option('ils_settings');
        $display_style = isset($options['display_style']) ? $options['display_style'] : 'floating';
        
        $container_class = ($display_style === 'topbar') ? 'ils-language-switcher ils-topbar' : 'ils-language-switcher';
        echo '<div id="ils-language-switcher" class="' . $container_class . '">';
        echo '<div class="ils-current-language" onclick="toggleLanguageDropdown()">';
        echo '<span class="ils-flag">' . $languages[$current_lang]['flag'] . '</span>';
        echo '<span class="ils-language-name">' . $languages[$current_lang]['native_name'] . '</span>';
        echo '<span class="ils-dropdown-arrow">▼</span>';
        echo '</div>';
        echo '<div class="ils-language-dropdown" id="ils-language-dropdown">';
        
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_lang) ? 'active' : '';
            echo '<div class="ils-language-option ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            echo '<span class="ils-flag">' . $language['flag'] . '</span>';
            echo '<span class="ils-language-name">' . $language['native_name'] . '</span>';
            echo '<span class="ils-language-english">(' . $language['name'] . ')</span>';
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
        // Hidden container for Google Website Translator element (if enabled)
        echo '<div id="ils-google-element" style="display:none"></div>';
    }
    
    public function ajax_switch_language() {
        check_ajax_referer('ils_nonce', 'nonce');
        
        $language = sanitize_text_field($_POST['language']);
        
        if (array_key_exists($language, $this->supported_languages)) {
            // Start session if not already started
            if (!session_id()) {
                session_start();
            }
            
            // Set session and cookie
            $_SESSION['ils_current_language'] = $language;
            setcookie('ils_current_language', $language, time() + (86400 * 30), '/'); // 30 days
            
            $this->current_language = $language;
            
            // Force refresh translation filters
            $this->refresh_translation_filters();
            
            // Update the language switcher display
            $languages = $this->supported_languages;
            $current_lang_data = $languages[$language];
            
            wp_send_json_success(array(
                'message' => 'Language switched successfully',
                'language' => $language,
                'language_name' => $current_lang_data['native_name'],
                'language_flag' => $current_lang_data['flag']
            ));
        } else {
            wp_send_json_error('Invalid language code');
        }
    }
    
    public function add_meta_tags() {
        $current_lang = $this->current_language;
        echo '<meta name="language" content="' . $current_lang . '">';
        echo '<html lang="' . $current_lang . '">';
    }
    
    public function add_translation_filters() {
        // Only add translation filters if we're not in admin and current_language is set
        if (!is_admin() && !empty($this->current_language)) {
            add_filter('the_content', array($this, 'translate_content'), 10);
            add_filter('the_title', array($this, 'translate_title'), 10);
            add_filter('get_the_excerpt', array($this, 'translate_excerpt'), 10);
            
            // Also add filters for other common content areas
            add_filter('the_excerpt', array($this, 'translate_excerpt'), 10);
            add_filter('widget_title', array($this, 'translate_title'), 10);
            add_filter('widget_text', array($this, 'translate_content'), 10);
        }
    }
    
    public function refresh_translation_filters() {
        // Remove existing filters first
        remove_filter('the_content', array($this, 'translate_content'), 10);
        remove_filter('the_title', array($this, 'translate_title'), 10);
        remove_filter('get_the_excerpt', array($this, 'translate_excerpt'), 10);
        remove_filter('the_excerpt', array($this, 'translate_excerpt'), 10);
        remove_filter('widget_title', array($this, 'translate_title'), 10);
        remove_filter('widget_text', array($this, 'translate_content'), 10);
        
        // Re-add filters with current language
        $this->add_translation_filters();
    }
    
    public function translate_content($content) {
        if (is_admin()) {
            return $content;
        }
        
        // Skip if no content or current language is English
        if (empty($content) || $this->current_language === 'en') {
            return $content;
        }
        
        // Debug: Log translation attempts
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("ILS Translation Debug - Content: " . substr($content, 0, 100) . " | Language: " . $this->current_language);
        }
        
        // This is a simplified translation - in a real implementation,
        // you would integrate with a translation service like Google Translate API
        $translated = $this->translate_text($content, $this->current_language);
        
        // Debug: Log translation result
        if (defined('WP_DEBUG') && WP_DEBUG && $translated !== $content) {
            error_log("ILS Translation Applied - Original: " . substr($content, 0, 100) . " | Translated: " . substr($translated, 0, 100));
        }
        
        return $translated;
    }
    
    public function translate_title($title) {
        if (is_admin()) {
            return $title;
        }
        
        return $this->translate_text($title, $this->current_language);
    }
    
    public function translate_excerpt($excerpt) {
        if (is_admin()) {
            return $excerpt;
        }
        
        return $this->translate_text($excerpt, $this->current_language);
    }
    
    private function translate_text($text, $target_language) {
        if ($target_language === 'en' || empty($text)) {
            return $text;
        }

        // Attempt Google Translate API if enabled
        if ($this->should_use_api_translation()) {
            $api = $this->translate_text_with_api($text, $target_language);
            if (is_string($api) && $api !== '') {
                return $api;
            }
        }

        // Fallback to built-in mappings
        $translations = $this->get_translation_mappings();
        if (!isset($translations[$target_language])) {
            return $text;
        }
        $translated_text = $text;
        foreach ($translations[$target_language] as $english => $translated) {
            $translated_text = preg_replace('/\b' . preg_quote($english, '/') . '\b/i', $translated, $translated_text);
        }
        return $translated_text;
    }

    private function should_use_api_translation() {
        if ($this->settings_cache === null) {
            $this->settings_cache = get_option('ils_settings');
        }
        $enabled = !empty($this->settings_cache['enable_api']);
        $apiKey = isset($this->settings_cache['api_key']) ? trim($this->settings_cache['api_key']) : '';
        return $enabled && $apiKey !== '';
    }

    private function translate_text_with_api($text, $target_language) {
        if ($this->settings_cache === null) {
            $this->settings_cache = get_option('ils_settings');
        }

        $cacheTtlHours = isset($this->settings_cache['cache_ttl']) ? intval($this->settings_cache['cache_ttl']) : 12;
        $cacheKey = 'ils_tr_' . md5($target_language . ':' . $text);
        if ($cacheTtlHours > 0) {
            $cached = get_transient($cacheKey);
            if ($cached !== false) {
                return $cached;
            }
        }

        $apiKey = isset($this->settings_cache['api_key']) ? trim($this->settings_cache['api_key']) : '';
        if ($apiKey === '') {
            return '';
        }

        $endpoint = 'https://translation.googleapis.com/language/translate/v2?key=' . rawurlencode($apiKey);
        $chunks = $this->split_text_into_chunks($text, 4000);
        $body = array(
            'target' => $target_language,
            'format' => 'html',
        );
        foreach ($chunks as $chunk) {
            $body['q'][] = $chunk;
        }

        $response = wp_remote_post($endpoint, array(
            'timeout' => 15,
            'headers' => array('Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8'),
            'body' => $body,
        ));

        if (is_wp_error($response)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ILS Translate API error: ' . $response->get_error_message());
            }
            return '';
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw = wp_remote_retrieve_body($response);
        if ($code !== 200 || empty($raw)) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ILS Translate API HTTP ' . $code . ' body: ' . substr($raw, 0, 200));
            }
            return '';
        }

        $json = json_decode($raw, true);
        if (!isset($json['data']['translations'])) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('ILS Translate API invalid response');
            }
            return '';
        }

        $translatedChunks = array();
        foreach ($json['data']['translations'] as $item) {
            $translatedText = isset($item['translatedText']) ? $item['translatedText'] : '';
            $translatedChunks[] = html_entity_decode($translatedText, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        $result = implode('', $translatedChunks);

        if ($cacheTtlHours > 0 && $result !== '') {
            set_transient($cacheKey, $result, $cacheTtlHours * HOUR_IN_SECONDS);
        }

        return $result;
    }

    private function split_text_into_chunks($text, $maxLength) {
        $chunks = array();
        $length = strlen($text);
        if ($length <= $maxLength) {
            return array($text);
        }
        $offset = 0;
        while ($offset < $length) {
            $slice = substr($text, $offset, $maxLength);
            $breakPos = max(strrpos($slice, ' '), strrpos($slice, '>'));
            if ($breakPos === false || $breakPos < ($maxLength * 0.6)) {
                $breakPos = strlen($slice);
            }
            $chunks[] = substr($text, $offset, $breakPos);
            $offset += $breakPos;
        }
        return $chunks;
    }
    
    private function get_translation_mappings() {
        return array(
            'hi' => array(
                'hello' => 'नमस्ते',
                'welcome' => 'स्वागत है',
                'home' => 'होम',
                'about' => 'हमारे बारे में',
                'contact' => 'संपर्क',
                'read more' => 'और पढ़ें',
                'search' => 'खोजें',
                'menu' => 'मेनू',
                'blog' => 'ब्लॉग',
                'news' => 'समाचार',
                'language' => 'भाषा',
                'select language' => 'भाषा चुनें',
                'english' => 'अंग्रेज़ी',
                'hindi' => 'हिंदी',
                'bengali' => 'बंगाली',
                'telugu' => 'तेलुगु',
                'tamil' => 'तमिल',
                'gujarati' => 'गुजराती',
                'kannada' => 'कन्नड़',
                'malayalam' => 'मलयालम',
                'punjabi' => 'पंजाबी',
                'marathi' => 'मराठी',
                'odia' => 'ओड़िया',
                'assamese' => 'असमिया',
                'urdu' => 'उर्दू',
                'sanskrit' => 'संस्कृत',
                'nepali' => 'नेपाली',
                'sindhi' => 'सिंधी',
                'kashmiri' => 'कश्मीरी',
                'maldivian' => 'मालदीवी',
                'website' => 'वेबसाइट',
                'page' => 'पेज',
                'post' => 'पोस्ट',
                'article' => 'लेख',
                'title' => 'शीर्षक',
                'content' => 'सामग्री',
                'text' => 'टेक्स्ट',
                'word' => 'शब्द',
                'click' => 'क्लिक करें',
                'here' => 'यहाँ',
                'this' => 'यह',
                'that' => 'वह',
                'is' => 'है',
                'are' => 'हैं',
                'was' => 'था',
                'were' => 'थे',
                'will' => 'होगा',
                'can' => 'सकता है',
                'should' => 'चाहिए',
                'would' => 'होगा',
                'could' => 'सकता था',
                'may' => 'सकता है',
                'might' => 'सकता है'
            ),
            'bn' => array(
                'hello' => 'হ্যালো',
                'welcome' => 'স্বাগতম',
                'home' => 'হোম',
                'about' => 'আমাদের সম্পর্কে',
                'contact' => 'যোগাযোগ',
                'read more' => 'আরও পড়ুন',
                'search' => 'অনুসন্ধান',
                'menu' => 'মেনু',
                'blog' => 'ব্লগ',
                'news' => 'সংবাদ',
                'language' => 'ভাষা',
                'select language' => 'ভাষা নির্বাচন করুন',
                'english' => 'ইংরেজি',
                'hindi' => 'হিন্দি',
                'bengali' => 'বাংলা',
                'telugu' => 'তেলুগু',
                'tamil' => 'তামিল',
                'gujarati' => 'গুজরাটি',
                'kannada' => 'কন্নড়',
                'malayalam' => 'মালয়ালম',
                'punjabi' => 'পাঞ্জাবি',
                'marathi' => 'মারাঠি',
                'odia' => 'ওড়িয়া',
                'assamese' => 'অসমীয়া',
                'urdu' => 'উর্দু',
                'sanskrit' => 'সংস্কৃত',
                'nepali' => 'নেপালি',
                'sindhi' => 'সিন্ধি',
                'kashmiri' => 'কাশ্মীরি',
                'maldivian' => 'মালদিভিয়ান',
                'website' => 'ওয়েবসাইট',
                'page' => 'পৃষ্ঠা',
                'post' => 'পোস্ট',
                'article' => 'নিবন্ধ',
                'title' => 'শিরোনাম',
                'content' => 'বিষয়বস্তু',
                'text' => 'টেক্সট',
                'word' => 'শব্দ',
                'click' => 'ক্লিক করুন',
                'here' => 'এখানে',
                'this' => 'এই',
                'that' => 'সেই',
                'is' => 'হয়',
                'are' => 'হয়',
                'was' => 'ছিল',
                'were' => 'ছিল',
                'will' => 'হবে',
                'can' => 'পারে',
                'should' => 'উচিত',
                'would' => 'হবে',
                'could' => 'পারত',
                'may' => 'পারে',
                'might' => 'পারে'
            ),
            'te' => array(
                'hello' => 'హలో',
                'welcome' => 'స్వాగతం',
                'home' => 'హోమ్',
                'about' => 'మా గురించి',
                'contact' => 'సంప్రదించండి',
                'read more' => 'మరింత చదవండి',
                'search' => 'వెతకండి',
                'menu' => 'మెనూ',
                'blog' => 'బ్లాగ్',
                'news' => 'వార్తలు',
                'language' => 'భాష',
                'select language' => 'భాషను ఎంచుకోండి',
                'english' => 'ఆంగ్లం',
                'hindi' => 'హిందీ',
                'bengali' => 'బెంగాలీ',
                'telugu' => 'తెలుగు',
                'tamil' => 'తమిళం',
                'gujarati' => 'గుజరాతీ',
                'kannada' => 'కన్నడ',
                'malayalam' => 'మలయాళం',
                'punjabi' => 'పంజాబీ',
                'marathi' => 'మరాఠీ',
                'odia' => 'ఒడియా',
                'assamese' => 'అస్సామీ',
                'urdu' => 'ఉర్దూ',
                'sanskrit' => 'సంస్కృతం',
                'nepali' => 'నేపాలీ',
                'sindhi' => 'సింధీ',
                'kashmiri' => 'కాశ్మీరీ',
                'maldivian' => 'మాల్దీవియన్'
            ),
            'ta' => array(
                'hello' => 'வணக்கம்',
                'welcome' => 'வரவேற்கிறோம்',
                'home' => 'முகப்பு',
                'about' => 'எங்களைப் பற்றி',
                'contact' => 'தொடர்பு',
                'read more' => 'மேலும் படிக்க',
                'search' => 'தேடு',
                'menu' => 'மெனு',
                'blog' => 'வலைப்பதிவு',
                'news' => 'செய்திகள்',
                'language' => 'மொழி',
                'select language' => 'மொழியைத் தேர்ந்தெடுக்கவும்',
                'english' => 'ஆங்கிலம்',
                'hindi' => 'ஹிந்தி',
                'bengali' => 'வங்காளம்',
                'telugu' => 'தெலுங்கு',
                'tamil' => 'தமிழ்',
                'gujarati' => 'குஜராத்தி',
                'kannada' => 'கன்னடம்',
                'malayalam' => 'மலையாளம்',
                'punjabi' => 'பஞ்சாபி',
                'marathi' => 'மராத்தி',
                'odia' => 'ஒரியா',
                'assamese' => 'அசாமி',
                'urdu' => 'உருது',
                'sanskrit' => 'சமஸ்கிருதம்',
                'nepali' => 'நேபாளி',
                'sindhi' => 'சிந்தி',
                'kashmiri' => 'காஷ்மீரி',
                'maldivian' => 'மால்தீவியன்'
            ),
            'gu' => array(
                'hello' => 'નમસ્તે',
                'welcome' => 'સ્વાગત છે',
                'home' => 'હોમ',
                'about' => 'અમારા વિશે',
                'contact' => 'સંપર્ક',
                'read more' => 'વધુ વાંચો',
                'search' => 'શોધો',
                'menu' => 'મેનુ',
                'blog' => 'બ્લોગ',
                'news' => 'સમાચાર',
                'language' => 'ભાષા',
                'select language' => 'ભાષા પસંદ કરો',
                'english' => 'અંગ્રેજી',
                'hindi' => 'હિન્દી',
                'bengali' => 'બંગાળી',
                'telugu' => 'તેલુગુ',
                'tamil' => 'તમિલ',
                'gujarati' => 'ગુજરાતી',
                'kannada' => 'કન્નડ',
                'malayalam' => 'મલયાળમ',
                'punjabi' => 'પંજાબી',
                'marathi' => 'મરાઠી',
                'odia' => 'ઓડિયા',
                'assamese' => 'અસમિયા',
                'urdu' => 'ઉર્દૂ',
                'sanskrit' => 'સંસ્કૃત',
                'nepali' => 'નેપાળી',
                'sindhi' => 'સિંધી',
                'kashmiri' => 'કાશ્મીરી',
                'maldivian' => 'માલદીવિયન'
            )
            // Add more languages as needed
        );
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Indian Language Switcher Settings',
            'Language Switcher',
            'manage_options',
            'indian-language-switcher',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting('ils_options', 'ils_settings');
        
        add_settings_section(
            'ils_main_section',
            'Language Switcher Settings',
            array($this, 'section_callback'),
            'indian-language-switcher'
        );
        
        add_settings_field(
            'ils_default_language',
            'Default Language',
            array($this, 'default_language_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );

        add_settings_field(
            'ils_enable_api',
            'Enable Google Translate API',
            array($this, 'enable_api_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );

        add_settings_field(
            'ils_api_key',
            'Google API Key',
            array($this, 'api_key_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );

        add_settings_field(
            'ils_cache_ttl',
            'API Cache TTL (hours)',
            array($this, 'cache_ttl_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );

        add_settings_field(
            'ils_display_style',
            'Display Style',
            array($this, 'display_style_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );

        add_settings_field(
            'ils_use_google_widget',
            'Use Google Website Translator (UI)',
            array($this, 'use_google_widget_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Indian Language Switcher Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('ils_options');
                do_settings_sections('indian-language-switcher');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    
    public function section_callback() {
        echo '<p>Configure the language switcher settings below:</p>';
    }
    
    public function default_language_callback() {
        $options = get_option('ils_settings');
        $default_language = isset($options['default_language']) ? $options['default_language'] : 'en';
        
        echo '<select name="ils_settings[default_language]">';
        foreach ($this->supported_languages as $code => $language) {
            $selected = ($code === $default_language) ? 'selected' : '';
            echo '<option value="' . $code . '" ' . $selected . '>' . $language['name'] . '</option>';
        }
        echo '</select>';
    }

    public function enable_api_callback() {
        $options = get_option('ils_settings');
        $enabled = !empty($options['enable_api']);
        echo '<label><input type="checkbox" name="ils_settings[enable_api]" value="1" ' . checked(true, $enabled, false) . '> Use Google Translate API when available</label>';
    }

    public function api_key_callback() {
        $options = get_option('ils_settings');
        $api_key = isset($options['api_key']) ? esc_attr($options['api_key']) : '';
        echo '<input type="text" class="regular-text" name="ils_settings[api_key]" value="' . $api_key . '" placeholder="AIza..." />';
        echo '<p class="description">Create an API key in Google Cloud Console and enable the Cloud Translation API.</p>';
    }

    public function cache_ttl_callback() {
        $options = get_option('ils_settings');
        $ttl = isset($options['cache_ttl']) ? intval($options['cache_ttl']) : 12;
        echo '<input type="number" min="0" step="1" name="ils_settings[cache_ttl]" value="' . $ttl . '" />';
        echo '<p class="description">Cache translated content for this many hours. Set 0 to disable caching.</p>';
    }

    public function display_style_callback() {
        $options = get_option('ils_settings');
        $style = isset($options['display_style']) ? $options['display_style'] : 'floating';
        echo '<select name="ils_settings[display_style]">';
        echo '<option value="floating" ' . selected($style, 'floating', false) . '>Floating (default)</option>';
        echo '<option value="topbar" ' . selected($style, 'topbar', false) . '>Top Bar (header style)</option>';
        echo '</select>';
        echo '<p class="description">Top Bar renders a compact selector similar to government portals.</p>';
    }

    public function use_google_widget_callback() {
        $options = get_option('ils_settings');
        $use = !empty($options['use_google_widget']);
        echo '<label><input type="checkbox" name="ils_settings[use_google_widget]" value="1" ' . checked(true, $use, false) . '> Render Google Website Translator UI (optional)</label>';
        echo '<p class="description">This loads the Google Website Translator dropdown for client-side page translation. It is separate from API-based content translation.</p>';
    }
    
    public function activate() {
        // Set default options
        $default_options = array(
            'default_language' => 'en',
            'enable_api' => false,
            'api_key' => '',
            'cache_ttl' => 12,
            'display_style' => 'floating',
            'use_google_widget' => false
        );
        if (!get_option('ils_settings')) {
            add_option('ils_settings', $default_options);
        }
    }
    
    public function deactivate() {
        // Clean up if needed
    }
    
    public function register_widget() {
        register_widget('ILS_Language_Switcher_Widget');
    }
    
    // Debug method to test translation
    public function test_translation($text = 'Hello welcome home') {
        $original_language = $this->current_language;
        $results = array();
        
        foreach (array_keys($this->supported_languages) as $lang) {
            $this->current_language = $lang;
            $results[$lang] = $this->translate_text($text, $lang);
        }
        
        $this->current_language = $original_language;
        return $results;
    }
}

// Initialize the plugin
new IndianLanguageSwitcher(); 