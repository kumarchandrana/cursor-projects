<?php
/**
 * Indian Language Switcher Shortcode
 */

if (!defined('ABSPATH')) {
    exit;
}

class ILS_Shortcode {
    
    public function __construct() {
        add_shortcode('indian_language_switcher', array($this, 'language_switcher_shortcode'));
        add_shortcode('ils_switcher', array($this, 'language_switcher_shortcode'));
    }
    
    public function language_switcher_shortcode($atts) {
        $atts = shortcode_atts(array(
            'style' => 'dropdown',
            'show_flags' => 'true',
            'show_native_names' => 'true',
            'position' => 'inline',
            'class' => ''
        ), $atts);
        
        $show_flags = filter_var($atts['show_flags'], FILTER_VALIDATE_BOOLEAN);
        $show_native_names = filter_var($atts['show_native_names'], FILTER_VALIDATE_BOOLEAN);
        
        ob_start();
        
        switch ($atts['style']) {
            case 'list':
                $this->display_list_shortcode($show_flags, $show_native_names, $atts['class']);
                break;
            case 'buttons':
                $this->display_buttons_shortcode($show_flags, $show_native_names, $atts['class']);
                break;
            case 'flags':
                $this->display_flags_shortcode($show_native_names, $atts['class']);
                break;
            default:
                $this->display_dropdown_shortcode($show_flags, $show_native_names, $atts['class']);
                break;
        }
        
        return ob_get_clean();
    }
    
    private function display_dropdown_shortcode($show_flags, $show_native_names, $class) {
        $current_language = isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'en';
        $languages = $this->get_supported_languages();
        
        echo '<div class="ils-shortcode-dropdown ' . esc_attr($class) . '">';
        echo '<div class="ils-shortcode-current" onclick="toggleShortcodeDropdown()">';
        if ($show_flags) {
            echo '<span class="ils-shortcode-flag">' . $languages[$current_language]['flag'] . '</span>';
        }
        if ($show_native_names) {
            echo '<span class="ils-shortcode-name">' . $languages[$current_language]['native_name'] . '</span>';
        } else {
            echo '<span class="ils-shortcode-name">' . $languages[$current_language]['name'] . '</span>';
        }
        echo '<span class="ils-shortcode-arrow">▼</span>';
        echo '</div>';
        echo '<div class="ils-shortcode-options" id="ils-shortcode-options">';
        
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_language) ? 'active' : '';
            echo '<div class="ils-shortcode-option ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-shortcode-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-shortcode-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-shortcode-name">' . $language['name'] . '</span>';
            }
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
    }
    
    private function display_list_shortcode($show_flags, $show_native_names, $class) {
        $current_language = isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'en';
        $languages = $this->get_supported_languages();
        
        echo '<div class="ils-shortcode-list ' . esc_attr($class) . '">';
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_language) ? 'active' : '';
            echo '<div class="ils-shortcode-list-item ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-shortcode-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-shortcode-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-shortcode-name">' . $language['name'] . '</span>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    
    private function display_buttons_shortcode($show_flags, $show_native_names, $class) {
        $current_language = isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'en';
        $languages = $this->get_supported_languages();
        
        echo '<div class="ils-shortcode-buttons ' . esc_attr($class) . '">';
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_language) ? 'active' : '';
            echo '<button class="ils-shortcode-button ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-shortcode-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-shortcode-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-shortcode-name">' . $language['name'] . '</span>';
            }
            echo '</button>';
        }
        echo '</div>';
    }
    
    private function display_flags_shortcode($show_native_names, $class) {
        $current_language = isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'en';
        $languages = $this->get_supported_languages();
        
        echo '<div class="ils-shortcode-flags ' . esc_attr($class) . '">';
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_language) ? 'active' : '';
            echo '<div class="ils-shortcode-flag-item ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')" title="' . $language['name'] . '">';
            echo '<span class="ils-shortcode-flag">' . $language['flag'] . '</span>';
            if ($show_native_names) {
                echo '<span class="ils-shortcode-name">' . $language['native_name'] . '</span>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    
    private function get_supported_languages() {
        return array(
            'en' => array('name' => 'English', 'native_name' => 'English', 'flag' => '🇮🇳'),
            'hi' => array('name' => 'Hindi', 'native_name' => 'हिन्दी', 'flag' => '🇮🇳'),
            'bn' => array('name' => 'Bengali', 'native_name' => 'বাংলা', 'flag' => '🇮🇳'),
            'te' => array('name' => 'Telugu', 'native_name' => 'తెలుగు', 'flag' => '🇮🇳'),
            'mr' => array('name' => 'Marathi', 'native_name' => 'मराठी', 'flag' => '🇮🇳'),
            'ta' => array('name' => 'Tamil', 'native_name' => 'தமிழ்', 'flag' => '🇮🇳'),
            'gu' => array('name' => 'Gujarati', 'native_name' => 'ગુજરાતી', 'flag' => '🇮🇳'),
            'kn' => array('name' => 'Kannada', 'native_name' => 'ಕನ್ನಡ', 'flag' => '🇮🇳'),
            'ml' => array('name' => 'Malayalam', 'native_name' => 'മലയാളം', 'flag' => '🇮🇳'),
            'pa' => array('name' => 'Punjabi', 'native_name' => 'ਪੰਜਾਬੀ', 'flag' => '🇮🇳'),
            'or' => array('name' => 'Odia', 'native_name' => 'ଓଡ଼ିଆ', 'flag' => '🇮🇳'),
            'as' => array('name' => 'Assamese', 'native_name' => 'অসমীয়া', 'flag' => '🇮🇳'),
            'ur' => array('name' => 'Urdu', 'native_name' => 'اردو', 'flag' => '🇮🇳'),
            'sa' => array('name' => 'Sanskrit', 'native_name' => 'संस्कृतम्', 'flag' => '🇮🇳'),
            'ne' => array('name' => 'Nepali', 'native_name' => 'नेपाली', 'flag' => '🇮🇳'),
            'sd' => array('name' => 'Sindhi', 'native_name' => 'सिन्धी', 'flag' => '🇮🇳'),
            'ks' => array('name' => 'Kashmiri', 'native_name' => 'कॉशुर', 'flag' => '🇮🇳'),
            'dv' => array('name' => 'Maldivian', 'native_name' => 'ދިވެހި', 'flag' => '🇮🇳')
        );
    }
}

// Initialize shortcode
new ILS_Shortcode(); 