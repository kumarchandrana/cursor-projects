<?php
/**
 * Standalone Plugin Test Script
 * This script tests the Indian Language Switcher plugin functionality
 */

echo "<h1>Indian Language Switcher - Plugin Test</h1>";

// Check 1: Plugin file exists
echo "<h2>1. Plugin File Check</h2>";
$plugin_file = 'indian-language-switcher.php';
if (file_exists($plugin_file)) {
    echo "<p style='color: green;'>✓ Plugin file exists: $plugin_file</p>";
} else {
    echo "<p style='color: red;'>✗ Plugin file missing: $plugin_file</p>";
}

// Check 2: Required files exist
echo "<h2>2. Required Files Check</h2>";
$required_files = array(
    'assets/js/ils-script.js',
    'assets/css/ils-style.css',
    'includes/class-ils-widget.php',
    'includes/class-ils-shortcode.php'
);

foreach ($required_files as $file) {
    if (file_exists($file)) {
        echo "<p style='color: green;'>✓ $file</p>";
    } else {
        echo "<p style='color: red;'>✗ $file</p>";
    }
}

// Check 3: Plugin structure
echo "<h2>3. Plugin Structure Check</h2>";
$plugin_content = file_get_contents($plugin_file);
if ($plugin_content) {
    if (strpos($plugin_content, 'Plugin Name: Indian Language Switcher') !== false) {
        echo "<p style='color: green;'>✓ Plugin header found</p>";
    } else {
        echo "<p style='color: red;'>✗ Plugin header missing</p>";
    }
    
    if (strpos($plugin_content, 'class IndianLanguageSwitcher') !== false) {
        echo "<p style='color: green;'>✓ Main plugin class found</p>";
    } else {
        echo "<p style='color: red;'>✗ Main plugin class missing</p>";
    }
    
    if (strpos($plugin_content, 'add_action') !== false) {
        echo "<p style='color: green;'>✓ WordPress hooks found</p>";
    } else {
        echo "<p style='color: red;'>✗ WordPress hooks missing</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Cannot read plugin file</p>";
}

// Check 4: JavaScript functionality
echo "<h2>4. JavaScript Check</h2>";
$js_content = file_get_contents('assets/js/ils-script.js');
if ($js_content) {
    if (strpos($js_content, 'switchLanguage') !== false) {
        echo "<p style='color: green;'>✓ Language switching function found</p>";
    } else {
        echo "<p style='color: red;'>✗ Language switching function missing</p>";
    }
    
    if (strpos($js_content, 'toggleLanguageDropdown') !== false) {
        echo "<p style='color: green;'>✓ Dropdown toggle function found</p>";
    } else {
        echo "<p style='color: red;'>✗ Dropdown toggle function missing</p>";
    }
    
    if (strpos($js_content, 'jQuery') !== false) {
        echo "<p style='color: green;'>✓ jQuery dependency found</p>";
    } else {
        echo "<p style='color: red;'>✗ jQuery dependency missing</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Cannot read JavaScript file</p>";
}

// Check 5: CSS styling
echo "<h2>5. CSS Check</h2>";
$css_content = file_get_contents('assets/css/ils-style.css');
if ($css_content) {
    if (strpos($css_content, '.ils-language-switcher') !== false) {
        echo "<p style='color: green;'>✓ Main switcher styles found</p>";
    } else {
        echo "<p style='color: red;'>✗ Main switcher styles missing</p>";
    }
    
    if (strpos($css_content, '.ils-language-dropdown') !== false) {
        echo "<p style='color: green;'>✓ Dropdown styles found</p>";
    } else {
        echo "<p style='color: red;'>✗ Dropdown styles missing</p>";
    }
    
    if (strpos($css_content, '@media') !== false) {
        echo "<p style='color: green;'>✓ Responsive styles found</p>";
    } else {
        echo "<p style='color: red;'>✗ Responsive styles missing</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Cannot read CSS file</p>";
}

// Check 6: Widget functionality
echo "<h2>6. Widget Check</h2>";
$widget_content = file_get_contents('includes/class-ils-widget.php');
if ($widget_content) {
    if (strpos($widget_content, 'class ILS_Language_Switcher_Widget') !== false) {
        echo "<p style='color: green;'>✓ Widget class found</p>";
    } else {
        echo "<p style='color: red;'>✗ Widget class missing</p>";
    }
    
    if (strpos($widget_content, 'extends WP_Widget') !== false) {
        echo "<p style='color: green;'>✓ Widget extends WP_Widget</p>";
    } else {
        echo "<p style='color: red;'>✗ Widget doesn't extend WP_Widget</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Cannot read widget file</p>";
}

// Check 7: Shortcode functionality
echo "<h2>7. Shortcode Check</h2>";
$shortcode_content = file_get_contents('includes/class-ils-shortcode.php');
if ($shortcode_content) {
    if (strpos($shortcode_content, 'class ILS_Shortcode') !== false) {
        echo "<p style='color: green;'>✓ Shortcode class found</p>";
    } else {
        echo "<p style='color: red;'>✗ Shortcode class missing</p>";
    }
    
    if (strpos($shortcode_content, 'add_shortcode') !== false) {
        echo "<p style='color: green;'>✓ Shortcode registration found</p>";
    } else {
        echo "<p style='color: red;'>✗ Shortcode registration missing</p>";
    }
} else {
    echo "<p style='color: red;'>✗ Cannot read shortcode file</p>";
}

// Check 8: Translation functionality
echo "<h2>8. Translation Check</h2>";
if ($plugin_content) {
    if (strpos($plugin_content, 'translate_text') !== false) {
        echo "<p style='color: green;'>✓ Translation function found</p>";
    } else {
        echo "<p style='color: red;'>✗ Translation function missing</p>";
    }
    
    if (strpos($plugin_content, 'get_translation_mappings') !== false) {
        echo "<p style='color: green;'>✓ Translation mappings found</p>";
    } else {
        echo "<p style='color: red;'>✗ Translation mappings missing</p>";
    }
    
    if (strpos($plugin_content, 'add_filter') !== false) {
        echo "<p style='color: green;'>✓ Content filters found</p>";
    } else {
        echo "<p style='color: red;'>✗ Content filters missing</p>";
    }
}

// Check 9: AJAX functionality
echo "<h2>9. AJAX Check</h2>";
if ($plugin_content) {
    if (strpos($plugin_content, 'wp_ajax_ils_switch_language') !== false) {
        echo "<p style='color: green;'>✓ AJAX handler found</p>";
    } else {
        echo "<p style='color: red;'>✗ AJAX handler missing</p>";
    }
    
    if (strpos($plugin_content, 'wp_ajax_nopriv_ils_switch_language') !== false) {
        echo "<p style='color: green;'>✓ Non-privileged AJAX handler found</p>";
    } else {
        echo "<p style='color: red;'>✗ Non-privileged AJAX handler missing</p>";
    }
}

// Check 10: Session handling
echo "<h2>10. Session Check</h2>";
if ($plugin_content) {
    if (strpos($plugin_content, 'session_start') !== false) {
        echo "<p style='color: green;'>✓ Session handling found</p>";
    } else {
        echo "<p style='color: red;'>✗ Session handling missing</p>";
    }
    
    if (strpos($plugin_content, '$_SESSION') !== false) {
        echo "<p style='color: green;'>✓ Session variables used</p>";
    } else {
        echo "<p style='color: red;'>✗ Session variables not used</p>";
    }
}

// Summary
echo "<h2>Summary</h2>";
echo "<p>This test checks the plugin structure and code integrity. For full functionality testing, the plugin needs to be installed in a WordPress environment.</p>";

echo "<h2>Common Issues and Solutions</h2>";
echo "<ol>";
echo "<li><strong>Plugin not showing:</strong> Make sure the plugin is activated in WordPress Admin > Plugins</li>";
echo "<li><strong>Language switcher not visible:</strong> Check if the floating switcher appears, or add the shortcode [indian_language_switcher] to any post</li>";
echo "<li><strong>Translation not working:</strong> The plugin uses basic word replacement. For full translation, integrate with Google Translate API</li>";
echo "<li><strong>AJAX errors:</strong> Check browser console for JavaScript errors</li>";
echo "<li><strong>Styling issues:</strong> Make sure the CSS file is being loaded properly</li>";
echo "</ol>";

echo "<h2>Installation Steps</h2>";
echo "<ol>";
echo "<li>Upload the plugin folder to wp-content/plugins/</li>";
echo "<li>Activate the plugin in WordPress Admin > Plugins</li>";
echo "<li>Look for the floating language switcher on your site</li>";
echo "<li>Or add the shortcode [indian_language_switcher] to any post</li>";
echo "<li>Or add the widget to any widget area</li>";
echo "</ol>";

echo "<p><strong>Note:</strong> This plugin requires WordPress 4.0+ and PHP 5.6+</p>";
?> 