<?php
/**
 * Installation Helper for Indian Language Switcher Plugin
 * 
 * This script helps you install the plugin properly.
 * 
 * Instructions:
 * 1. Upload all plugin files to: wp-content/plugins/indian-language-switcher/
 * 2. Run this script once by visiting: yoursite.com/install-plugin.php
 * 3. Delete this file after installation
 */

// Check if WordPress is loaded
if (!defined('ABSPATH')) {
    // Try to load WordPress
    $wp_load_path = dirname(__FILE__) . '/wp-load.php';
    if (file_exists($wp_load_path)) {
        require_once($wp_load_path);
    } else {
        echo "WordPress not found. Please place this file in your WordPress root directory.";
        exit;
    }
}

// Check if plugin is already installed
$plugin_path = WP_PLUGIN_DIR . '/indian-language-switcher/indian-language-switcher.php';
if (file_exists($plugin_path)) {
    echo "<h2>✅ Plugin Already Installed!</h2>";
    echo "<p>The Indian Language Switcher plugin is already installed.</p>";
    echo "<p><strong>Next Steps:</strong></p>";
    echo "<ol>";
    echo "<li>Go to <a href='" . admin_url('plugins.php') . "'>WordPress Admin > Plugins</a></li>";
    echo "<li>Find 'Indian Language Switcher' in the list</li>";
    echo "<li>Click 'Activate'</li>";
    echo "<li>Go to <a href='" . admin_url('options-general.php?page=indian-language-switcher') . "'>Settings > Language Switcher</a> to configure</li>";
    echo "</ol>";
} else {
    echo "<h2>❌ Plugin Not Found</h2>";
    echo "<p>The Indian Language Switcher plugin is not installed.</p>";
    echo "<p><strong>Installation Steps:</strong></p>";
    echo "<ol>";
    echo "<li>Create folder: <code>wp-content/plugins/indian-language-switcher/</code></li>";
    echo "<li>Upload all plugin files to this folder</li>";
    echo "<li>Go to <a href='" . admin_url('plugins.php') . "'>WordPress Admin > Plugins</a></li>";
    echo "<li>Find 'Indian Language Switcher' and activate it</li>";
    echo "</ol>";
    
    echo "<h3>Required Files:</h3>";
    echo "<ul>";
    echo "<li>indian-language-switcher.php</li>";
    echo "<li>assets/js/ils-script.js</li>";
    echo "<li>assets/css/ils-style.css</li>";
    echo "<li>includes/class-ils-widget.php</li>";
    echo "<li>includes/class-ils-shortcode.php</li>";
    echo "<li>README.md</li>";
    echo "<li>INSTALLATION.md</li>";
    echo "</ul>";
}

echo "<hr>";
echo "<p><strong>After installation:</strong></p>";
echo "<ul>";
echo "<li>The widget will appear in <a href='" . admin_url('widgets.php') . "'>Appearance > Widgets</a></li>";
echo "<li>Use shortcode <code>[indian_language_switcher]</code> anywhere</li>";
echo "<li>Plugin will show as floating widget automatically</li>";
echo "</ul>";

echo "<p><em>Delete this file after successful installation.</em></p>";
?> 