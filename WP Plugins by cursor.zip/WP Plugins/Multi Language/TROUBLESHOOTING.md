# Indian Language Switcher - Troubleshooting Guide

## Common Issues and Solutions

### 1. Plugin Not Showing/Working

**Symptoms:**
- Language switcher doesn't appear on the site
- No floating language switcher visible
- Shortcode doesn't work

**Solutions:**
1. **Check Plugin Activation:**
   - Go to WordPress Admin > Plugins
   - Make sure "Indian Language Switcher" is activated
   - If not activated, click "Activate"

2. **Check Plugin Installation:**
   - Ensure the plugin is in `wp-content/plugins/indian-language-switcher/`
   - All files should be present in the plugin directory

3. **Check for JavaScript Errors:**
   - Open browser Developer Tools (F12)
   - Go to Console tab
   - Look for any red error messages
   - Common issues: jQuery not loaded, AJAX errors

4. **Check CSS Loading:**
   - In Developer Tools, go to Network tab
   - Refresh the page
   - Look for `ils-style.css` - if it's red, CSS isn't loading

### 2. Language Switcher Not Visible

**Solutions:**
1. **Look for Floating Switcher:**
   - The switcher should appear in the top-right corner
   - Check if it's hidden behind other elements
   - Try scrolling to see if it's positioned off-screen

2. **Add Shortcode:**
   - Add `[indian_language_switcher]` to any post or page
   - This will display the language switcher inline

3. **Add Widget:**
   - Go to Appearance > Widgets
   - Look for "Indian Language Switcher" widget
   - Add it to any widget area

### 3. Language Switching Not Working

**Symptoms:**
- Clicking language options doesn't change the language
- Page doesn't reload or update
- No translation occurs

**Solutions:**
1. **Check AJAX Functionality:**
   - Open browser Developer Tools
   - Go to Network tab
   - Click on a language option
   - Look for AJAX requests to `admin-ajax.php`
   - If no request appears, there's a JavaScript issue

2. **Check Session Support:**
   - The plugin uses PHP sessions
   - Make sure sessions are enabled in PHP
   - Check if your hosting supports sessions

3. **Check WordPress AJAX:**
   - Ensure `admin-ajax.php` is accessible
   - Check if WordPress AJAX is working on your site

### 4. Translation Not Working

**Symptoms:**
- Language switches but content doesn't translate
- Text remains in English

**Solutions:**
1. **Check Translation Mappings:**
   - The plugin uses basic word replacement
   - Only common words are translated
   - For full translation, integrate with Google Translate API

2. **Check Content Filters:**
   - The plugin adds filters to `the_content`, `the_title`, etc.
   - Make sure your theme supports these filters
   - Some themes may override these filters

3. **Test with Simple Text:**
   - Try switching to Hindi and look for words like "Hello" → "नमस्ते"
   - If basic words don't translate, there's a filter issue

### 5. JavaScript Errors

**Common Errors:**
1. **jQuery not loaded:**
   - Error: `jQuery is not defined`
   - Solution: Make sure your theme loads jQuery

2. **AJAX URL not defined:**
   - Error: `ils_ajax is not defined`
   - Solution: Check if the plugin is properly enqueuing scripts

3. **Function not found:**
   - Error: `switchLanguage is not defined`
   - Solution: Check if JavaScript file is loading

**Debugging Steps:**
1. Open browser Developer Tools (F12)
2. Go to Console tab
3. Look for red error messages
4. Check Network tab for failed file loads

### 6. CSS/Styling Issues

**Symptoms:**
- Language switcher looks broken
- Dropdown doesn't appear
- Styling is missing

**Solutions:**
1. **Check CSS Loading:**
   - In Developer Tools > Network tab
   - Look for `ils-style.css`
   - If it's red or missing, CSS isn't loading

2. **Check for CSS Conflicts:**
   - Your theme might have conflicting CSS
   - Try temporarily switching to a default theme
   - Check if the switcher appears correctly

3. **Check Responsive Design:**
   - On mobile, the switcher moves to bottom-right
   - Make sure it's not hidden behind mobile elements

### 7. WordPress Compatibility Issues

**Check Requirements:**
- WordPress 4.0 or higher
- PHP 5.6 or higher
- jQuery (usually included with WordPress)

**Solutions:**
1. **Update WordPress:**
   - Go to Dashboard > Updates
   - Update WordPress to latest version

2. **Check PHP Version:**
   - Contact your hosting provider
   - Ensure PHP 5.6+ is enabled

3. **Check Theme Compatibility:**
   - Try switching to Twenty Twenty-One theme
   - Test if the plugin works with default theme

### 8. Server/Hosting Issues

**Common Issues:**
1. **Sessions Disabled:**
   - Contact hosting provider
   - Enable PHP sessions

2. **File Permissions:**
   - Ensure plugin files are readable
   - Set permissions to 644 for files, 755 for directories

3. **Memory Limits:**
   - Increase PHP memory limit
   - Contact hosting provider if needed

### 9. Debugging Steps

**Step-by-Step Debugging:**
1. **Check Plugin Files:**
   ```bash
   # Verify all files exist
   ls wp-content/plugins/indian-language-switcher/
   ```

2. **Check WordPress Error Log:**
   - Look in `wp-content/debug.log`
   - Enable debugging in `wp-config.php`

3. **Test in Isolation:**
   - Deactivate other plugins
   - Switch to default theme
   - Test if plugin works

4. **Check Browser Console:**
   - Open Developer Tools (F12)
   - Look for JavaScript errors
   - Check Network tab for failed requests

### 10. Advanced Troubleshooting

**Enable WordPress Debugging:**
Add to `wp-config.php`:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

**Check Plugin Hooks:**
The plugin should add these hooks:
- `wp_enqueue_scripts` - for loading CSS/JS
- `wp_footer` - for displaying switcher
- `wp_ajax_ils_switch_language` - for AJAX handling

**Test Translation Function:**
Create a test file to check translation:
```php
<?php
// Test translation
$translator = new IndianLanguageSwitcher();
$text = "Hello welcome home";
$translated = $translator->translate_text($text, 'hi');
echo "Original: $text\n";
echo "Translated: $translated\n";
?>
```

### 11. Getting Help

If the above solutions don't work:

1. **Check Error Logs:**
   - WordPress debug log
   - Server error logs
   - Browser console errors

2. **Contact Support:**
   - Provide error messages
   - Include WordPress version
   - Include PHP version
   - Include theme name

3. **Test Environment:**
   - Try on a fresh WordPress installation
   - Test with default theme
   - Test with no other plugins

### 12. Plugin Features

**What the Plugin Does:**
- Displays a floating language switcher
- Supports 18 Indian languages
- Provides shortcode `[indian_language_switcher]`
- Provides widget for sidebar
- Basic word translation (not full translation)
- Session-based language persistence

**What the Plugin Doesn't Do:**
- Full sentence translation (requires Google Translate API)
- Automatic language detection
- SEO-friendly URLs
- Database storage of translations

### 13. Alternative Solutions

If the plugin still doesn't work:

1. **Use Shortcode Only:**
   - Add `[indian_language_switcher]` to posts
   - This bypasses the floating switcher

2. **Use Widget Only:**
   - Add the widget to sidebar
   - This provides a different display method

3. **Manual Implementation:**
   - Copy the plugin code
   - Integrate directly into your theme
   - Customize as needed

### 14. Performance Tips

**Optimization:**
1. **Minimize AJAX Calls:**
   - Language switching uses AJAX
   - Consider caching translations

2. **CSS Optimization:**
   - The CSS is already optimized
   - Consider minifying for production

3. **JavaScript Optimization:**
   - The JS is already optimized
   - Consider minifying for production

### 15. Security Considerations

**Security Features:**
- Nonce verification for AJAX requests
- Input sanitization
- Output escaping
- WordPress coding standards compliance

**Best Practices:**
- Keep WordPress updated
- Use HTTPS
- Regular security scans
- Backup before testing

---

**Note:** This plugin is designed for basic language switching with word replacement. For full translation capabilities, consider integrating with Google Translate API or similar services. 