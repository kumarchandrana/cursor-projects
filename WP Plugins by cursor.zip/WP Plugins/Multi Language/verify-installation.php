<?php
/**
 * Installation Verification Script
 * Upload this to your WordPress root directory and access it via browser
 * to verify the plugin installation
 */

// Load WordPress
require_once('wp-config.php');
require_once('wp-load.php');

echo "<h1>Indian Language Switcher - Installation Verification</h1>";

// Check 1: Plugin file exists
$plugin_file = 'wp-content/plugins/indian-language-switcher/indian-language-switcher.php';
echo "<h2>1. Plugin File Check</h2>";
if (file_exists($plugin_file)) {
    echo "<p style='color: green;'>✓ Plugin file exists: $plugin_file</p>";
} else {
    echo "<p style='color: red;'>✗ Plugin file missing: $plugin_file</p>";
    echo "<p>Please ensure the plugin is uploaded to the correct location.</p>";
}

// Check 2: Plugin is active
echo "<h2>2. Plugin Activation Check</h2>";
if (class_exists('IndianLanguageSwitcher')) {
    echo "<p style='color: green;'>✓ Plugin class exists - plugin is loaded</p>";
} else {
    echo "<p style='color: red;'>✗ Plugin class not found - plugin may not be activated</p>";
    echo "<p>Please go to WordPress Admin > Plugins and activate the Indian Language Switcher plugin.</p>";
}

// Check 3: Required files exist
echo "<h2>3. Required Files Check</h2>";
$required_files = array(
    'wp-content/plugins/indian-language-switcher/assets/js/ils-script.js',
    'wp-content/plugins/indian-language-switcher/assets/css/ils-style.css',
    'wp-content/plugins/indian-language-switcher/includes/class-ils-widget.php',
    'wp-content/plugins/indian-language-switcher/includes/class-ils-shortcode.php'
);

foreach ($required_files as $file) {
    if (file_exists($file)) {
        echo "<p style='color: green;'>✓ $file</p>";
    } else {
        echo "<p style='color: red;'>✗ $file</p>";
    }
}

// Check 4: Widget registration
echo "<h2>4. Widget Registration Check</h2>";
if (class_exists('IndianLanguageSwitcher')) {
    $ils = new IndianLanguageSwitcher();
    if (method_exists($ils, 'register_widget')) {
        echo "<p style='color: green;'>✓ Widget registration method exists</p>";
    } else {
        echo "<p style='color: red;'>✗ Widget registration method missing</p>";
    }
} else {
    echo "<p style='color: orange;'>⚠ Cannot check widget registration - plugin not loaded</p>";
}

// Check 5: WordPress version
echo "<h2>5. WordPress Version Check</h2>";
global $wp_version;
echo "<p>WordPress Version: $wp_version</p>";
if (version_compare($wp_version, '4.0', '>=')) {
    echo "<p style='color: green;'>✓ WordPress version is compatible</p>";
} else {
    echo "<p style='color: red;'>✗ WordPress version too old. Requires 4.0+</p>";
}

// Check 6: PHP version
echo "<h2>6. PHP Version Check</h2>";
$php_version = phpversion();
echo "<p>PHP Version: $php_version</p>";
if (version_compare($php_version, '5.6', '>=')) {
    echo "<p style='color: green;'>✓ PHP version is compatible</p>";
} else {
    echo "<p style='color: red;'>✗ PHP version too old. Requires 5.6+</p>";
}

// Check 7: Session support
echo "<h2>7. Session Support Check</h2>";
if (function_exists('session_start')) {
    echo "<p style='color: green;'>✓ PHP sessions are supported</p>";
} else {
    echo "<p style='color: red;'>✗ PHP sessions not available</p>";
}

// Check 8: AJAX support
echo "<h2>8. AJAX Support Check</h2>";
if (function_exists('wp_ajax_ils_switch_language')) {
    echo "<p style='color: green;'>✓ AJAX handler is registered</p>";
} else {
    echo "<p style='color: orange;'>⚠ AJAX handler not found (may be normal if plugin not fully loaded)</p>";
}

// Summary
echo "<h2>Summary</h2>";
echo "<p>If you see any red ✗ marks above, those issues need to be resolved for the plugin to work properly.</p>";
echo "<p>If all checks show green ✓ marks, the plugin should be working correctly.</p>";

echo "<h2>Next Steps</h2>";
echo "<ol>";
echo "<li>If all checks pass, go to your WordPress site and look for the floating language switcher</li>";
echo "<li>If you don't see the switcher, try adding the shortcode <code>[indian_language_switcher]</code> to any post</li>";
echo "<li>Check Appearance > Widgets to see if the language switcher widget is available</li>";
echo "<li>If issues persist, upload and run <code>test-translation.php</code> to test translation functionality</li>";
echo "</ol>";

echo "<p><a href='../'>← Back to WordPress Site</a></p>";
?> 