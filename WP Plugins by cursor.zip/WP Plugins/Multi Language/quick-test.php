<?php
echo "=== Indian Language Switcher Plugin Test ===\n\n";

// Check main plugin file
if (file_exists('indian-language-switcher.php')) {
    echo "✓ Main plugin file exists\n";
    
    $content = file_get_contents('indian-language-switcher.php');
    if (strpos($content, 'Plugin Name: Indian Language Switcher') !== false) {
        echo "✓ Plugin header found\n";
    } else {
        echo "✗ Plugin header missing\n";
    }
    
    if (strpos($content, 'class IndianLanguageSwitcher') !== false) {
        echo "✓ Main class found\n";
    } else {
        echo "✗ Main class missing\n";
    }
} else {
    echo "✗ Main plugin file missing\n";
}

// Check required files
$files = [
    'assets/js/ils-script.js',
    'assets/css/ils-style.css',
    'includes/class-ils-widget.php',
    'includes/class-ils-shortcode.php'
];

echo "\nChecking required files:\n";
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "✓ $file\n";
    } else {
        echo "✗ $file\n";
    }
}

// Check for common issues
echo "\nChecking for common issues:\n";

if (file_exists('indian-language-switcher.php')) {
    $content = file_get_contents('indian-language-switcher.php');
    
    // Check for session handling
    if (strpos($content, 'session_start') !== false) {
        echo "✓ Session handling found\n";
    } else {
        echo "✗ Session handling missing - this may cause issues\n";
    }
    
    // Check for AJAX handlers
    if (strpos($content, 'wp_ajax_ils_switch_language') !== false) {
        echo "✓ AJAX handler found\n";
    } else {
        echo "✗ AJAX handler missing\n";
    }
    
    // Check for translation functions
    if (strpos($content, 'translate_text') !== false) {
        echo "✓ Translation function found\n";
    } else {
        echo "✗ Translation function missing\n";
    }
    
    // Check for WordPress hooks
    if (strpos($content, 'add_action') !== false) {
        echo "✓ WordPress hooks found\n";
    } else {
        echo "✗ WordPress hooks missing\n";
    }
}

echo "\n=== Potential Issues ===\n";
echo "1. Plugin needs to be installed in WordPress wp-content/plugins/ directory\n";
echo "2. Plugin needs to be activated in WordPress Admin\n";
echo "3. WordPress version 4.0+ required\n";
echo "4. PHP version 5.6+ required\n";
echo "5. jQuery must be loaded on the site\n";
echo "6. Sessions must be enabled in PHP\n";

echo "\n=== How to Fix ===\n";
echo "1. Upload the entire plugin folder to wp-content/plugins/indian-language-switcher/\n";
echo "2. Go to WordPress Admin > Plugins and activate 'Indian Language Switcher'\n";
echo "3. Look for the floating language switcher on your site\n";
echo "4. Or add shortcode [indian_language_switcher] to any post\n";
echo "5. Or add the widget to any widget area\n";

echo "\n=== Testing in WordPress ===\n";
echo "To test if the plugin works in WordPress:\n";
echo "1. Install WordPress locally or on a server\n";
echo "2. Upload this plugin to wp-content/plugins/\n";
echo "3. Activate the plugin\n";
echo "4. Check if the language switcher appears\n";
echo "5. Try switching languages\n";
echo "6. Check browser console for JavaScript errors\n";
?> 