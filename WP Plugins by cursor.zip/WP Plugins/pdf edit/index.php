<?php
session_start();
require_once 'vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Initialize PDF editor
$pdfEditor = new PDFEdit\PDFEditor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced PDF Editor</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/6.0.0-beta.2/dropzone.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="app-container">
        <!-- Header -->
        <header class="header">
            <div class="header-content">
                <div class="logo">
                    <i class="fas fa-file-pdf"></i>
                    <h1>Advanced PDF Editor</h1>
                </div>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="openFileDialog()">
                        <i class="fas fa-upload"></i> Upload PDF
                    </button>
                    <button class="btn btn-secondary" onclick="showHelp()">
                        <i class="fas fa-question-circle"></i> Help
                    </button>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Sidebar -->
            <aside class="sidebar">
                <nav class="sidebar-nav">
                    <div class="nav-section">
                        <h3><i class="fas fa-edit"></i> Basic Editing</h3>
                        <ul>
                            <li><a href="#" onclick="showTool('text-edit')"><i class="fas fa-font"></i> Text Editor</a></li>
                            <li><a href="#" onclick="showTool('image-edit')"><i class="fas fa-image"></i> Image Editor</a></li>
                            <li><a href="#" onclick="showTool('shape-edit')"><i class="fas fa-shapes"></i> Shapes & Lines</a></li>
                            <li><a href="#" onclick="showTool('page-manage')"><i class="fas fa-file-alt"></i> Page Management</a></li>
                        </ul>
                    </div>

                    <div class="nav-section">
                        <h3><i class="fas fa-highlighter"></i> Annotations</h3>
                        <ul>
                            <li><a href="#" onclick="showTool('highlight')"><i class="fas fa-highlighter"></i> Highlight Text</a></li>
                            <li><a href="#" onclick="showTool('sticky-notes')"><i class="fas fa-sticky-note"></i> Sticky Notes</a></li>
                            <li><a href="#" onclick="showTool('drawing')"><i class="fas fa-pen"></i> Drawing Tools</a></li>
                            <li><a href="#" onclick="showTool('stamps')"><i class="fas fa-stamp"></i> Stamps & Watermarks</a></li>
                        </ul>
                    </div>

                    <div class="nav-section">
                        <h3><i class="fas fa-cogs"></i> Advanced Tools</h3>
                        <ul>
                            <li><a href="#" onclick="showTool('forms')"><i class="fas fa-wpforms"></i> Forms & Fields</a></li>
                            <li><a href="#" onclick="showTool('security')"><i class="fas fa-shield-alt"></i> Security</a></li>
                            <li><a href="#" onclick="showTool('ocr')"><i class="fas fa-eye"></i> OCR</a></li>
                            <li><a href="#" onclick="showTool('batch')"><i class="fas fa-layer-group"></i> Batch Processing</a></li>
                        </ul>
                    </div>
                </nav>
            </aside>

            <!-- Main Workspace -->
            <div class="workspace">
                <!-- File Upload Area -->
                <div id="upload-area" class="upload-area">
                    <div class="upload-content">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <h2>Upload Your PDF</h2>
                        <p>Drag and drop your PDF file here or click to browse</p>
                        <form action="upload.php" class="dropzone" id="pdf-dropzone">
                            <div class="dz-message">
                                <i class="fas fa-file-pdf"></i>
                                <h3>Drop PDF files here</h3>
                                <p>or click to select files</p>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- PDF Viewer -->
                <div id="pdf-viewer" class="pdf-viewer" style="display: none;">
                    <div class="viewer-header">
                        <div class="viewer-controls">
                            <button class="btn btn-sm" onclick="previousPage()"><i class="fas fa-chevron-left"></i></button>
                            <span id="page-info">Page 1 of 1</span>
                            <button class="btn btn-sm" onclick="nextPage()"><i class="fas fa-chevron-right"></i></button>
                            <input type="range" id="zoom-slider" min="50" max="200" value="100" onchange="changeZoom(this.value)">
                            <span id="zoom-level">100%</span>
                        </div>
                        <div class="viewer-actions">
                            <button class="btn btn-primary" onclick="saveChanges()">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                            <button class="btn btn-secondary" onclick="downloadPDF()">
                                <i class="fas fa-download"></i> Download
                            </button>
                        </div>
                    </div>
                    <div class="viewer-content">
                        <canvas id="pdf-canvas"></canvas>
                    </div>
                </div>

                <!-- Tool Panels -->
                <div id="tool-panels" class="tool-panels">
                    <!-- Text Editor Panel -->
                    <div id="text-edit-panel" class="tool-panel" style="display: none;">
                        <h3><i class="fas fa-font"></i> Text Editor</h3>
                        <div class="tool-content">
                            <div class="form-group">
                                <label>Text Content:</label>
                                <textarea id="text-content" placeholder="Enter text to add or edit..."></textarea>
                            </div>
                            <div class="form-group">
                                <label>Font Family:</label>
                                <select id="font-family">
                                    <option value="Arial">Arial</option>
                                    <option value="Times New Roman">Times New Roman</option>
                                    <option value="Helvetica">Helvetica</option>
                                    <option value="Courier New">Courier New</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Font Size:</label>
                                <input type="number" id="font-size" value="12" min="8" max="72">
                            </div>
                            <div class="form-group">
                                <label>Color:</label>
                                <input type="color" id="text-color" value="#000000">
                            </div>
                            <div class="form-group">
                                <label>Position:</label>
                                <input type="number" id="text-x" placeholder="X" step="0.1">
                                <input type="number" id="text-y" placeholder="Y" step="0.1">
                            </div>
                            <button class="btn btn-primary" onclick="addText()">Add Text</button>
                        </div>
                    </div>

                    <!-- Image Editor Panel -->
                    <div id="image-edit-panel" class="tool-panel" style="display: none;">
                        <h3><i class="fas fa-image"></i> Image Editor</h3>
                        <div class="tool-content">
                            <div class="form-group">
                                <label>Upload Image:</label>
                                <input type="file" id="image-upload" accept="image/*">
                            </div>
                            <div class="form-group">
                                <label>Position:</label>
                                <input type="number" id="image-x" placeholder="X" step="0.1">
                                <input type="number" id="image-y" placeholder="Y" step="0.1">
                            </div>
                            <div class="form-group">
                                <label>Size:</label>
                                <input type="number" id="image-width" placeholder="Width" step="0.1">
                                <input type="number" id="image-height" placeholder="Height" step="0.1">
                            </div>
                            <button class="btn btn-primary" onclick="addImage()">Add Image</button>
                        </div>
                    </div>

                    <!-- Page Management Panel -->
                    <div id="page-manage-panel" class="tool-panel" style="display: none;">
                        <h3><i class="fas fa-file-alt"></i> Page Management</h3>
                        <div class="tool-content">
                            <div class="page-thumbnails" id="page-thumbnails">
                                <!-- Page thumbnails will be generated here -->
                            </div>
                            <div class="page-actions">
                                <button class="btn btn-secondary" onclick="rotatePage()">
                                    <i class="fas fa-redo"></i> Rotate
                                </button>
                                <button class="btn btn-secondary" onclick="deletePage()">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <button class="btn btn-secondary" onclick="duplicatePage()">
                                    <i class="fas fa-copy"></i> Duplicate
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Security Panel -->
                    <div id="security-panel" class="tool-panel" style="display: none;">
                        <h3><i class="fas fa-shield-alt"></i> Security Settings</h3>
                        <div class="tool-content">
                            <div class="form-group">
                                <label>Password Protection:</label>
                                <input type="password" id="pdf-password" placeholder="Enter password">
                            </div>
                            <div class="form-group">
                                <label>Permissions:</label>
                                <div class="checkbox-group">
                                    <label><input type="checkbox" id="allow-print"> Allow Printing</label>
                                    <label><input type="checkbox" id="allow-copy"> Allow Copying</label>
                                    <label><input type="checkbox" id="allow-edit"> Allow Editing</label>
                                </div>
                            </div>
                            <button class="btn btn-primary" onclick="applySecurity()">Apply Security</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modals -->
    <div id="help-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Help & Documentation</h2>
                <span class="close" onclick="closeModal('help-modal')">&times;</span>
            </div>
            <div class="modal-body">
                <h3>Getting Started</h3>
                <p>Upload a PDF file to begin editing. You can drag and drop files or click the upload button.</p>
                
                <h3>Available Features</h3>
                <ul>
                    <li><strong>Text Editing:</strong> Add, edit, or delete text with custom fonts and colors</li>
                    <li><strong>Image Management:</strong> Add, edit, or remove images from your PDF</li>
                    <li><strong>Annotations:</strong> Highlight text, add sticky notes, and draw on pages</li>
                    <li><strong>Page Management:</strong> Reorder, rotate, or delete pages</li>
                    <li><strong>Security:</strong> Add password protection and set permissions</li>
                    <li><strong>Forms:</strong> Fill and create interactive forms</li>
                    <li><strong>OCR:</strong> Convert scanned documents to editable text</li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/6.0.0-beta.2/dropzone.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
