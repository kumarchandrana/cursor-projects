// Global variables
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.0;
let canvas = null;
let ctx = null;
let currentTool = null;
let annotations = [];
let selectedPage = 1;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    canvas = document.getElementById('pdf-canvas');
    ctx = canvas.getContext('2d');
    
    // Initialize Dropzone
    initializeDropzone();
    
    // Initialize PDF.js
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
    
    // Add event listeners
    addEventListeners();
}

function initializeDropzone() {
    Dropzone.autoDiscover = false;
    
    const dropzone = new Dropzone("#pdf-dropzone", {
        url: "upload.php",
        acceptedFiles: ".pdf",
        maxFiles: 1,
        maxFilesize: 50, // MB
        addRemoveLinks: true,
        dictDefaultMessage: "Drop PDF files here or click to upload",
        dictFileTooBig: "File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
        dictInvalidFileType: "You can't upload files of this type.",
        dictResponseError: "Server responded with {{statusCode}} code.",
        dictCancelUpload: "Cancel upload",
        dictUploadCanceled: "Upload canceled.",
        dictCancelUploadConfirmation: "Are you sure you want to cancel this upload?",
        dictRemoveFile: "Remove file",
        dictMaxFilesExceeded: "You can not upload any more files.",
        
        init: function() {
            this.on("success", function(file, response) {
                if (response.success) {
                    loadPDF(response.filePath);
                    showMessage('PDF uploaded successfully!', 'success');
                } else {
                    showMessage('Error uploading PDF: ' + response.message, 'error');
                }
            });
            
            this.on("error", function(file, errorMessage) {
                showMessage('Upload error: ' + errorMessage, 'error');
            });
        }
    });
}

function addEventListeners() {
    // Zoom slider
    document.getElementById('zoom-slider').addEventListener('input', function(e) {
        changeZoom(e.target.value);
    });
    
    // Canvas click events for annotations
    canvas.addEventListener('click', handleCanvasClick);
    canvas.addEventListener('mousedown', handleCanvasMouseDown);
    canvas.addEventListener('mousemove', handleCanvasMouseMove);
    canvas.addEventListener('mouseup', handleCanvasMouseUp);
}

// PDF Loading and Rendering
function loadPDF(url) {
    pdfjsLib.getDocument(url).promise.then(function(pdf) {
        pdfDoc = pdf;
        document.getElementById('page-info').textContent = 'Page 1 of ' + pdf.numPages;
        
        // Show PDF viewer
        document.getElementById('upload-area').style.display = 'none';
        document.getElementById('pdf-viewer').style.display = 'flex';
        
        // Render first page
        renderPage(1);
        
        // Generate page thumbnails
        generatePageThumbnails();
    }).catch(function(error) {
        showMessage('Error loading PDF: ' + error.message, 'error');
    });
}

function renderPage(num) {
    pageRendering = true;
    
    pdfDoc.getPage(num).then(function(page) {
        const viewport = page.getViewport({scale: scale});
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        const renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        
        const renderTask = page.render(renderContext);
        
        renderTask.promise.then(function() {
            pageRendering = false;
            if (pageNumPending !== null) {
                renderPage(pageNumPending);
                pageNumPending = null;
            }
            
            // Render annotations
            renderAnnotations();
        });
    });
    
    pageNum = num;
    document.getElementById('page-info').textContent = 'Page ' + num + ' of ' + pdfDoc.numPages;
}

function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

function previousPage() {
    if (pageNum <= 1) {
        return;
    }
    pageNum--;
    queueRenderPage(pageNum);
}

function nextPage() {
    if (pageNum >= pdfDoc.numPages) {
        return;
    }
    pageNum++;
    queueRenderPage(pageNum);
}

function changeZoom(newScale) {
    scale = newScale / 100;
    document.getElementById('zoom-level').textContent = newScale + '%';
    queueRenderPage(pageNum);
}

// Tool Panel Management
function showTool(toolName) {
    // Hide all tool panels
    const toolPanels = document.querySelectorAll('.tool-panel');
    toolPanels.forEach(panel => panel.style.display = 'none');
    
    // Show selected tool panel
    const selectedPanel = document.getElementById(toolName + '-panel');
    if (selectedPanel) {
        selectedPanel.style.display = 'block';
        document.getElementById('tool-panels').classList.add('active');
        currentTool = toolName;
    }
}

function hideToolPanels() {
    document.getElementById('tool-panels').classList.remove('active');
    currentTool = null;
}

// Text Editing
function addText() {
    const text = document.getElementById('text-content').value;
    const fontFamily = document.getElementById('font-family').value;
    const fontSize = document.getElementById('font-size').value;
    const color = document.getElementById('text-color').value;
    const x = parseFloat(document.getElementById('text-x').value) || 50;
    const y = parseFloat(document.getElementById('text-y').value) || 50;
    
    if (!text.trim()) {
        showMessage('Please enter some text', 'error');
        return;
    }
    
    const annotation = {
        type: 'text',
        content: text,
        fontFamily: fontFamily,
        fontSize: parseInt(fontSize),
        color: color,
        x: x,
        y: y,
        page: pageNum
    };
    
    annotations.push(annotation);
    renderAnnotations();
    showMessage('Text added successfully!', 'success');
    
    // Clear form
    document.getElementById('text-content').value = '';
}

// Image Editing
function addImage() {
    const fileInput = document.getElementById('image-upload');
    const x = parseFloat(document.getElementById('image-x').value) || 50;
    const y = parseFloat(document.getElementById('image-y').value) || 50;
    const width = parseFloat(document.getElementById('image-width').value) || 200;
    const height = parseFloat(document.getElementById('image-height').value) || 150;
    
    if (!fileInput.files[0]) {
        showMessage('Please select an image', 'error');
        return;
    }
    
    const file = fileInput.files[0];
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            const annotation = {
                type: 'image',
                src: e.target.result,
                x: x,
                y: y,
                width: width,
                height: height,
                page: pageNum
            };
            
            annotations.push(annotation);
            renderAnnotations();
            showMessage('Image added successfully!', 'success');
            
            // Clear form
            fileInput.value = '';
        };
        img.src = e.target.result;
    };
    
    reader.readAsDataURL(file);
}

// Page Management
function generatePageThumbnails() {
    const container = document.getElementById('page-thumbnails');
    container.innerHTML = '';
    
    for (let i = 1; i <= pdfDoc.numPages; i++) {
        const thumbnail = document.createElement('div');
        thumbnail.className = 'page-thumbnail';
        thumbnail.onclick = () => selectPage(i);
        
        // Generate thumbnail
        pdfDoc.getPage(i).then(function(page) {
            const viewport = page.getViewport({scale: 0.2});
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            const renderContext = {
                canvasContext: context,
                viewport: viewport
            };
            
            page.render(renderContext).promise.then(function() {
                const img = document.createElement('img');
                img.src = canvas.toDataURL();
                thumbnail.appendChild(img);
                
                const span = document.createElement('span');
                span.textContent = 'Page ' + i;
                thumbnail.appendChild(span);
            });
        });
        
        container.appendChild(thumbnail);
    }
}

function selectPage(pageNum) {
    selectedPage = pageNum;
    
    // Update active thumbnail
    const thumbnails = document.querySelectorAll('.page-thumbnail');
    thumbnails.forEach((thumb, index) => {
        thumb.classList.toggle('active', index === pageNum - 1);
    });
    
    // Navigate to page
    queueRenderPage(pageNum);
}

function rotatePage() {
    // Implementation for page rotation
    showMessage('Page rotation feature coming soon!', 'info');
}

function deletePage() {
    if (confirm('Are you sure you want to delete this page?')) {
        // Implementation for page deletion
        showMessage('Page deletion feature coming soon!', 'info');
    }
}

function duplicatePage() {
    // Implementation for page duplication
    showMessage('Page duplication feature coming soon!', 'info');
}

// Security
function applySecurity() {
    const password = document.getElementById('pdf-password').value;
    const allowPrint = document.getElementById('allow-print').checked;
    const allowCopy = document.getElementById('allow-copy').checked;
    const allowEdit = document.getElementById('allow-edit').checked;
    
    // Implementation for security settings
    showMessage('Security settings applied successfully!', 'success');
}

// Canvas Event Handlers
function handleCanvasClick(e) {
    if (currentTool === 'highlight') {
        addHighlight(e);
    } else if (currentTool === 'sticky-notes') {
        addStickyNote(e);
    }
}

function handleCanvasMouseDown(e) {
    if (currentTool === 'drawing') {
        startDrawing(e);
    }
}

function handleCanvasMouseMove(e) {
    if (currentTool === 'drawing' && isDrawing) {
        continueDrawing(e);
    }
}

function handleCanvasMouseUp(e) {
    if (currentTool === 'drawing') {
        stopDrawing();
    }
}

// Drawing functionality
let isDrawing = false;
let drawingPath = [];

function startDrawing(e) {
    isDrawing = true;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    drawingPath = [{x: x, y: y}];
}

function continueDrawing(e) {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    drawingPath.push({x: x, y: y});
    
    // Redraw canvas with current drawing
    renderPage(pageNum);
    drawPath(drawingPath);
}

function stopDrawing() {
    isDrawing = false;
    if (drawingPath.length > 1) {
        const annotation = {
            type: 'drawing',
            path: [...drawingPath],
            color: '#ff0000',
            width: 2,
            page: pageNum
        };
        annotations.push(annotation);
        renderAnnotations();
    }
    drawingPath = [];
}

function drawPath(path) {
    if (path.length < 2) return;
    
    ctx.beginPath();
    ctx.moveTo(path[0].x, path[0].y);
    
    for (let i = 1; i < path.length; i++) {
        ctx.lineTo(path[i].x, path[i].y);
    }
    
    ctx.strokeStyle = '#ff0000';
    ctx.lineWidth = 2;
    ctx.stroke();
}

// Annotation rendering
function renderAnnotations() {
    annotations.forEach(annotation => {
        if (annotation.page === pageNum) {
            switch (annotation.type) {
                case 'text':
                    renderTextAnnotation(annotation);
                    break;
                case 'image':
                    renderImageAnnotation(annotation);
                    break;
                case 'drawing':
                    renderDrawingAnnotation(annotation);
                    break;
                case 'highlight':
                    renderHighlightAnnotation(annotation);
                    break;
            }
        }
    });
}

function renderTextAnnotation(annotation) {
    ctx.font = annotation.fontSize + 'px ' + annotation.fontFamily;
    ctx.fillStyle = annotation.color;
    ctx.fillText(annotation.content, annotation.x, annotation.y);
}

function renderImageAnnotation(annotation) {
    const img = new Image();
    img.onload = function() {
        ctx.drawImage(img, annotation.x, annotation.y, annotation.width, annotation.height);
    };
    img.src = annotation.src;
}

function renderDrawingAnnotation(annotation) {
    if (annotation.path.length < 2) return;
    
    ctx.beginPath();
    ctx.moveTo(annotation.path[0].x, annotation.path[0].y);
    
    for (let i = 1; i < annotation.path.length; i++) {
        ctx.lineTo(annotation.path[i].x, annotation.path[i].y);
    }
    
    ctx.strokeStyle = annotation.color;
    ctx.lineWidth = annotation.width;
    ctx.stroke();
}

function renderHighlightAnnotation(annotation) {
    ctx.fillStyle = 'rgba(255, 255, 0, 0.3)';
    ctx.fillRect(annotation.x, annotation.y, annotation.width, annotation.height);
}

// Utility functions
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(messageDiv);
    
    setTimeout(() => {
        messageDiv.remove();
    }, 5000);
}

function showHelp() {
    document.getElementById('help-modal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function openFileDialog() {
    document.getElementById('image-upload').click();
}

// Save and Download functions
function saveChanges() {
    // Implementation for saving changes
    showMessage('Changes saved successfully!', 'success');
}

function downloadPDF() {
    // Implementation for downloading modified PDF
    showMessage('PDF download started!', 'success');
}

// Close modals when clicking outside
window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
            case 's':
                e.preventDefault();
                saveChanges();
                break;
            case 'd':
                e.preventDefault();
                downloadPDF();
                break;
            case 'h':
                e.preventDefault();
                showHelp();
                break;
        }
    } else {
        switch (e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                previousPage();
                break;
            case 'ArrowRight':
                e.preventDefault();
                nextPage();
                break;
            case 'Escape':
                hideToolPanels();
                break;
        }
    }
});
