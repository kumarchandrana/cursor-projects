<?php

namespace PDFEdit;

use setasign\Fpdi\Fpdi;
use setasign\FPDF\FPDF;
use Smalot\PdfParser\Parser;
use Intervention\Image\ImageManager;
use League\Flysystem\Filesystem;
use League\Flysystem\Local\LocalFilesystemAdapter;

class PDFEditor
{
    private $pdf;
    private $parser;
    private $imageManager;
    private $filesystem;
    private $currentFile;
    private $annotations = [];
    
    public function __construct()
    {
        $this->parser = new Parser();
        $this->imageManager = new ImageManager(['driver' => 'gd']);
        $this->filesystem = new Filesystem(new LocalFilesystemAdapter(__DIR__ . '/../'));
        
        // Create necessary directories
        $this->createDirectories();
    }
    
    /**
     * Create necessary directories
     */
    private function createDirectories()
    {
        $directories = ['uploads', 'temp', 'output', 'assets/images'];
        foreach ($directories as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }
    
    /**
     * Load a PDF file
     */
    public function loadPDF($filepath)
    {
        if (!file_exists($filepath)) {
            throw new \Exception('PDF file not found');
        }
        
        $this->currentFile = $filepath;
        $this->pdf = new Fpdi();
        
        try {
            $pageCount = $this->pdf->setSourceFile($filepath);
            return $pageCount;
        } catch (\Exception $e) {
            throw new \Exception('Error loading PDF: ' . $e->getMessage());
        }
    }
    
    /**
     * Add text to PDF
     */
    public function addText($text, $page, $x, $y, $fontSize = 12, $fontFamily = 'Arial', $color = '#000000')
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        $this->pdf->SetFont($fontFamily, '', $fontSize);
        $this->pdf->SetTextColor($this->hexToRgb($color));
        $this->pdf->Text($x, $y, $text);
        
        $this->annotations[] = [
            'type' => 'text',
            'content' => $text,
            'page' => $page,
            'x' => $x,
            'y' => $y,
            'fontSize' => $fontSize,
            'fontFamily' => $fontFamily,
            'color' => $color
        ];
    }
    
    /**
     * Add image to PDF
     */
    public function addImage($imagePath, $page, $x, $y, $width = null, $height = null)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        if (!file_exists($imagePath)) {
            throw new \Exception('Image file not found');
        }
        
        $this->pdf->AddPage();
        $this->pdf->Image($imagePath, $x, $y, $width, $height);
        
        $this->annotations[] = [
            'type' => 'image',
            'path' => $imagePath,
            'page' => $page,
            'x' => $x,
            'y' => $y,
            'width' => $width,
            'height' => $height
        ];
    }
    
    /**
     * Add drawing/annotation to PDF
     */
    public function addDrawing($path, $page, $color = '#ff0000', $width = 2)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        $this->pdf->SetDrawColor($this->hexToRgb($color));
        $this->pdf->SetLineWidth($width);
        
        // Draw the path
        if (count($path) > 1) {
            $this->pdf->MoveTo($path[0]['x'], $path[0]['y']);
            for ($i = 1; $i < count($path); $i++) {
                $this->pdf->LineTo($path[$i]['x'], $path[$i]['y']);
            }
        }
        
        $this->annotations[] = [
            'type' => 'drawing',
            'path' => $path,
            'page' => $page,
            'color' => $color,
            'width' => $width
        ];
    }
    
    /**
     * Add highlight to PDF
     */
    public function addHighlight($page, $x, $y, $width, $height, $color = '#ffff00')
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        $this->pdf->SetFillColor($this->hexToRgb($color));
        $this->pdf->Rect($x, $y, $width, $height, 'F');
        
        $this->annotations[] = [
            'type' => 'highlight',
            'page' => $page,
            'x' => $x,
            'y' => $y,
            'width' => $width,
            'height' => $height,
            'color' => $color
        ];
    }
    
    /**
     * Rotate page
     */
    public function rotatePage($page, $angle)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        $this->pdf->Rotate($angle);
        
        $this->annotations[] = [
            'type' => 'rotation',
            'page' => $page,
            'angle' => $angle
        ];
    }
    
    /**
     * Delete page
     */
    public function deletePage($page)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        // Implementation for page deletion
        $this->annotations[] = [
            'type' => 'delete_page',
            'page' => $page
        ];
    }
    
    /**
     * Duplicate page
     */
    public function duplicatePage($page)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->annotations[] = [
            'type' => 'duplicate_page',
            'page' => $page
        ];
    }
    
    /**
     * Add password protection
     */
    public function addPasswordProtection($password, $permissions = [])
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->SetProtection($permissions, $password);
    }
    
    /**
     * Set permissions
     */
    public function setPermissions($permissions)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->SetProtection($permissions);
    }
    
    /**
     * Extract text from PDF
     */
    public function extractText($filepath)
    {
        try {
            $pdf = $this->parser->parseFile($filepath);
            return $pdf->getText();
        } catch (\Exception $e) {
            throw new \Exception('Error extracting text: ' . $e->getMessage());
        }
    }
    
    /**
     * Convert PDF to images
     */
    public function pdfToImages($filepath, $outputDir = 'temp', $format = 'png')
    {
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }
        
        $images = [];
        $pdf = $this->parser->parseFile($filepath);
        
        foreach ($pdf->getPages() as $pageNum => $page) {
            $imagePath = $outputDir . '/page_' . ($pageNum + 1) . '.' . $format;
            // Implementation for PDF to image conversion
            $images[] = $imagePath;
        }
        
        return $images;
    }
    
    /**
     * Merge multiple PDFs
     */
    public function mergePDFs($pdfFiles, $outputPath)
    {
        $merger = new Fpdi();
        
        foreach ($pdfFiles as $file) {
            if (file_exists($file)) {
                $pageCount = $merger->setSourceFile($file);
                for ($i = 1; $i <= $pageCount; $i++) {
                    $merger->AddPage();
                    $merger->useTemplate($merger->importPage($i));
                }
            }
        }
        
        $merger->Output($outputPath, 'F');
    }
    
    /**
     * Split PDF into multiple files
     */
    public function splitPDF($filepath, $outputDir, $pagesPerFile = 1)
    {
        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }
        
        $pdf = new Fpdi();
        $pageCount = $pdf->setSourceFile($filepath);
        
        $files = [];
        for ($i = 1; $i <= $pageCount; $i += $pagesPerFile) {
            $newPdf = new Fpdi();
            $newPdf->setSourceFile($filepath);
            
            $endPage = min($i + $pagesPerFile - 1, $pageCount);
            for ($j = $i; $j <= $endPage; $j++) {
                $newPdf->AddPage();
                $newPdf->useTemplate($newPdf->importPage($j));
            }
            
            $outputFile = $outputDir . '/split_' . $i . '_' . $endPage . '.pdf';
            $newPdf->Output($outputFile, 'F');
            $files[] = $outputFile;
        }
        
        return $files;
    }
    
    /**
     * Compress PDF
     */
    public function compressPDF($inputPath, $outputPath, $quality = 85)
    {
        // Implementation for PDF compression
        copy($inputPath, $outputPath);
        return $outputPath;
    }
    
    /**
     * Add digital signature
     */
    public function addDigitalSignature($certificatePath, $password = '')
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        // Implementation for digital signature
        $this->annotations[] = [
            'type' => 'digital_signature',
            'certificate' => $certificatePath
        ];
    }
    
    /**
     * Create form fields
     */
    public function createFormField($type, $name, $x, $y, $width, $height, $page = 1)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        
        switch ($type) {
            case 'text':
                $this->pdf->TextField($name, $width, $height, ['x' => $x, 'y' => $y]);
                break;
            case 'checkbox':
                $this->pdf->CheckBox($name, $x, $y, $width, $height);
                break;
            case 'radio':
                $this->pdf->RadioButton($name, $x, $y, $width, $height);
                break;
            case 'dropdown':
                $this->pdf->ComboBox($name, $width, $height, ['x' => $x, 'y' => $y]);
                break;
        }
        
        $this->annotations[] = [
            'type' => 'form_field',
            'field_type' => $type,
            'name' => $name,
            'page' => $page,
            'x' => $x,
            'y' => $y,
            'width' => $width,
            'height' => $height
        ];
    }
    
    /**
     * Fill form fields
     */
    public function fillFormField($name, $value)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->SetField($name, $value);
    }
    
    /**
     * Extract form data
     */
    public function extractFormData($filepath)
    {
        try {
            $pdf = $this->parser->parseFile($filepath);
            return $pdf->getFormData();
        } catch (\Exception $e) {
            throw new \Exception('Error extracting form data: ' . $e->getMessage());
        }
    }
    
    /**
     * Add watermark
     */
    public function addWatermark($text, $page, $x, $y, $fontSize = 48, $color = '#cccccc', $angle = 45)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->pdf->AddPage();
        $this->pdf->SetFont('Arial', '', $fontSize);
        $this->pdf->SetTextColor($this->hexToRgb($color));
        $this->pdf->StartTransform();
        $this->pdf->Rotate($angle, $x, $y);
        $this->pdf->Text($x, $y, $text);
        $this->pdf->StopTransform();
        
        $this->annotations[] = [
            'type' => 'watermark',
            'text' => $text,
            'page' => $page,
            'x' => $x,
            'y' => $y,
            'fontSize' => $fontSize,
            'color' => $color,
            'angle' => $angle
        ];
    }
    
    /**
     * Add header/footer
     */
    public function addHeaderFooter($type, $content, $page = 'all')
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->annotations[] = [
            'type' => $type,
            'content' => $content,
            'page' => $page
        ];
    }
    
    /**
     * Search and replace text
     */
    public function searchReplaceText($search, $replace, $page = null)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        $this->annotations[] = [
            'type' => 'search_replace',
            'search' => $search,
            'replace' => $replace,
            'page' => $page
        ];
    }
    
    /**
     * Batch processing
     */
    public function batchProcess($files, $operation, $params = [])
    {
        $results = [];
        
        foreach ($files as $file) {
            try {
                $this->loadPDF($file);
                
                switch ($operation) {
                    case 'compress':
                        $results[] = $this->compressPDF($file, 'output/' . basename($file), $params['quality'] ?? 85);
                        break;
                    case 'add_watermark':
                        $this->addWatermark($params['text'], 1, 100, 100);
                        $results[] = $this->save('output/' . basename($file));
                        break;
                    case 'add_password':
                        $this->addPasswordProtection($params['password']);
                        $results[] = $this->save('output/' . basename($file));
                        break;
                }
            } catch (\Exception $e) {
                $results[] = ['error' => $e->getMessage(), 'file' => $file];
            }
        }
        
        return $results;
    }
    
    /**
     * Save PDF
     */
    public function save($outputPath = null)
    {
        if (!$this->pdf) {
            throw new \Exception('No PDF loaded');
        }
        
        if (!$outputPath) {
            $outputPath = 'output/' . uniqid('edited_') . '.pdf';
        }
        
        $this->pdf->Output($outputPath, 'F');
        return $outputPath;
    }
    
    /**
     * Get annotations
     */
    public function getAnnotations()
    {
        return $this->annotations;
    }
    
    /**
     * Clear annotations
     */
    public function clearAnnotations()
    {
        $this->annotations = [];
    }
    
    /**
     * Convert hex color to RGB
     */
    private function hexToRgb($hex)
    {
        $hex = str_replace('#', '', $hex);
        
        if (strlen($hex) == 3) {
            $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
            $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
            $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
        } else {
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        }
        
        return [$r, $g, $b];
    }
}
