# Advanced PDF Editor

A comprehensive PHP-based PDF editing tool with a modern, responsive web interface. This application provides extensive PDF manipulation capabilities including text editing, image management, annotations, security features, and more.

## 🚀 Features

### 🔹 Basic Editing
- **Text Management**: Add, edit, or delete text with custom fonts, sizes, and colors
- **Image Operations**: Add, edit, or remove images from PDFs
- **Shapes & Lines**: Insert various shapes, lines, and geometric elements
- **Page Management**: Rearrange, rotate, or delete pages with drag-and-drop functionality

### 🔹 Annotations & Markup
- **Text Highlighting**: Highlight, underline, or strikethrough text
- **Sticky Notes**: Add comments and notes to specific areas
- **Drawing Tools**: Freehand drawing with pen, pencil, and marker tools
- **Stamps & Watermarks**: Add custom stamps and watermarks

### 🔹 Page Management
- **Split PDFs**: Divide single PDFs into multiple files
- **Merge PDFs**: Combine multiple PDFs into one document
- **Page Reordering**: Drag-and-drop page reordering
- **Page Rotation**: Rotate pages at any angle
- **Crop & Resize**: Crop or resize pages as needed

### 🔹 Forms & Fields
- **Form Filling**: Fill in interactive PDF forms
- **Form Creation**: Create new form fields (text boxes, checkboxes, radio buttons, dropdowns)
- **Digital Signatures**: Add digital signature fields
- **Form Data Extraction**: Extract data from filled forms

### 🔹 Security & Permissions
- **Password Protection**: Add or remove password protection
- **Permission Control**: Set print, copy, and edit restrictions
- **Redaction**: Permanently hide sensitive text or images
- **Digital Certificates**: Apply digital signatures and certificates

### 🔹 Content Editing
- **Hyperlink Management**: Edit existing links or add new ones
- **Headers & Footers**: Insert headers, footers, and page numbers
- **Background Elements**: Add background colors or images
- **Page Replacement**: Replace pages with new content
- **Search & Replace**: Find and replace text throughout documents

### 🔹 Advanced Tools
- **OCR Support**: Optical Character Recognition for scanned PDFs
- **Text Conversion**: Convert scanned pages to editable text
- **PDF Compression**: Reduce file size while maintaining quality
- **Format Export**: Export to Word, Excel, PowerPoint, or Image formats
- **Batch Processing**: Process multiple PDFs simultaneously

## 🛠️ Installation

### Prerequisites
- PHP 8.0 or higher
- Composer
- Web server (Apache/Nginx)
- GD extension for PHP
- Fileinfo extension for PHP

### Step 1: Clone or Download
```bash
git clone <repository-url>
cd pdf-edit
```

### Step 2: Install Dependencies
```bash
composer install
```

### Step 3: Set Up Directories
The application will automatically create necessary directories, but you can also create them manually:
```bash
mkdir uploads temp output assets/images logs
chmod 755 uploads temp output assets/images logs
```

### Step 4: Configure Web Server

#### Apache Configuration
Create a `.htaccess` file in the root directory:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"
```

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/pdf-edit;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.0-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
}
```

### Step 5: Environment Configuration
Create a `.env` file in the root directory:
```env
# PDF Editor Configuration
APP_NAME="Advanced PDF Editor"
APP_ENV=development
APP_DEBUG=true

# File Upload Settings
MAX_FILE_SIZE=52428800
UPLOAD_PATH=uploads/
TEMP_PATH=temp/
OUTPUT_PATH=output/

# Security Settings
ALLOWED_FILE_TYPES=pdf
ENABLE_PASSWORD_PROTECTION=true
ENABLE_DIGITAL_SIGNATURES=true

# OCR Settings
ENABLE_OCR=false
OCR_ENGINE=tesseract

# Compression Settings
DEFAULT_COMPRESSION_QUALITY=85
MAX_COMPRESSION_QUALITY=100
MIN_COMPRESSION_QUALITY=10

# Session Settings
SESSION_LIFETIME=3600
SESSION_SECURE=false

# API Settings
API_RATE_LIMIT=100
API_TIMEOUT=30

# Logging
LOG_LEVEL=info
LOG_PATH=logs/
```

### Step 6: Set Permissions
```bash
chmod 755 uploads temp output assets/images logs
chown -R www-data:www-data uploads temp output assets/images logs
```

## 🎯 Usage

### Getting Started
1. Open your web browser and navigate to the application URL
2. Click "Upload PDF" or drag and drop a PDF file
3. Once uploaded, the PDF will be displayed in the viewer
4. Use the sidebar tools to edit your PDF

### Basic Operations

#### Adding Text
1. Click "Text Editor" in the sidebar
2. Enter your text in the text area
3. Choose font family, size, and color
4. Set the position (X, Y coordinates)
5. Click "Add Text"

#### Adding Images
1. Click "Image Editor" in the sidebar
2. Upload an image file
3. Set position and size
4. Click "Add Image"

#### Page Management
1. Click "Page Management" in the sidebar
2. View page thumbnails
3. Use the action buttons to rotate, delete, or duplicate pages

#### Security Features
1. Click "Security" in the sidebar
2. Enter a password for protection
3. Set permissions (print, copy, edit)
4. Click "Apply Security"

### Keyboard Shortcuts
- `Ctrl/Cmd + S`: Save changes
- `Ctrl/Cmd + D`: Download PDF
- `Ctrl/Cmd + H`: Show help
- `Arrow Keys`: Navigate pages
- `Escape`: Close tool panels

## 🔧 API Endpoints

The application provides a RESTful API for programmatic access:

### Text Operations
- `POST /api.php?action=add_text` - Add text to PDF
- `POST /api.php?action=search_replace` - Search and replace text

### Image Operations
- `POST /api.php?action=add_image` - Add image to PDF

### Drawing & Annotations
- `POST /api.php?action=add_drawing` - Add drawing
- `POST /api.php?action=add_highlight` - Add highlight
- `POST /api.php?action=add_watermark` - Add watermark

### Page Management
- `POST /api.php?action=rotate_page` - Rotate page
- `POST /api.php?action=delete_page` - Delete page
- `POST /api.php?action=duplicate_page` - Duplicate page

### Security
- `POST /api.php?action=add_password` - Add password protection
- `POST /api.php?action=set_permissions` - Set permissions

### Forms
- `POST /api.php?action=create_form_field` - Create form field
- `POST /api.php?action=fill_form_field` - Fill form field
- `GET /api.php?action=extract_form_data` - Extract form data

### File Operations
- `POST /api.php?action=save` - Save PDF
- `POST /api.php?action=merge_pdfs` - Merge PDFs
- `POST /api.php?action=split_pdf` - Split PDF
- `POST /api.php?action=compress_pdf` - Compress PDF
- `POST /api.php?action=batch_process` - Batch processing

### Information
- `GET /api.php?action=extract_text` - Extract text
- `GET /api.php?action=pdf_to_images` - Convert to images
- `GET /api.php?action=get_annotations` - Get annotations

## 🛡️ Security Considerations

### File Upload Security
- File type validation
- File size limits
- Secure file naming
- Upload directory protection

### PDF Security
- Password protection
- Permission restrictions
- Digital signatures
- Content redaction

### Application Security
- Input validation
- XSS protection
- CSRF protection
- Secure headers

## 🔍 Troubleshooting

### Common Issues

#### Upload Errors
- Check file size limits in PHP configuration
- Verify upload directory permissions
- Ensure GD extension is installed

#### PDF Loading Issues
- Verify PDF file integrity
- Check file permissions
- Ensure sufficient memory allocation

#### Performance Issues
- Optimize image sizes before upload
- Use compression for large files
- Consider server resources

### Logs
Check the `logs/` directory for error logs and debugging information.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue on GitHub
- Check the documentation
- Review the troubleshooting section

## 🔄 Updates

To update the application:
1. Backup your current installation
2. Download the latest version
3. Replace files (excluding uploads and configuration)
4. Run `composer install` to update dependencies
5. Test the application

---

**Note**: This application requires proper server configuration and security measures for production use. Always test thoroughly in a development environment before deploying to production.
