<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

session_start();

require_once 'vendor/autoload.php';

// Load environment variables
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Initialize PDF editor
$pdfEditor = new PDFEdit\PDFEditor();

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    $method = $_SERVER['REQUEST_METHOD'];
    $action = $_GET['action'] ?? '';
    
    switch ($method) {
        case 'POST':
            handlePostRequest($action, $pdfEditor);
            break;
        case 'GET':
            handleGetRequest($action, $pdfEditor);
            break;
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

function handlePostRequest($action, $pdfEditor) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case 'add_text':
            $pdfEditor->addText(
                $input['text'],
                $input['page'],
                $input['x'],
                $input['y'],
                $input['fontSize'] ?? 12,
                $input['fontFamily'] ?? 'Arial',
                $input['color'] ?? '#000000'
            );
            echo json_encode(['success' => true, 'message' => 'Text added successfully']);
            break;
            
        case 'add_image':
            $pdfEditor->addImage(
                $input['imagePath'],
                $input['page'],
                $input['x'],
                $input['y'],
                $input['width'] ?? null,
                $input['height'] ?? null
            );
            echo json_encode(['success' => true, 'message' => 'Image added successfully']);
            break;
            
        case 'add_drawing':
            $pdfEditor->addDrawing(
                $input['path'],
                $input['page'],
                $input['color'] ?? '#ff0000',
                $input['width'] ?? 2
            );
            echo json_encode(['success' => true, 'message' => 'Drawing added successfully']);
            break;
            
        case 'add_highlight':
            $pdfEditor->addHighlight(
                $input['page'],
                $input['x'],
                $input['y'],
                $input['width'],
                $input['height'],
                $input['color'] ?? '#ffff00'
            );
            echo json_encode(['success' => true, 'message' => 'Highlight added successfully']);
            break;
            
        case 'rotate_page':
            $pdfEditor->rotatePage($input['page'], $input['angle']);
            echo json_encode(['success' => true, 'message' => 'Page rotated successfully']);
            break;
            
        case 'delete_page':
            $pdfEditor->deletePage($input['page']);
            echo json_encode(['success' => true, 'message' => 'Page deleted successfully']);
            break;
            
        case 'duplicate_page':
            $pdfEditor->duplicatePage($input['page']);
            echo json_encode(['success' => true, 'message' => 'Page duplicated successfully']);
            break;
            
        case 'add_password':
            $pdfEditor->addPasswordProtection($input['password'], $input['permissions'] ?? []);
            echo json_encode(['success' => true, 'message' => 'Password protection added successfully']);
            break;
            
        case 'set_permissions':
            $pdfEditor->setPermissions($input['permissions']);
            echo json_encode(['success' => true, 'message' => 'Permissions set successfully']);
            break;
            
        case 'add_watermark':
            $pdfEditor->addWatermark(
                $input['text'],
                $input['page'],
                $input['x'],
                $input['y'],
                $input['fontSize'] ?? 48,
                $input['color'] ?? '#cccccc',
                $input['angle'] ?? 45
            );
            echo json_encode(['success' => true, 'message' => 'Watermark added successfully']);
            break;
            
        case 'add_header_footer':
            $pdfEditor->addHeaderFooter(
                $input['type'],
                $input['content'],
                $input['page'] ?? 'all'
            );
            echo json_encode(['success' => true, 'message' => 'Header/Footer added successfully']);
            break;
            
        case 'search_replace':
            $pdfEditor->searchReplaceText(
                $input['search'],
                $input['replace'],
                $input['page'] ?? null
            );
            echo json_encode(['success' => true, 'message' => 'Text replaced successfully']);
            break;
            
        case 'create_form_field':
            $pdfEditor->createFormField(
                $input['type'],
                $input['name'],
                $input['x'],
                $input['y'],
                $input['width'],
                $input['height'],
                $input['page'] ?? 1
            );
            echo json_encode(['success' => true, 'message' => 'Form field created successfully']);
            break;
            
        case 'fill_form_field':
            $pdfEditor->fillFormField($input['name'], $input['value']);
            echo json_encode(['success' => true, 'message' => 'Form field filled successfully']);
            break;
            
        case 'add_digital_signature':
            $pdfEditor->addDigitalSignature(
                $input['certificatePath'],
                $input['password'] ?? ''
            );
            echo json_encode(['success' => true, 'message' => 'Digital signature added successfully']);
            break;
            
        case 'save':
            $outputPath = $pdfEditor->save($input['outputPath'] ?? null);
            echo json_encode([
                'success' => true,
                'message' => 'PDF saved successfully',
                'outputPath' => $outputPath
            ]);
            break;
            
        case 'batch_process':
            $results = $pdfEditor->batchProcess(
                $input['files'],
                $input['operation'],
                $input['params'] ?? []
            );
            echo json_encode([
                'success' => true,
                'message' => 'Batch processing completed',
                'results' => $results
            ]);
            break;
            
        case 'merge_pdfs':
            $pdfEditor->mergePDFs($input['files'], $input['outputPath']);
            echo json_encode(['success' => true, 'message' => 'PDFs merged successfully']);
            break;
            
        case 'split_pdf':
            $files = $pdfEditor->splitPDF(
                $input['filepath'],
                $input['outputDir'],
                $input['pagesPerFile'] ?? 1
            );
            echo json_encode([
                'success' => true,
                'message' => 'PDF split successfully',
                'files' => $files
            ]);
            break;
            
        case 'compress_pdf':
            $outputPath = $pdfEditor->compressPDF(
                $input['inputPath'],
                $input['outputPath'],
                $input['quality'] ?? 85
            );
            echo json_encode([
                'success' => true,
                'message' => 'PDF compressed successfully',
                'outputPath' => $outputPath
            ]);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
}

function handleGetRequest($action, $pdfEditor) {
    switch ($action) {
        case 'extract_text':
            $text = $pdfEditor->extractText($_GET['filepath']);
            echo json_encode([
                'success' => true,
                'text' => $text
            ]);
            break;
            
        case 'extract_form_data':
            $formData = $pdfEditor->extractFormData($_GET['filepath']);
            echo json_encode([
                'success' => true,
                'formData' => $formData
            ]);
            break;
            
        case 'pdf_to_images':
            $images = $pdfEditor->pdfToImages(
                $_GET['filepath'],
                $_GET['outputDir'] ?? 'temp',
                $_GET['format'] ?? 'png'
            );
            echo json_encode([
                'success' => true,
                'images' => $images
            ]);
            break;
            
        case 'get_annotations':
            $annotations = $pdfEditor->getAnnotations();
            echo json_encode([
                'success' => true,
                'annotations' => $annotations
            ]);
            break;
            
        case 'clear_annotations':
            $pdfEditor->clearAnnotations();
            echo json_encode([
                'success' => true,
                'message' => 'Annotations cleared successfully'
            ]);
            break;
            
        default:
            throw new Exception('Invalid action');
    }
}
?>
