# GST Calculator India - Demo Usage

This document shows how to use the GST Calculator plugin with the new prompt button functionality.

## Basic Usage

### 1. GST Calculator
Use the main calculator shortcode:
```
[gst_calculator]
```

### 2. Prompt Button
Use the prompt button shortcode to display the original requirements:
```
[gst_prompt_button]
```

### 3. Combined Usage
You can use both shortcodes together on the same page:
```
[gst_prompt_button]

[gst_calculator]
```

## Advanced Usage

### Customizing the Prompt Button
You can customize the button text and styling:

```
[gst_prompt_button text="View Original Requirements" class="custom-prompt-btn"]
```

### Customizing the Calculator
You can customize the calculator title and breakdown display:

```
[gst_calculator title="Custom GST Calculator" show_breakdown="false"]
```

## Complete Example Page

Here's a complete example of how to use both features:

```html
<h2>GST Calculator India</h2>

<!-- Prompt Button -->
[gst_prompt_button text="View Original Requirements"]

<!-- Calculator -->
[gst_calculator title="GST Calculator India" show_breakdown="true"]
```

## Features

### Prompt Button Features:
- ✅ Displays original plugin requirements in a modal popup
- ✅ AJAX-powered content loading
- ✅ Responsive design
- ✅ Keyboard navigation (Escape to close)
- ✅ Click outside to close
- ✅ Loading states and error handling
- ✅ Smooth animations

### Calculator Features:
- ✅ GST calculation with AJAX
- ✅ CGST/SGST breakdown
- ✅ Real-time validation
- ✅ Responsive design
- ✅ Accessibility features
- ✅ Modern UI with FontAwesome icons

## Installation

1. Upload the plugin files to `/wp-content/plugins/gst-calculator-india/`
2. Activate the plugin in WordPress admin
3. Use the shortcodes on any page or post

## Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Mobile browsers

## Accessibility

Both the calculator and prompt modal include:
- Keyboard navigation
- ARIA attributes
- Focus management
- Screen reader support
- High contrast support 