# GST Calculator India - WordPress Plugin

A comprehensive WordPress plugin for calculating Goods and Services Tax (GST) for Indian businesses. Features AJAX-powered dynamic calculations, CGST/SGST breakdown, and a modern, responsive interface.

## 🚀 Features

- **Dynamic GST Calculation**: Real-time calculation without page refresh using AJAX
- **Multiple GST Rates**: Support for 5%, 12%, 18%, and 28% GST rates
- **CGST & SGST Breakdown**: Automatic calculation of Central GST and State GST for intra-state transactions
- **Modern UI**: Beautiful, responsive design with FontAwesome icons
- **Form Validation**: Real-time input validation with visual feedback
- **Accessibility**: Keyboard navigation and screen reader support
- **Mobile Responsive**: Optimized for all device sizes
- **Shortcode Support**: Easy integration with `[gst_calculator]` shortcode

## 📋 Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- jQuery (included with WordPress)
- Modern web browser with JavaScript enabled

## 🛠️ Installation

### Method 1: Manual Installation

1. **Download the Plugin**
   - Download all plugin files to your local machine
   - Ensure the file structure is maintained as shown below

2. **Upload to WordPress**
   - Log in to your WordPress admin dashboard
   - Navigate to **Plugins > Add New > Upload Plugin**
   - Click **Choose File** and select the `gst-calculator.php` file
   - Click **Install Now**
   - Activate the plugin

3. **Verify Installation**
   - Go to **Plugins > Installed Plugins**
   - Look for "GST Calculator India" in the list
   - Ensure it shows as "Active"

### Method 2: FTP Upload

1. **Prepare Files**
   - Create a folder named `gst-calculator-india` in your WordPress plugins directory
   - Upload all plugin files to this folder

2. **File Structure**
   ```
   wp-content/plugins/gst-calculator-india/
   ├── gst-calculator.php
   ├── css/
   │   └── style.css
   ├── js/
   │   └── script.js
   └── README.md
   ```

3. **Activate Plugin**
   - Go to **Plugins > Installed Plugins**
   - Find "GST Calculator India" and click **Activate**

## 📖 Usage

### Basic Usage

Add the GST calculator to any page or post using the shortcode:

```
[gst_calculator]
```

### Advanced Usage

Customize the calculator with shortcode attributes:

```
[gst_calculator title="Custom GST Calculator" show_breakdown="false"]
```

**Available Attributes:**
- `title`: Custom title for the calculator (default: "GST Calculator India")
- `show_breakdown`: Show/hide CGST & SGST breakdown (default: "true")

### Examples

**Basic Calculator:**
```
[gst_calculator]
```

**Custom Title:**
```
[gst_calculator title="Business GST Calculator"]
```

**Without Breakdown:**
```
[gst_calculator show_breakdown="false"]
```

**Full Customization:**
```
[gst_calculator title="Professional GST Calculator" show_breakdown="true"]
```

## 🧮 How It Works

### Calculation Formula

The plugin uses the standard GST calculation formula:

```
GST Amount = (Original Price × GST Rate) ÷ 100
Final Price = Original Price + GST Amount
CGST Amount = SGST Amount = GST Amount ÷ 2
```

### GST Rates Supported

- **5%**: Essential goods and services
- **12%**: Standard rate for most goods
- **18%**: Standard rate for most services
- **28%**: Luxury goods and services

### CGST & SGST Breakdown

For intra-state transactions, the total GST is split equally:
- **CGST (Central GST)**: 50% of total GST
- **SGST (State GST)**: 50% of total GST

## 🎨 Customization

### Styling

The plugin includes comprehensive CSS styling in `css/style.css`. You can customize the appearance by:

1. **Theme Override**: Add custom CSS to your theme's stylesheet
2. **Plugin Modification**: Edit `css/style.css` directly (backup first!)

### Key CSS Classes

- `.gst-calculator-container`: Main container
- `.gst-calculator-header`: Header section
- `.gst-calculator-form`: Form section
- `.gst-calculator-results`: Results section
- `.result-item`: Individual result items
- `.breakdown-section`: CGST/SGST breakdown

### JavaScript Customization

The JavaScript functionality is in `js/script.js`. Key features:

- AJAX calculation handling
- Form validation
- Error handling
- Loading states
- Accessibility enhancements

## 🔧 Troubleshooting

### Common Issues

**1. Calculator Not Appearing**
- Ensure the shortcode is correctly placed: `[gst_calculator]`
- Check that the plugin is activated
- Verify JavaScript is enabled in your browser

**2. AJAX Errors**
- Check browser console for JavaScript errors
- Ensure WordPress AJAX is working
- Verify nonce security is not blocking requests

**3. Styling Issues**
- Clear browser cache
- Check for CSS conflicts with your theme
- Verify FontAwesome is loading correctly

**4. Mobile Responsiveness**
- Test on different devices
- Check viewport meta tag in your theme
- Verify CSS media queries are working

### Debug Mode

Enable WordPress debug mode to see detailed error messages:

```php
// Add to wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

### Browser Compatibility

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Features

- **Nonce Verification**: All AJAX requests include security nonces
- **Input Sanitization**: All user inputs are properly sanitized
- **Output Escaping**: All output is properly escaped
- **SQL Injection Protection**: No direct database queries
- **XSS Protection**: Proper escaping of all user data

## 📱 Mobile Optimization

The plugin is fully responsive and optimized for mobile devices:

- Touch-friendly interface
- Optimized button sizes
- Responsive grid layouts
- Mobile-specific styling
- Touch gesture support

## 🌐 Browser Support

- **Desktop**: Chrome, Firefox, Safari, Edge
- **Mobile**: iOS Safari, Chrome Mobile, Samsung Internet
- **Legacy**: Internet Explorer 11+ (with polyfills)

## 📄 License

This plugin is licensed under the GPL v2 or later.

## 🤝 Support

For support and feature requests:

1. Check the troubleshooting section above
2. Review WordPress error logs
3. Test with a default theme
4. Disable other plugins to check for conflicts

## 🔄 Updates

To update the plugin:

1. **Backup**: Always backup your site before updating
2. **Deactivate**: Deactivate the plugin
3. **Replace Files**: Upload new plugin files
4. **Reactivate**: Reactivate the plugin
5. **Test**: Test functionality on a staging site

## 📊 Performance

The plugin is optimized for performance:

- Minimal database queries
- Efficient AJAX handling
- Optimized CSS and JavaScript
- Lazy loading of resources
- Caching-friendly structure

## 🎯 Best Practices

1. **Regular Updates**: Keep the plugin updated
2. **Backup**: Regular backups of your site
3. **Testing**: Test on staging before production
4. **Monitoring**: Monitor for errors and performance
5. **Documentation**: Keep notes of customizations

---

**Version**: 1.0.0  
**Last Updated**: January 2025  
**Compatibility**: WordPress 5.0+  
**PHP Version**: 7.4+ 