import React, { useState } from "react";
import axios from "axios";

function App() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  const handleUpload = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);

    setStatus("Uploading...");

    try {
      const res = await axios.post("http://localhost:8000/upload/", formData);
      setStatus(`✅ Uploaded! ID: ${res.data.id}`);
    } catch (err) {
      setStatus("❌ Upload failed");
    }
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h2>📄 Manuscript Uploader</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <br /><br />
      <button onClick={handleUpload}>Upload</button>
      <p>{status}</p>
    </div>
  );
}

export default App;
