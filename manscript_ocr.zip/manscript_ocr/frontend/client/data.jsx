import React, { useState } from "react";
import axios from "axios";
import PDFPreview from "./PDFPreview";
import VectorResults from "./VectorResults";

function App() {
  const [file, setFile] = useState(null);
  const [docId, setDocId] = useState(null);
  const [pdfUrl, setPdfUrl] = useState("");
  const [vectorResults, setVectorResults] = useState([]);

  const uploadFile = async () => {
    if (!file) return;
    const form = new FormData(); form.append("file", file);
    const res = await axios.post("/upload/", form);
    setDocId(res.data.id);
    setPdfUrl(`/files/${res.data.id}.pdf`);
  };

  const runSearch = async () => {
    const res = await axios.get("/search/", { params: { q: "ancient India" } });
    setVectorResults(res.data.results);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>🧾 Manuscript Uploader</h2>
      <input type="file" onChange={e => setFile(e.target.files[0])} />
      <button onClick={uploadFile}>Upload</button>

      {docId && (
        <div>
          <h3>📄 Preview</h3>
          <PDFPreview url={pdfUrl} />
          <button style={{ marginTop: 10 }} onClick={runSearch}>
            Run Semantic Search
          </button>
          <VectorResults results={vectorResults} />
        </div>
      )}
    </div>
  );
}

export default App;

