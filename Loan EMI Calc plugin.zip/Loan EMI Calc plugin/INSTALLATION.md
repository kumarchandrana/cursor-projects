# Quick Installation Guide

## Step-by-Step Installation

### 1. Download the Plugin
- Download all files from this repository
- Keep the folder structure intact

### 2. Upload to WordPress
**Option A: WordPress Admin**
1. Go to your WordPress admin panel
2. Navigate to **Plugins > Add New**
3. Click **Upload Plugin**
4. Choose the plugin folder or zip file
5. Click **Install Now**

**Option B: FTP Upload**
1. Use FTP to connect to your server
2. Navigate to `/wp-content/plugins/`
3. Upload the `loan-emi-calculator` folder
4. Ensure the path is: `/wp-content/plugins/loan-emi-calculator/`

### 3. Activate the Plugin
1. Go to **Plugins** in your WordPress admin
2. Find "Loan EMI Calculator"
3. Click **Activate**

### 4. Use the Plugin
Add the shortcode to any page or post:
```
[emi_calculator]
```

## File Structure
```
loan-emi-calculator/
├── loan-emi-calculator.php
├── css/
│   └── style.css
├── js/
│   └── script.js
├── README.md
└── INSTALLATION.md
```

## Requirements
- WordPress 5.0+
- PHP 7.0+
- Modern web browser

## Support
If you encounter any issues, check the main README.md file for troubleshooting tips. 