<?php
/**
 * Plugin Name: Loan EMI Calculator
 * Plugin URI: https://example.com/loan-emi-calculator
 * Description: A WordPress plugin to calculate loan EMI with a shortcode [emi_calculator]
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: loan-emi-calculator
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LOAN_EMI_CALCULATOR_VERSION', '1.0.0');
define('LOAN_EMI_CALCULATOR_PLUGIN_URL', plugin_dir_url(__FILE__));
define('LOAN_EMI_CALCULATOR_PLUGIN_PATH', plugin_dir_path(__FILE__));

class LoanEMICalculator {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_calculate_emi', array($this, 'calculate_emi_ajax'));
        add_action('wp_ajax_nopriv_calculate_emi', array($this, 'calculate_emi_ajax'));
    }
    
    public function init() {
        add_shortcode('emi_calculator', array($this, 'emi_calculator_shortcode'));
    }
    
    public function enqueue_scripts() {
        // Enqueue FontAwesome
        wp_enqueue_style(
            'fontawesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
            array(),
            '6.0.0'
        );
        
        // Enqueue plugin CSS
        wp_enqueue_style(
            'loan-emi-calculator-style',
            LOAN_EMI_CALCULATOR_PLUGIN_URL . 'css/style.css',
            array(),
            LOAN_EMI_CALCULATOR_VERSION
        );
        
        // Enqueue plugin JavaScript
        wp_enqueue_script(
            'loan-emi-calculator-script',
            LOAN_EMI_CALCULATOR_PLUGIN_URL . 'js/script.js',
            array('jquery'),
            LOAN_EMI_CALCULATOR_VERSION,
            true
        );
        
        // Localize script for AJAX
        wp_localize_script(
            'loan-emi-calculator-script',
            'loan_emi_ajax',
            array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('loan_emi_nonce')
            )
        );
    }
    
    public function emi_calculator_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Loan EMI Calculator',
            'currency' => '₹'
        ), $atts);
        
        ob_start();
        ?>
        <div class="loan-emi-calculator">
            <div class="emi-calculator-header">
                <h3><i class="fas fa-calculator"></i> <?php echo esc_html($atts['title']); ?></h3>
            </div>
            
            <div class="emi-calculator-form">
                <div class="form-group">
                    <label for="loan_amount">
                        <i class="fas fa-money-bill-wave"></i> Loan Amount (<?php echo esc_html($atts['currency']); ?>)
                    </label>
                    <input type="text" id="loan_amount" name="loan_amount" placeholder="Enter loan amount (₹1 to ₹10000000000)" maxlength="11" required>

                </div>
                
                <div class="form-group">
                    <label for="interest_rate">
                        <i class="fas fa-percentage"></i> Interest Rate (% per annum)
                    </label>
                    <input type="number" id="interest_rate" name="interest_rate" placeholder="Enter interest rate" min="0.1" max="50" step="0.1" required>
                </div>
                
                <div class="form-group">
                    <label for="loan_tenure">
                        <i class="fas fa-calendar-alt"></i> Loan Tenure
                    </label>
                    <div class="tenure-input-group">
                        <input type="number" id="loan_tenure" name="loan_tenure" placeholder="Enter tenure" min="1" required>
                        <select id="tenure_type" name="tenure_type">
                            <option value="years">Years</option>
                            <option value="months">Months</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="button" id="calculate_emi" class="calculate-btn">
                        <i class="fas fa-calculator"></i> Calculate EMI
                    </button>
                </div>
            </div>
            
            <div class="emi-calculator-results" id="emi_results" style="display: none;">
                <h4><i class="fas fa-chart-pie"></i> EMI Calculation Results</h4>
                <div class="results-grid">
                    <div class="result-item">
                        <div class="result-label">
                            <i class="fas fa-calendar-check"></i> Monthly EMI
                        </div>
                        <div class="result-value" id="monthly_emi">-</div>
                    </div>
                    
                    <div class="result-item">
                        <div class="result-label">
                            <i class="fas fa-coins"></i> Total Interest Payable
                        </div>
                        <div class="result-value" id="total_interest">-</div>
                    </div>
                    
                    <div class="result-item">
                        <div class="result-label">
                            <i class="fas fa-money-bill-alt"></i> Total Amount Payable
                        </div>
                        <div class="result-value" id="total_amount">-</div>
                    </div>
                </div>
                
                <div class="emi-breakdown">
                    <h5><i class="fas fa-info-circle"></i> EMI Breakdown</h5>
                    <div class="breakdown-item">
                        <span>Principal Amount:</span>
                        <span id="principal_amount">-</span>
                    </div>
                    <div class="breakdown-item">
                        <span>Interest Amount:</span>
                        <span id="interest_amount">-</span>
                    </div>
                    <div class="breakdown-item total">
                        <span>Total Amount:</span>
                        <span id="breakdown_total">-</span>
                    </div>
                </div>
            </div>
            
            <div class="emi-calculator-error" id="emi_error" style="display: none;">
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span id="error_text"></span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    public function calculate_emi_ajax() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'loan_emi_nonce')) {
            wp_die('Security check failed');
        }
        
        // Get and validate input
        $loan_amount = floatval($_POST['loan_amount']);
        $interest_rate = floatval($_POST['interest_rate']);
        $loan_tenure = intval($_POST['loan_tenure']);
        $tenure_type = sanitize_text_field($_POST['tenure_type']);
        
        // Validation
        if ($loan_amount < 1 || $loan_amount > 10000000000 || strlen((string)$loan_amount) > 10) {
            wp_send_json_error('Please enter a valid loan amount (₹1 to ₹10,000,000,000, maximum 10 digits).');
        }
        
        if ($interest_rate <= 0 || $interest_rate > 50) {
            wp_send_json_error('Please enter a valid interest rate (0.1% to 50%).');
        }
        
        if ($loan_tenure <= 0) {
            wp_send_json_error('Please enter a valid loan tenure.');
        }
        
        // Convert tenure to months if in years
        if ($tenure_type === 'years') {
            $loan_tenure = $loan_tenure * 12;
        }
        
        // Calculate monthly interest rate
        $monthly_interest_rate = $interest_rate / 12 / 100;
        
        // Calculate EMI using the formula: EMI = [P × R × (1+R)^N] / [(1+R)^N – 1]
        $principal = $loan_amount;
        $rate = $monthly_interest_rate;
        $time = $loan_tenure;
        
        if ($rate == 0) {
            $emi = $principal / $time;
        } else {
            $emi = $principal * $rate * pow(1 + $rate, $time) / (pow(1 + $rate, $time) - 1);
        }
        
        // Calculate totals
        $total_amount = $emi * $time;
        $total_interest = $total_amount - $principal;
        
        // Format results
        $results = array(
            'monthly_emi' => number_format($emi, 2),
            'total_interest' => number_format($total_interest, 2),
            'total_amount' => number_format($total_amount, 2),
            'principal_amount' => number_format($principal, 2),
            'interest_amount' => number_format($total_interest, 2),
            'breakdown_total' => number_format($total_amount, 2),
            'currency' => '₹'
        );
        
        wp_send_json_success($results);
    }
}

// Initialize the plugin
new LoanEMICalculator();

// Activation hook
register_activation_hook(__FILE__, 'loan_emi_calculator_activate');
function loan_emi_calculator_activate() {
    // Create necessary directories if they don't exist
    $css_dir = LOAN_EMI_CALCULATOR_PLUGIN_PATH . 'css';
    $js_dir = LOAN_EMI_CALCULATOR_PLUGIN_PATH . 'js';
    
    if (!file_exists($css_dir)) {
        wp_mkdir_p($css_dir);
    }
    
    if (!file_exists($js_dir)) {
        wp_mkdir_p($js_dir);
    }
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'loan_emi_calculator_deactivate');
function loan_emi_calculator_deactivate() {
    // Clean up if needed
} 