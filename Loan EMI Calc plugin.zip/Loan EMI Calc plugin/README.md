# Loan EMI Calculator WordPress Plugin

A modern, responsive WordPress plugin that helps users calculate their monthly loan EMI (Equated Monthly Installment) with a beautiful user interface and AJAX-powered calculations.

## Features

- **Modern UI/UX**: Clean, responsive design with smooth animations
- **AJAX Calculations**: Instant results without page refresh
- **FontAwesome Icons**: Beautiful visual elements throughout the interface
- **Input Validation**: Real-time validation with helpful error messages
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Accessibility**: ARIA labels and keyboard navigation support
- **Shortcode Support**: Easy to embed on any page or post

## Installation

### Method 1: Manual Installation

1. **Download the Plugin Files**
   - Download all plugin files to your computer
   - Ensure the file structure is maintained:
   ```
   loan-emi-calculator/
   ├── loan-emi-calculator.php
   ├── css/
   │   └── style.css
   ├── js/
   │   └── script.js
   └── README.md
   ```

2. **Upload to WordPress**
   - Log in to your WordPress admin panel
   - Go to **Plugins > Add New**
   - Click **Upload Plugin**
   - Choose the plugin zip file or folder
   - Click **Install Now**

3. **Activate the Plugin**
   - After installation, click **Activate Plugin**

### Method 2: FTP Upload

1. **Upload Files**
   - Use FTP to upload the plugin folder to `/wp-content/plugins/`
   - The path should be: `/wp-content/plugins/loan-emi-calculator/`

2. **Activate Plugin**
   - Go to **Plugins** in your WordPress admin
   - Find "Loan EMI Calculator" and click **Activate**

## Usage

### Basic Usage

Simply add the shortcode `[emi_calculator]` to any page or post where you want the calculator to appear.

**Example:**
```
[emi_calculator]
```

### Advanced Usage

You can customize the calculator with shortcode attributes:

```
[emi_calculator title="Custom Calculator Title" currency="$"]
```

**Available Attributes:**
- `title`: Custom title for the calculator (default: "Loan EMI Calculator")
- `currency`: Currency symbol (default: "₹")

### Examples

**Basic Calculator:**
```
[emi_calculator]
```

**Custom Title:**
```
[emi_calculator title="Home Loan EMI Calculator"]
```

**US Dollar Currency:**
```
[emi_calculator currency="$" title="US Loan Calculator"]
```

## How It Works

### EMI Formula

The plugin uses the standard EMI formula:
```
EMI = [P × R × (1+R)^N] / [(1+R)^N – 1]
```

Where:
- **P** = Principal Loan Amount
- **R** = Monthly Interest Rate (Annual Rate ÷ 12 ÷ 100)
- **N** = Total Number of Months

### Input Fields

1. **Loan Amount**: Enter the principal amount you want to borrow
2. **Interest Rate**: Annual interest rate offered by the bank
3. **Loan Tenure**: Duration of the loan (in years or months)

### Results Displayed

- **Monthly EMI**: Your monthly payment amount
- **Total Interest Payable**: Total interest over the loan term
- **Total Amount Payable**: Principal + Total Interest
- **EMI Breakdown**: Detailed breakdown of principal and interest

## Technical Details

### Files Structure

```
loan-emi-calculator/
├── loan-emi-calculator.php    # Main plugin file
├── css/
│   └── style.css             # Stylesheet
├── js/
│   └── script.js             # JavaScript functionality
└── README.md                 # This file
```

### Dependencies

- **WordPress**: 5.0 or higher
- **jQuery**: Included with WordPress
- **FontAwesome**: Loaded from CDN
- **PHP**: 7.0 or higher

### Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Customization

### Styling

You can customize the appearance by modifying `css/style.css`. The plugin uses CSS custom properties and modern CSS features.

### JavaScript

The JavaScript file (`js/script.js`) handles:
- Form validation
- AJAX requests
- UI interactions
- Accessibility features

### PHP Customization

The main plugin file contains:
- Shortcode registration
- AJAX handlers
- EMI calculation logic
- WordPress hooks and filters

## Troubleshooting

### Common Issues

1. **Calculator Not Appearing**
   - Ensure the plugin is activated
   - Check if the shortcode is correctly placed
   - Verify no JavaScript errors in browser console

2. **AJAX Not Working**
   - Check if your theme supports jQuery
   - Ensure no JavaScript conflicts
   - Verify WordPress AJAX is enabled

3. **Styling Issues**
   - Check if your theme CSS is overriding plugin styles
   - Ensure FontAwesome is loading correctly
   - Verify responsive design on mobile devices

### Debug Mode

To enable debug mode, add this to your `wp-config.php`:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

## Security Features

- **Nonce Verification**: All AJAX requests are protected with WordPress nonces
- **Input Sanitization**: All user inputs are properly sanitized
- **Output Escaping**: All output is properly escaped
- **SQL Injection Protection**: Uses WordPress prepared statements

## Performance

- **Minimal Dependencies**: Only requires jQuery (already included in WordPress)
- **Optimized CSS**: Efficient selectors and minimal file size
- **Lazy Loading**: Scripts and styles loaded only when needed
- **CDN Usage**: FontAwesome loaded from CDN for better performance

## Support

For support and feature requests, please contact the plugin developer.

## Changelog

### Version 1.0.0
- Initial release
- Basic EMI calculation functionality
- AJAX-powered calculations
- Responsive design
- FontAwesome integration
- Input validation
- Accessibility features

## License

This plugin is licensed under the GPL v2 or later.

## Credits

- **FontAwesome**: Icons by FontAwesome
- **WordPress**: Built on WordPress platform
- **jQuery**: JavaScript library

---

**Note**: This plugin is designed for educational and informational purposes. Always consult with financial professionals for actual loan calculations and decisions. 