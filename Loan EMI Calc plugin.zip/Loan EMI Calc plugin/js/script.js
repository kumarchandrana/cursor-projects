jQuery(document).ready(function($) {
    
    // Initialize the EMI Calculator
    function initEMICalculator() {
        const $calculator = $('.loan-emi-calculator');
        const $calculateBtn = $('#calculate_emi');
        const $results = $('#emi_results');
        const $error = $('#emi_error');
        
        // Handle Calculate EMI button click
        $calculateBtn.on('click', function(e) {
            e.preventDefault();
            calculateEMI();
        });
        
        // Handle Enter key press on inputs
        $calculator.find('input, select').on('keypress', function(e) {
            if (e.which === 13) { // Enter key
                e.preventDefault();
                calculateEMI();
            }
        });
        
        // Real-time validation
        $calculator.find('input').on('input', function() {
            validateInput($(this));
        });
        
        // Handle tenure type change
        $('#tenure_type').on('change', function() {
            updateTenurePlaceholder();
        });
        
        // Initialize tenure placeholder
        updateTenurePlaceholder();
    }
    
    // Update tenure placeholder based on type
    function updateTenurePlaceholder() {
        const tenureType = $('#tenure_type').val();
        const placeholder = tenureType === 'years' ? 'Enter years (e.g., 5)' : 'Enter months (e.g., 60)';
        $('#loan_tenure').attr('placeholder', placeholder);
    }
    
    // Validate individual input
    function validateInput($input) {
        const value = $input.val();
        const field = $input.attr('id');
        
        // Remove previous error styling
        $input.removeClass('error');
        
        if (value === '') {
            return true; // Allow empty for real-time validation
        }
        
        let isValid = true;
        
        switch (field) {
            case 'loan_amount':
                // Allow positive numbers from 1 to 10,000,000,000 (max 10 digits)
                if (value < 1 || value > 10000000000 || value.length > 10) {
                    isValid = false;
                }
                break;
            case 'interest_rate':
                if (value < 0.1 || value > 50) {
                    isValid = false;
                }
                break;
            case 'loan_tenure':
                if (value < 1) {
                    isValid = false;
                }
                break;
        }
        
        if (!isValid) {
            $input.addClass('error');
        }
        
        return isValid;
    }
    
    // Validate all inputs
    function validateForm() {
        const $loanAmount = $('#loan_amount');
        const $interestRate = $('#interest_rate');
        const $loanTenure = $('#loan_tenure');
        
        let isValid = true;
        
        // Check if all fields are filled
        if (!$loanAmount.val() || !$interestRate.val() || !$loanTenure.val()) {
            showError('Please fill in all required fields.');
            return false;
        }
        
        // Validate individual fields
        if (!validateInput($loanAmount)) {
            showError('Please enter a valid loan amount (₹1 to ₹10,000,000,000, maximum 10 digits).');
            isValid = false;
        }
        
        if (!validateInput($interestRate)) {
            showError('Please enter a valid interest rate (0.1% to 50%).');
            isValid = false;
        }
        
        if (!validateInput($loanTenure)) {
            showError('Please enter a valid loan tenure (minimum 1).');
            isValid = false;
        }
        
        return isValid;
    }
    
    // Calculate EMI via AJAX
    function calculateEMI() {
        if (!validateForm()) {
            return;
        }
        
        const $calculateBtn = $('#calculate_emi');
        const $results = $('#emi_results');
        const $error = $('#emi_error');
        
        // Hide previous results and errors
        $results.hide();
        $error.hide();
        
        // Show loading state
        $calculateBtn.addClass('loading').prop('disabled', true);
        
        // Prepare data
        const formData = {
            action: 'calculate_emi',
            nonce: loan_emi_ajax.nonce,
            loan_amount: $('#loan_amount').val(), // Clean numeric value
            interest_rate: $('#interest_rate').val(),
            loan_tenure: $('#loan_tenure').val(),
            tenure_type: $('#tenure_type').val()
        };
        
        // Make AJAX request
        $.ajax({
            url: loan_emi_ajax.ajax_url,
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $calculateBtn.removeClass('loading').prop('disabled', false);
                
                if (response.success) {
                    displayResults(response.data);
                } else {
                    showError(response.data || 'An error occurred while calculating EMI.');
                }
            },
            error: function(xhr, status, error) {
                $calculateBtn.removeClass('loading').prop('disabled', false);
                showError('Network error. Please try again.');
                console.error('AJAX Error:', error);
            }
        });
    }
    
    // Display calculation results
    function displayResults(data) {
        const $results = $('#emi_results');
        const currency = data.currency || '₹';
        
        // Update result values
        $('#monthly_emi').text(currency + ' ' + data.monthly_emi);
        $('#total_interest').text(currency + ' ' + data.total_interest);
        $('#total_amount').text(currency + ' ' + data.total_amount);
        $('#principal_amount').text(currency + ' ' + data.principal_amount);
        $('#interest_amount').text(currency + ' ' + data.interest_amount);
        $('#breakdown_total').text(currency + ' ' + data.breakdown_total);
        
        // Show results with animation
        $results.show();
        
        // Add success animation to result items
        $('.result-item').addClass('success');
        setTimeout(function() {
            $('.result-item').removeClass('success');
        }, 600);
        
        // Scroll to results if needed
        if (!isElementInViewport($results[0])) {
            $('html, body').animate({
                scrollTop: $results.offset().top - 50
            }, 500);
        }
    }
    
    // Show error message
    function showError(message) {
        const $error = $('#emi_error');
        const $errorText = $('#error_text');
        
        $errorText.text(message);
        $error.show();
        
        // Scroll to error if needed
        if (!isElementInViewport($error[0])) {
            $('html, body').animate({
                scrollTop: $error.offset().top - 50
            }, 500);
        }
    }
    
    // Check if element is in viewport
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    // Format number with commas
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
    // Add input formatting for better UX
    function addInputFormatting() {
        // Simple numeric input for loan amount - no comma formatting to avoid parsing issues
        $('#loan_amount').on('input', function() {
            let value = $(this).val();
            
            // Remove any non-numeric characters
            value = value.replace(/[^\d]/g, '');
            
            // Limit to maximum 10 digits
            if (value.length > 10) {
                value = value.substring(0, 10);
            }
            
            // Update the input with clean numeric value
            $(this).val(value);
        });
        
        // Handle paste events
        $('#loan_amount').on('paste', function(e) {
            setTimeout(function() {
                let value = $(this).val();
                value = value.replace(/[^\d]/g, '');
                if (value.length > 10) {
                    value = value.substring(0, 10);
                }
                $(this).val(value);
            }.bind(this), 10);
        });
        
        // Limit decimal places for interest rate
        $('#interest_rate').on('input', function() {
            let value = $(this).val();
            if (value && value.includes('.')) {
                let parts = value.split('.');
                if (parts[1].length > 2) {
                    $(this).val(parts[0] + '.' + parts[1].substring(0, 2));
                }
            }
        });
    }
    
    // Add tooltips for better UX
    function addTooltips() {
        // Add title attributes for better accessibility
        $('#loan_amount').attr('title', 'Enter the loan amount you want to borrow');
        $('#interest_rate').attr('title', 'Enter the annual interest rate offered by the bank');
        $('#loan_tenure').attr('title', 'Enter the loan duration');
        $('#tenure_type').attr('title', 'Select whether tenure is in years or months');
    }
    
    // Initialize everything
    initEMICalculator();
    addInputFormatting();
    addTooltips();
    
    // Handle window resize for responsive design
    $(window).on('resize', function() {
        // Recalculate any responsive elements if needed
        updateTenurePlaceholder();
    });
    
    // Add keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + Enter to calculate
        if ((e.ctrlKey || e.metaKey) && e.which === 13) {
            e.preventDefault();
            calculateEMI();
        }
    });
    
    // Add form reset functionality
    function addResetFunctionality() {
        // Add a reset button or clear functionality
        $('.loan-emi-calculator').on('dblclick', '.emi-calculator-header', function() {
            if (confirm('Reset the calculator?')) {
                $('.loan-emi-calculator input').val('');
                $('#emi_results').hide();
                $('#emi_error').hide();
                $('#calculate_emi').removeClass('loading').prop('disabled', false);
            }
        });
    }
    
    addResetFunctionality();
    
    // Add accessibility improvements
    function addAccessibilityFeatures() {
        // Add ARIA labels
        $('#loan_amount').attr('aria-label', 'Loan amount in rupees');
        $('#interest_rate').attr('aria-label', 'Annual interest rate in percentage');
        $('#loan_tenure').attr('aria-label', 'Loan tenure');
        $('#tenure_type').attr('aria-label', 'Tenure type selection');
        $('#calculate_emi').attr('aria-label', 'Calculate EMI button');
        
        // Add focus management
        $('.loan-emi-calculator input').on('focus', function() {
            $(this).closest('.form-group').addClass('focused');
        }).on('blur', function() {
            $(this).closest('.form-group').removeClass('focused');
        });
    }
    
    addAccessibilityFeatures();
    
}); 