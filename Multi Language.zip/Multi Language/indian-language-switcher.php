<?php
/**
 * Plugin Name: Indian Language Switcher
 * Plugin URI: https://example.com/indian-language-switcher
 * Description: A comprehensive language switcher plugin supporting all Indian languages. Allows users to switch between different Indian languages and translates content accordingly.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: indian-language-switcher
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('ILS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('ILS_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('ILS_PLUGIN_VERSION', '1.0.0');

class IndianLanguageSwitcher {
    
    private $supported_languages;
    private $current_language;
    
    public function __construct() {
        $this->init_supported_languages();
        $this->init_hooks();
    }
    
    private function init_supported_languages() {
        $this->supported_languages = array(
            'en' => array(
                'name' => 'English',
                'native_name' => 'English',
                'flag' => '🇮🇳',
                'code' => 'en'
            ),
            'hi' => array(
                'name' => 'Hindi',
                'native_name' => 'हिन्दी',
                'flag' => '🇮🇳',
                'code' => 'hi'
            ),
            'bn' => array(
                'name' => 'Bengali',
                'native_name' => 'বাংলা',
                'flag' => '🇮🇳',
                'code' => 'bn'
            ),
            'te' => array(
                'name' => 'Telugu',
                'native_name' => 'తెలుగు',
                'flag' => '🇮🇳',
                'code' => 'te'
            ),
            'mr' => array(
                'name' => 'Marathi',
                'native_name' => 'मराठी',
                'flag' => '🇮🇳',
                'code' => 'mr'
            ),
            'ta' => array(
                'name' => 'Tamil',
                'native_name' => 'தமிழ்',
                'flag' => '🇮🇳',
                'code' => 'ta'
            ),
            'gu' => array(
                'name' => 'Gujarati',
                'native_name' => 'ગુજરાતી',
                'flag' => '🇮🇳',
                'code' => 'gu'
            ),
            'kn' => array(
                'name' => 'Kannada',
                'native_name' => 'ಕನ್ನಡ',
                'flag' => '🇮🇳',
                'code' => 'kn'
            ),
            'ml' => array(
                'name' => 'Malayalam',
                'native_name' => 'മലയാളം',
                'flag' => '🇮🇳',
                'code' => 'ml'
            ),
            'pa' => array(
                'name' => 'Punjabi',
                'native_name' => 'ਪੰਜਾਬੀ',
                'flag' => '🇮🇳',
                'code' => 'pa'
            ),
            'or' => array(
                'name' => 'Odia',
                'native_name' => 'ଓଡ଼ିଆ',
                'flag' => '🇮🇳',
                'code' => 'or'
            ),
            'as' => array(
                'name' => 'Assamese',
                'native_name' => 'অসমীয়া',
                'flag' => '🇮🇳',
                'code' => 'as'
            ),
            'ur' => array(
                'name' => 'Urdu',
                'native_name' => 'اردو',
                'flag' => '🇮🇳',
                'code' => 'ur'
            ),
            'sa' => array(
                'name' => 'Sanskrit',
                'native_name' => 'संस्कृतम्',
                'flag' => '🇮🇳',
                'code' => 'sa'
            ),
            'ne' => array(
                'name' => 'Nepali',
                'native_name' => 'नेपाली',
                'flag' => '🇮🇳',
                'code' => 'ne'
            ),
            'sd' => array(
                'name' => 'Sindhi',
                'native_name' => 'सिन्धी',
                'flag' => '🇮🇳',
                'code' => 'sd'
            ),
            'ks' => array(
                'name' => 'Kashmiri',
                'native_name' => 'कॉशुर',
                'flag' => '🇮🇳',
                'code' => 'ks'
            ),
            'dv' => array(
                'name' => 'Maldivian',
                'native_name' => 'ދިވެހި',
                'flag' => '🇮🇳',
                'code' => 'dv'
            )
        );
    }
    
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_footer', array($this, 'add_language_switcher'));
        add_action('wp_ajax_ils_switch_language', array($this, 'ajax_switch_language'));
        add_action('wp_ajax_nopriv_ils_switch_language', array($this, 'ajax_switch_language'));
        add_action('wp_head', array($this, 'add_meta_tags'));
        add_filter('the_content', array($this, 'translate_content'));
        add_filter('the_title', array($this, 'translate_title'));
        add_filter('get_the_excerpt', array($this, 'translate_excerpt'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'admin_init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Include widget and shortcode
        require_once ILS_PLUGIN_PATH . 'includes/class-ils-widget.php';
        require_once ILS_PLUGIN_PATH . 'includes/class-ils-shortcode.php';
    }
    
    public function init() {
        // Set current language from session or default to English
        if (isset($_SESSION['ils_current_language'])) {
            $this->current_language = $_SESSION['ils_current_language'];
        } else {
            $this->current_language = 'en';
        }
        
        // Start session if not already started
        if (!session_id()) {
            session_start();
        }
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('ils-script', ILS_PLUGIN_URL . 'assets/js/ils-script.js', array('jquery'), ILS_PLUGIN_VERSION, true);
        wp_enqueue_style('ils-style', ILS_PLUGIN_URL . 'assets/css/ils-style.css', array(), ILS_PLUGIN_VERSION);
        
        wp_localize_script('ils-script', 'ils_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ils_nonce'),
            'current_language' => $this->current_language
        ));
    }
    
    public function add_language_switcher() {
        $current_lang = $this->current_language;
        $languages = $this->supported_languages;
        
        echo '<div id="ils-language-switcher" class="ils-language-switcher">';
        echo '<div class="ils-current-language" onclick="toggleLanguageDropdown()">';
        echo '<span class="ils-flag">' . $languages[$current_lang]['flag'] . '</span>';
        echo '<span class="ils-language-name">' . $languages[$current_lang]['native_name'] . '</span>';
        echo '<span class="ils-dropdown-arrow">▼</span>';
        echo '</div>';
        echo '<div class="ils-language-dropdown" id="ils-language-dropdown">';
        
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_lang) ? 'active' : '';
            echo '<div class="ils-language-option ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            echo '<span class="ils-flag">' . $language['flag'] . '</span>';
            echo '<span class="ils-language-name">' . $language['native_name'] . '</span>';
            echo '<span class="ils-language-english">(' . $language['name'] . ')</span>';
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
    }
    
    public function ajax_switch_language() {
        check_ajax_referer('ils_nonce', 'nonce');
        
        $language = sanitize_text_field($_POST['language']);
        
        if (array_key_exists($language, $this->supported_languages)) {
            if (!session_id()) {
                session_start();
            }
            $_SESSION['ils_current_language'] = $language;
            $this->current_language = $language;
            
            wp_send_json_success(array(
                'message' => 'Language switched successfully',
                'language' => $language
            ));
        } else {
            wp_send_json_error('Invalid language code');
        }
    }
    
    public function add_meta_tags() {
        $current_lang = $this->current_language;
        echo '<meta name="language" content="' . $current_lang . '">';
        echo '<html lang="' . $current_lang . '">';
    }
    
    public function translate_content($content) {
        if (is_admin()) {
            return $content;
        }
        
        // This is a simplified translation - in a real implementation,
        // you would integrate with a translation service like Google Translate API
        return $this->translate_text($content, $this->current_language);
    }
    
    public function translate_title($title) {
        if (is_admin()) {
            return $title;
        }
        
        return $this->translate_text($title, $this->current_language);
    }
    
    public function translate_excerpt($excerpt) {
        if (is_admin()) {
            return $excerpt;
        }
        
        return $this->translate_text($excerpt, $this->current_language);
    }
    
    private function translate_text($text, $target_language) {
        // For demo purposes, we'll use a simple translation mapping
        // In a real implementation, you would use Google Translate API or similar
        
        $translations = $this->get_translation_mappings();
        
        if ($target_language === 'en') {
            return $text; // No translation needed for English
        }
        
        // Simple word replacement for demo
        foreach ($translations[$target_language] as $english => $translated) {
            $text = str_ireplace($english, $translated, $text);
        }
        
        return $text;
    }
    
    private function get_translation_mappings() {
        return array(
            'hi' => array(
                'hello' => 'नमस्ते',
                'welcome' => 'स्वागत है',
                'home' => 'होम',
                'about' => 'हमारे बारे में',
                'contact' => 'संपर्क',
                'read more' => 'और पढ़ें',
                'search' => 'खोजें',
                'menu' => 'मेनू',
                'blog' => 'ब्लॉग',
                'news' => 'समाचार'
            ),
            'bn' => array(
                'hello' => 'হ্যালো',
                'welcome' => 'স্বাগতম',
                'home' => 'হোম',
                'about' => 'আমাদের সম্পর্কে',
                'contact' => 'যোগাযোগ',
                'read more' => 'আরও পড়ুন',
                'search' => 'অনুসন্ধান',
                'menu' => 'মেনু',
                'blog' => 'ব্লগ',
                'news' => 'সংবাদ'
            ),
            'te' => array(
                'hello' => 'హలో',
                'welcome' => 'స్వాగతం',
                'home' => 'హోమ్',
                'about' => 'మా గురించి',
                'contact' => 'సంప్రదించండి',
                'read more' => 'మరింత చదవండి',
                'search' => 'వెతకండి',
                'menu' => 'మెనూ',
                'blog' => 'బ్లాగ్',
                'news' => 'వార్తలు'
            )
            // Add more languages as needed
        );
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Indian Language Switcher Settings',
            'Language Switcher',
            'manage_options',
            'indian-language-switcher',
            array($this, 'admin_page')
        );
    }
    
    public function admin_init() {
        register_setting('ils_options', 'ils_settings');
        
        add_settings_section(
            'ils_main_section',
            'Language Switcher Settings',
            array($this, 'section_callback'),
            'indian-language-switcher'
        );
        
        add_settings_field(
            'ils_default_language',
            'Default Language',
            array($this, 'default_language_callback'),
            'indian-language-switcher',
            'ils_main_section'
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Indian Language Switcher Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('ils_options');
                do_settings_sections('indian-language-switcher');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    
    public function section_callback() {
        echo '<p>Configure the language switcher settings below:</p>';
    }
    
    public function default_language_callback() {
        $options = get_option('ils_settings');
        $default_language = isset($options['default_language']) ? $options['default_language'] : 'en';
        
        echo '<select name="ils_settings[default_language]">';
        foreach ($this->supported_languages as $code => $language) {
            $selected = ($code === $default_language) ? 'selected' : '';
            echo '<option value="' . $code . '" ' . $selected . '>' . $language['name'] . '</option>';
        }
        echo '</select>';
    }
    
    public function activate() {
        // Set default options
        $default_options = array(
            'default_language' => 'en'
        );
        add_option('ils_settings', $default_options);
    }
    
    public function deactivate() {
        // Clean up if needed
    }
}

// Initialize the plugin
new IndianLanguageSwitcher(); 