# Installation Guide - Indian Language Switcher

## Quick Installation

### Step 1: Upload Plugin
1. Download the plugin files
2. Upload the entire `indian-language-switcher` folder to your WordPress `/wp-content/plugins/` directory
3. Or zip the folder and upload via WordPress admin

### Step 2: Activate Plugin
1. Go to WordPress Admin > Plugins
2. Find "Indian Language Switcher" in the list
3. Click "Activate"

### Step 3: Configure Settings
1. Go to Settings > Language Switcher
2. Select your default language
3. Save changes

## Usage

### Automatic Display
The language switcher will automatically appear as a floating widget in the top-right corner of your website.

### Widget Display
1. Go to Appearance > Widgets
2. Add "Indian Language Switcher" widget to any widget area
3. Configure display options

### Shortcode Usage
Use these shortcodes anywhere in your content:

```
[indian_language_switcher]
[ils_switcher style="dropdown"]
[ils_switcher style="buttons" show_flags="true"]
[ils_switcher style="list" show_native_names="true"]
[ils_switcher style="flags"]
```

### Shortcode Parameters
- `style`: dropdown, list, buttons, flags
- `show_flags`: true/false
- `show_native_names`: true/false
- `class`: custom CSS class

## Customization

### CSS Customization
Edit `assets/css/ils-style.css` to customize appearance.

### Position Changes
Modify the CSS position in the main stylesheet:
```css
.ils-language-switcher {
    position: fixed;
    top: 20px;    /* Change position */
    right: 20px;  /* Change position */
}
```

## Troubleshooting

### Plugin Not Working?
1. Check if plugin is activated
2. Clear browser cache
3. Check browser console for errors
4. Verify theme supports required hooks

### Translations Not Working?
1. Check translation mappings in main plugin file
2. Verify language codes are correct
3. Test with simple words first

## Support
For help, check the README.md file or contact the plugin author. 