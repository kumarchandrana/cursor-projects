jQuery(document).ready(function($) {
    
    // Global variables
    let isDropdownOpen = false;
    
    // Toggle language dropdown
    window.toggleLanguageDropdown = function() {
        const dropdown = document.getElementById('ils-language-dropdown');
        const arrow = document.querySelector('.ils-dropdown-arrow');
        
        if (isDropdownOpen) {
            dropdown.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
            isDropdownOpen = false;
        } else {
            dropdown.style.display = 'block';
            arrow.style.transform = 'rotate(180deg)';
            isDropdownOpen = true;
        }
    };
    
    // Switch language function
    window.switchLanguage = function(languageCode) {
        // Show loading state
        const switcher = document.getElementById('ils-language-switcher');
        switcher.classList.add('loading');
        
        // Make AJAX request to switch language
        $.ajax({
            url: ils_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'ils_switch_language',
                language: languageCode,
                nonce: ils_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Update the UI to reflect the new language
                    updateLanguageUI(languageCode);
                    
                    // Reload the page to apply translations
                    setTimeout(function() {
                        location.reload();
                    }, 500);
                } else {
                    console.error('Language switch failed:', response.data);
                    switcher.classList.remove('loading');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                switcher.classList.remove('loading');
            }
        });
    };
    
    // Update language UI
    function updateLanguageUI(languageCode) {
        const currentLanguage = document.querySelector('.ils-current-language');
        const languageName = document.querySelector('.ils-language-name');
        const flag = document.querySelector('.ils-flag');
        
        // Update with new language info (this would be populated from PHP)
        // For now, we'll just show a loading state
        languageName.textContent = 'Loading...';
    }
    
    // Close dropdown when clicking outside
    $(document).on('click', function(e) {
        const switcher = document.getElementById('ils-language-switcher');
        if (!switcher.contains(e.target)) {
            const dropdown = document.getElementById('ils-language-dropdown');
            const arrow = document.querySelector('.ils-dropdown-arrow');
            
            if (isDropdownOpen) {
                dropdown.style.display = 'none';
                arrow.style.transform = 'rotate(0deg)';
                isDropdownOpen = false;
            }
        }
    });
    
    // Keyboard navigation
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && isDropdownOpen) {
            toggleLanguageDropdown();
        }
    });
    
    // Add smooth animations
    $('.ils-language-option').hover(
        function() {
            $(this).addClass('hover');
        },
        function() {
            $(this).removeClass('hover');
        }
    );
    
    // Add loading animation
    function showLoading() {
        const switcher = document.getElementById('ils-language-switcher');
        switcher.classList.add('loading');
        
        // Add loading spinner
        const spinner = document.createElement('div');
        spinner.className = 'ils-loading-spinner';
        spinner.innerHTML = '<div class="spinner"></div>';
        switcher.appendChild(spinner);
    }
    
    function hideLoading() {
        const switcher = document.getElementById('ils-language-switcher');
        switcher.classList.remove('loading');
        
        // Remove loading spinner
        const spinner = switcher.querySelector('.ils-loading-spinner');
        if (spinner) {
            spinner.remove();
        }
    }
    
    // Add accessibility features
    $('.ils-current-language').attr('role', 'button');
    $('.ils-current-language').attr('aria-haspopup', 'true');
    $('.ils-current-language').attr('aria-expanded', 'false');
    
    $('.ils-language-option').attr('role', 'menuitem');
    $('.ils-language-dropdown').attr('role', 'menu');
    
    // Update ARIA attributes when dropdown is toggled
    function updateAriaAttributes() {
        const currentLanguage = document.querySelector('.ils-current-language');
        const dropdown = document.getElementById('ils-language-dropdown');
        
        if (isDropdownOpen) {
            currentLanguage.setAttribute('aria-expanded', 'true');
            dropdown.setAttribute('aria-hidden', 'false');
        } else {
            currentLanguage.setAttribute('aria-expanded', 'false');
            dropdown.setAttribute('aria-hidden', 'true');
        }
    }
    
    // Override the toggle function to include ARIA updates
    const originalToggle = window.toggleLanguageDropdown;
    window.toggleLanguageDropdown = function() {
        originalToggle();
        updateAriaAttributes();
    };
    
    // Add focus management
    $('.ils-language-option').on('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            const languageCode = $(this).data('language');
            switchLanguage(languageCode);
        }
    });
    
    // Add screen reader announcements
    function announceLanguageChange(languageName) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = `Language changed to ${languageName}`;
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            announcement.remove();
        }, 1000);
    }
    
    // Enhanced switch language function with announcements
    const originalSwitchLanguage = window.switchLanguage;
    window.switchLanguage = function(languageCode) {
        const languageOption = document.querySelector(`[data-language="${languageCode}"]`);
        const languageName = languageOption ? languageOption.querySelector('.ils-language-name').textContent : languageCode;
        
        announceLanguageChange(languageName);
        originalSwitchLanguage(languageCode);
    };
    
    // Add touch support for mobile devices
    let touchStartY = 0;
    let touchEndY = 0;
    
    $('.ils-current-language').on('touchstart', function(e) {
        touchStartY = e.originalEvent.touches[0].clientY;
    });
    
    $('.ils-current-language').on('touchend', function(e) {
        touchEndY = e.originalEvent.changedTouches[0].clientY;
        const touchDiff = touchStartY - touchEndY;
        
        // Only trigger if it's a tap (not a swipe)
        if (Math.abs(touchDiff) < 10) {
            toggleLanguageDropdown();
        }
    });
    
    // Add performance optimization
    let resizeTimeout;
    $(window).on('resize', function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            // Reposition dropdown if needed
            const dropdown = document.getElementById('ils-language-dropdown');
            if (isDropdownOpen) {
                // Check if dropdown is still visible
                const rect = dropdown.getBoundingClientRect();
                if (rect.bottom > window.innerHeight) {
                    dropdown.style.top = 'auto';
                    dropdown.style.bottom = '100%';
                }
            }
        }, 250);
    });
    
    // Initialize tooltips for language names
    $('.ils-language-option').each(function() {
        const $this = $(this);
        const languageName = $this.find('.ils-language-name').text();
        const englishName = $this.find('.ils-language-english').text();
        
        $this.attr('title', `${languageName} (${englishName})`);
    });
    
    // Add error handling
    window.addEventListener('error', function(e) {
        console.error('Language switcher error:', e.error);
        
        // Fallback: reload page if language switch fails
        if (e.error && e.error.message && e.error.message.includes('ils')) {
            setTimeout(function() {
                location.reload();
            }, 1000);
        }
    });
    
    // Add analytics tracking (optional)
    function trackLanguageSwitch(languageCode) {
        if (typeof gtag !== 'undefined') {
            gtag('event', 'language_switch', {
                'event_category': 'user_interaction',
                'event_label': languageCode
            });
        }
    }
    
    // Override switch language to include tracking
    const originalSwitchLanguageWithTracking = window.switchLanguage;
    window.switchLanguage = function(languageCode) {
        trackLanguageSwitch(languageCode);
        originalSwitchLanguageWithTracking(languageCode);
    };
    
}); 