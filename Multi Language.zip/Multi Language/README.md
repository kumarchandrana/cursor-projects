# Indian Language Switcher - WordPress Plugin

A comprehensive WordPress plugin that provides a beautiful language switcher supporting all major Indian languages. When users select a language, the entire website content changes to that language.

## 🌟 Features

- **18 Indian Languages Supported**: Hindi, Bengali, Telugu, Marathi, Tamil, Gujarati, Kannada, Malayalam, Punjabi, Odia, Assamese, Urdu, Sanskrit, Nepali, Sindhi, Kashmiri, and Maldivian
- **Beautiful UI**: Modern, responsive design with smooth animations
- **Accessibility**: Full keyboard navigation and screen reader support
- **Mobile Responsive**: Works perfectly on all devices
- **Dark Mode Support**: Automatically adapts to user's system preferences
- **Translation System**: Built-in translation mappings for common words
- **Admin Panel**: Easy configuration through WordPress admin
- **AJAX Powered**: Smooth language switching without page reload
- **SEO Friendly**: Proper meta tags and language attributes

## 📋 Supported Languages

| Language | Native Name | Code | Script |
|----------|-------------|------|--------|
| English | English | en | Latin |
| Hindi | हिन्दी | hi | Devanagari |
| Bengali | বাংলা | bn | Bengali |
| Telugu | తెలుగు | te | Telugu |
| Marathi | मराठी | mr | Devanagari |
| Tamil | தமிழ் | ta | Tamil |
| Gujarati | ગુજરાતી | gu | Gujarati |
| Kannada | ಕನ್ನಡ | kn | Kannada |
| Malayalam | മലയാളം | ml | Malayalam |
| Punjabi | ਪੰਜਾਬੀ | pa | Gurmukhi |
| Odia | ଓଡ଼ିଆ | or | Odia |
| Assamese | অসমীয়া | as | Bengali |
| Urdu | اردو | ur | Arabic |
| Sanskrit | संस्कृतम् | sa | Devanagari |
| Nepali | नेपाली | ne | Devanagari |
| Sindhi | सिन्धी | sd | Devanagari |
| Kashmiri | कॉशुर | ks | Devanagari |
| Maldivian | ދިވެހި | dv | Thaana |

## 🚀 Installation

### Method 1: Manual Installation

1. Download the plugin files
2. Upload the `indian-language-switcher` folder to your WordPress `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress admin
4. Go to Settings > Language Switcher to configure the plugin

### Method 2: WordPress Admin Upload

1. Go to WordPress Admin > Plugins > Add New
2. Click "Upload Plugin"
3. Choose the plugin zip file
4. Click "Install Now"
5. Activate the plugin

## ⚙️ Configuration

### Admin Settings

1. Go to **Settings > Language Switcher** in your WordPress admin
2. Select your default language
3. Save changes

### Customization

The language switcher appears as a floating widget in the top-right corner of your website. You can customize its appearance by modifying the CSS file located at:
```
assets/css/ils-style.css
```

## 🎨 Customization Options

### Changing Position

To change the position of the language switcher, modify the CSS in `assets/css/ils-style.css`:

```css
.ils-language-switcher {
    position: fixed;
    top: 20px;        /* Change top position */
    right: 20px;      /* Change right position */
    /* or use left: 20px; for left side */
}
```

### Changing Colors

The plugin uses CSS custom properties for easy theming:

```css
:root {
    --ils-primary-color: #1976d2;      /* Primary color */
    --ils-secondary-color: #6c757d;    /* Secondary color */
    --ils-background-color: #ffffff;   /* Background color */
    --ils-border-color: #e1e5e9;       /* Border color */
    --ils-hover-color: #f8f9fa;       /* Hover color */
    --ils-text-color: #2c3e50;        /* Text color */
}
```

### Adding Custom Translations

To add custom translations, edit the `get_translation_mappings()` method in the main plugin file:

```php
private function get_translation_mappings() {
    return array(
        'hi' => array(
            'your_word' => 'आपका शब्द',
            'another_word' => 'दूसरा शब्द',
        ),
        // Add more languages...
    );
}
```

## 🔧 Advanced Features

### Integration with Translation Services

For production use, you can integrate with translation services like Google Translate API:

```php
private function translate_text($text, $target_language) {
    // Replace this with your translation service
    $api_key = 'your_google_translate_api_key';
    $url = "https://translation.googleapis.com/language/translate/v2?key=" . $api_key;
    
    $data = array(
        'q' => $text,
        'target' => $target_language,
        'source' => 'en'
    );
    
    // Make API call and return translated text
    return $translated_text;
}
```

### Shortcode Support

Add this to your theme's `functions.php` to display the language switcher anywhere:

```php
function ils_language_switcher_shortcode() {
    ob_start();
    // Your language switcher HTML here
    return ob_get_clean();
}
add_shortcode('language_switcher', 'ils_language_switcher_shortcode');
```

## 📱 Mobile Support

The plugin is fully responsive and includes:

- Touch-friendly interface
- Swipe gestures support
- Optimized layout for small screens
- Proper viewport handling

## ♿ Accessibility Features

- **Keyboard Navigation**: Full keyboard support with arrow keys and Enter/Space
- **Screen Reader Support**: Proper ARIA labels and announcements
- **High Contrast Mode**: Automatic adaptation to system preferences
- **Reduced Motion**: Respects user's motion preferences
- **Focus Management**: Clear focus indicators

## 🔒 Security Features

- **Nonce Verification**: All AJAX requests are protected with WordPress nonces
- **Input Sanitization**: All user inputs are properly sanitized
- **XSS Protection**: Output is properly escaped
- **Session Management**: Secure session handling for language preferences

## 🐛 Troubleshooting

### Common Issues

1. **Language switcher not appearing**
   - Check if the plugin is activated
   - Verify that your theme supports `wp_footer()` hook
   - Check browser console for JavaScript errors

2. **Translations not working**
   - Ensure you have proper translation mappings
   - Check if the content filter is working
   - Verify language codes are correct

3. **Styling issues**
   - Clear browser cache
   - Check for CSS conflicts with your theme
   - Verify CSS file is loading properly

### Debug Mode

Enable WordPress debug mode to see detailed error messages:

```php
// Add to wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

## 📈 Performance Optimization

- **Caching**: Consider implementing translation caching
- **Lazy Loading**: Load translations on demand
- **CDN**: Serve static assets through CDN
- **Minification**: Minify CSS and JavaScript files

## 🤝 Contributing

We welcome contributions! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This plugin is licensed under the GPL v2 or later.

## 🙏 Credits

- **Flags**: Emoji flags for visual representation
- **Fonts**: Google Noto Sans fonts for proper text rendering
- **Icons**: Modern CSS for smooth animations

## 📞 Support

For support and questions:

- Create an issue on GitHub
- Contact the plugin author
- Check the WordPress.org plugin forum

## 🔄 Changelog

### Version 1.0.0
- Initial release
- Support for 18 Indian languages
- Modern UI with animations
- Mobile responsive design
- Accessibility features
- Admin configuration panel

---

**Made with ❤️ for the Indian WordPress community** 