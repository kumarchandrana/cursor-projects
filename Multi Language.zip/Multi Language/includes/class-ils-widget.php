<?php
/**
 * Indian Language Switcher Widget
 */

if (!defined('ABSPATH')) {
    exit;
}

class ILS_Language_Switcher_Widget extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'ils_language_switcher_widget',
            'Indian Language Switcher',
            array(
                'description' => 'Display the Indian Language Switcher in any widget area',
                'classname' => 'ils-widget'
            )
        );
    }
    
    public function widget($args, $instance) {
        echo $args['before_widget'];
        
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        
        // Display the language switcher
        $this->display_language_switcher($instance);
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        $position = !empty($instance['position']) ? $instance['position'] : 'dropdown';
        $show_flags = !empty($instance['show_flags']) ? $instance['show_flags'] : true;
        $show_native_names = !empty($instance['show_native_names']) ? $instance['show_native_names'] : true;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('position'); ?>">Display Style:</label>
            <select class="widefat" id="<?php echo $this->get_field_id('position'); ?>" name="<?php echo $this->get_field_name('position'); ?>">
                <option value="dropdown" <?php selected($position, 'dropdown'); ?>>Dropdown</option>
                <option value="list" <?php selected($position, 'list'); ?>>List</option>
                <option value="buttons" <?php selected($position, 'buttons'); ?>>Buttons</option>
            </select>
        </p>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('show_flags'); ?>" name="<?php echo $this->get_field_name('show_flags'); ?>" <?php checked($show_flags); ?>>
            <label for="<?php echo $this->get_field_id('show_flags'); ?>">Show Flags</label>
        </p>
        <p>
            <input type="checkbox" id="<?php echo $this->get_field_id('show_native_names'); ?>" name="<?php echo $this->get_field_name('show_native_names'); ?>" <?php checked($show_native_names); ?>>
            <label for="<?php echo $this->get_field_id('show_native_names'); ?>">Show Native Names</label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['position'] = (!empty($new_instance['position'])) ? strip_tags($new_instance['position']) : 'dropdown';
        $instance['show_flags'] = (!empty($new_instance['show_flags'])) ? true : false;
        $instance['show_native_names'] = (!empty($new_instance['show_native_names'])) ? true : false;
        return $instance;
    }
    
    private function display_language_switcher($instance) {
        $position = isset($instance['position']) ? $instance['position'] : 'dropdown';
        $show_flags = isset($instance['show_flags']) ? $instance['show_flags'] : true;
        $show_native_names = isset($instance['show_native_names']) ? $instance['show_native_names'] : true;
        
        // Get current language and supported languages
        $current_language = isset($_SESSION['ils_current_language']) ? $_SESSION['ils_current_language'] : 'en';
        $supported_languages = $this->get_supported_languages();
        
        switch ($position) {
            case 'list':
                $this->display_list_style($supported_languages, $current_language, $show_flags, $show_native_names);
                break;
            case 'buttons':
                $this->display_buttons_style($supported_languages, $current_language, $show_flags, $show_native_names);
                break;
            default:
                $this->display_dropdown_style($supported_languages, $current_language, $show_flags, $show_native_names);
                break;
        }
    }
    
    private function display_dropdown_style($languages, $current_lang, $show_flags, $show_native_names) {
        echo '<div class="ils-widget-dropdown">';
        echo '<div class="ils-widget-current" onclick="toggleWidgetDropdown()">';
        if ($show_flags) {
            echo '<span class="ils-widget-flag">' . $languages[$current_lang]['flag'] . '</span>';
        }
        if ($show_native_names) {
            echo '<span class="ils-widget-name">' . $languages[$current_lang]['native_name'] . '</span>';
        } else {
            echo '<span class="ils-widget-name">' . $languages[$current_lang]['name'] . '</span>';
        }
        echo '<span class="ils-widget-arrow">▼</span>';
        echo '</div>';
        echo '<div class="ils-widget-options" id="ils-widget-options">';
        
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_lang) ? 'active' : '';
            echo '<div class="ils-widget-option ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-widget-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-widget-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-widget-name">' . $language['name'] . '</span>';
            }
            echo '</div>';
        }
        
        echo '</div>';
        echo '</div>';
    }
    
    private function display_list_style($languages, $current_lang, $show_flags, $show_native_names) {
        echo '<div class="ils-widget-list">';
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_lang) ? 'active' : '';
            echo '<div class="ils-widget-list-item ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-widget-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-widget-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-widget-name">' . $language['name'] . '</span>';
            }
            echo '</div>';
        }
        echo '</div>';
    }
    
    private function display_buttons_style($languages, $current_lang, $show_flags, $show_native_names) {
        echo '<div class="ils-widget-buttons">';
        foreach ($languages as $code => $language) {
            $active_class = ($code === $current_lang) ? 'active' : '';
            echo '<button class="ils-widget-button ' . $active_class . '" data-language="' . $code . '" onclick="switchLanguage(\'' . $code . '\')">';
            if ($show_flags) {
                echo '<span class="ils-widget-flag">' . $language['flag'] . '</span>';
            }
            if ($show_native_names) {
                echo '<span class="ils-widget-name">' . $language['native_name'] . '</span>';
            } else {
                echo '<span class="ils-widget-name">' . $language['name'] . '</span>';
            }
            echo '</button>';
        }
        echo '</div>';
    }
    
    private function get_supported_languages() {
        return array(
            'en' => array('name' => 'English', 'native_name' => 'English', 'flag' => '🇮🇳'),
            'hi' => array('name' => 'Hindi', 'native_name' => 'हिन्दी', 'flag' => '🇮🇳'),
            'bn' => array('name' => 'Bengali', 'native_name' => 'বাংলা', 'flag' => '🇮🇳'),
            'te' => array('name' => 'Telugu', 'native_name' => 'తెలుగు', 'flag' => '🇮🇳'),
            'mr' => array('name' => 'Marathi', 'native_name' => 'मराठी', 'flag' => '🇮🇳'),
            'ta' => array('name' => 'Tamil', 'native_name' => 'தமிழ்', 'flag' => '🇮🇳'),
            'gu' => array('name' => 'Gujarati', 'native_name' => 'ગુજરાતી', 'flag' => '🇮🇳'),
            'kn' => array('name' => 'Kannada', 'native_name' => 'ಕನ್ನಡ', 'flag' => '🇮🇳'),
            'ml' => array('name' => 'Malayalam', 'native_name' => 'മലയാളം', 'flag' => '🇮🇳'),
            'pa' => array('name' => 'Punjabi', 'native_name' => 'ਪੰਜਾਬੀ', 'flag' => '🇮🇳'),
            'or' => array('name' => 'Odia', 'native_name' => 'ଓଡ଼ିଆ', 'flag' => '🇮🇳'),
            'as' => array('name' => 'Assamese', 'native_name' => 'অসমীয়া', 'flag' => '🇮🇳'),
            'ur' => array('name' => 'Urdu', 'native_name' => 'اردو', 'flag' => '🇮🇳'),
            'sa' => array('name' => 'Sanskrit', 'native_name' => 'संस्कृतम्', 'flag' => '🇮🇳'),
            'ne' => array('name' => 'Nepali', 'native_name' => 'नेपाली', 'flag' => '🇮🇳'),
            'sd' => array('name' => 'Sindhi', 'native_name' => 'सिन्धी', 'flag' => '🇮🇳'),
            'ks' => array('name' => 'Kashmiri', 'native_name' => 'कॉशुर', 'flag' => '🇮🇳'),
            'dv' => array('name' => 'Maldivian', 'native_name' => 'ދިވެހި', 'flag' => '🇮🇳')
        );
    }
}

// Register the widget
function ils_register_widget() {
    register_widget('ILS_Language_Switcher_Widget');
}
add_action('widgets_init', 'ils_register_widget'); 